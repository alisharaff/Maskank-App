# maskank

A new Flutter project To rent apartments using artificial intelligence.

![Splash](https://github.com/alisharaff/Maskank_App_Version_oNe/assets/77925806/b5d0ccbb-ddb5-4d59-95d8-5f9347c911f1)

![Onboarding-1](https://github.com/alisharaff/Maskank_App_Version_oNe/assets/77925806/5e0084a6-6b18-4006-8fba-da34c943ac3e)

## Getting Started

This project is a starting point for a Flutter application.

# -- System Design

# lib -- Core -- like this
                # __ DI(get_it)
                # __ Networking(Dio -- Retrofit)
                # __ Routing
                # __ Helpers
                # __ Theming
                # __ Widgets
# lib -- Features -- like this -
                       # home
                          --  data -- model - repo
                          --  logic -- cuibt
                          --  ui --  screens - home_widgets
# Hello friends, my name is Ali Sharaf and i with my flutter team here
# Please don't touch anything here 😅                           
