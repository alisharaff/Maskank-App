import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:maskank/view/screens/splash/splash_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileScreenController extends GetxController {
  TextEditingController fullnameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController mailController = TextEditingController();

  TextEditingController addressController = TextEditingController();
  FocusNode focusNode = FocusNode();
  Color fontColor = const Color(0xffABAC9C);
  bool isReadOnly = true;
  String profileName = 'Ali SHaraf';
  String userPhone = '';

  Uint8List? image;

  @override
  void onInit() {
    super.onInit();
    getInfo();
  }

  getInfo() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    profileName = prefs.getString(AppConstants.fullName)!;
    userPhone = prefs.getString(AppConstants.userPhone)!;
    fullnameController.text = profileName;
    phoneController.text = userPhone;
    update();
  }

  void logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.clear();

    Get.to(() => const SplashScreen());
  }

  void toggleReadOnly() {
    isReadOnly = !isReadOnly;
    profileName = fullnameController.text;
    update();
  }

  void showImagePickerOption() {
    Get.bottomSheet(
      Container(
        color: const Color(0xffEAF0EC),
        padding: const EdgeInsets.all(18.0),
        child: SizedBox(
          width: Get.width,
          height: Get.height / 4.5,
          child: Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      _pickImageFromGallery();
                    },
                    child: const SizedBox(
                      child: Column(
                        children: [
                          Icon(
                            Icons.image,
                            size: 70,
                            color: Color(0xff5E756D),
                          ),
                          Text("Gallery",
                              style: TextStyle(
                                fontFamily: "Besley",
                              ))
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      _pickImageFromCamera();
                    },
                    child: const SizedBox(
                      child: Column(
                        children: [
                          Icon(
                            Icons.camera_alt,
                            size: 70,
                            color: Color(0xff5E756D),
                          ),
                          Text(
                            "Camera",
                            style: TextStyle(
                              fontFamily: "Besley",
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future _pickImageFromGallery() async {
    final returnImage =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (returnImage == null) return;
    image = File(returnImage.path).readAsBytesSync();
    Get.back();
    update();
  }

  Future _pickImageFromCamera() async {
    final returnImage =
        await ImagePicker().pickImage(source: ImageSource.camera);
    if (returnImage == null) return;
    image = File(returnImage.path).readAsBytesSync();
    Get.back();
    update();
  }
}
