import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/data/model/post_details_model.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PostController extends GetxController {
  late PostDetails postDetails;
  List houseList = [];
  bool isRequest = true;
  bool isLoad = false;

  @override
  void onInit() {
    super.onInit();
    isRequest = true;
  }

  void getPostDetials(int postId) async {
    isLoad = false;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response =
        await apiClient.getData("${AppConstants.getPostsDetailsUrl}/$postId");

    // Check the response status
    if (response.statusCode == 200) {
      print(response.body);
      Map<String, dynamic> jsonMap = response.body['post details'];
      postDetails = PostDetails.fromJson(jsonMap);
      isLoad = true;
      update();
      print(postDetails.city);
    } else {
      print(response.body);
      isLoad = true;
      update();
      print("NO Data");
    }
  }

  void requestPost(int postId) async {
    isRequest = true;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Map<String, dynamic> userData = {
      "renter_id": prefs.getInt(AppConstants.userID)
    };

    Response response = await apiClient.postData(
        '${AppConstants.addRequestPostUrl}/$postId', userData);

    // Check the response status
    if (response.statusCode == 200) {
      isRequest = false;
      update();
      Fluttertoast.showToast(
          msg: "Request successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
    } else {
      isRequest = false;
      update();
      Fluttertoast.showToast(
          msg: "Try Again",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
