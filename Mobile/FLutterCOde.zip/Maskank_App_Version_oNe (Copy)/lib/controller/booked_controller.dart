import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/data/model/request_user_post_model.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BookedUserRequestController extends GetxController {
  bool isLoad = false;
  List<PostData> houseList = [];
  getRequestInfo() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response =
        await apiClient.getData("${AppConstants.showRequestPostUrl}/${prefs.getInt(AppConstants.userID)}");

    // Check the response status
    if (response.statusCode == 200) {
      Map<String, dynamic> jsonResponse = response.body;
     List<dynamic> jsonList = jsonResponse['data'];
      houseList = jsonList.map((json) => PostData.fromJson(json)).toList();
      isLoad = false;
      update();
    } else {
      print(response.body);
      isLoad = false;
      update();
      Fluttertoast.showToast(
          msg: "Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
