import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/data/model/post_owner_model.dart';
import 'package:maskank/data/model/request_data_model.dart';
import 'package:maskank/data/model/requests_user_model.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UploadOwnerStatusController extends GetxController {
  bool isLoad = false;
  bool isLoadReq = false;
 
  late List<MainRequestsOwner> postListRequsts;
  @override
  void onInit() {
    super.onInit();
    getPostsOfOwner();
  }
  bool isLoadStuts = false;
  void updatePost(int status, int reqId) async {
    isLoadStuts = true;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Map<String, dynamic> userData = {
      'status': status,
      '_method': "put",
    };

    Response response = await apiClient.postData(
        "${AppConstants.updtaeRequestStatusUrl}/$reqId", userData);

    // Check the response status
    if (response.statusCode == 200) {
      print(response.body);
      Fluttertoast.showToast(
          msg: "Update successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);

      isLoadStuts = false;
      update();
    } else {
      isLoadStuts = false;
      update();
      Fluttertoast.showToast(
          msg: "Update Erorr",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
  void getPostsOfOwner() async {
    isLoad = true;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response = await apiClient.getData(
        "${AppConstants.getRequestDataUrl}/${prefs.getInt(AppConstants.userID)}");
    print("******************");
    print(response.body);
    print("******************");

    // Check the response status
    if (response.statusCode == 200) {
      List<dynamic> jsonList = response.body as List<dynamic>;

      postListRequsts =
          jsonList.map((json) => MainRequestsOwner.fromJson(json)).toList();
      isLoad = false;
      update();
    } else {
      isLoad = false;
      update();
      Fluttertoast.showToast(
          msg: "Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  void loadWaitingAndDone() {}
}
