import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:maskank/view/base/butNavBar/owner_nav_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginOwnerController extends GetxController {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  GlobalKey<FormState> loginOwnerformKey = GlobalKey<FormState>();
  bool isVisible = false;
  bool isLogin = false;

  void toggleVisibility() {
    isVisible = !isVisible;
    update();
  }

  void login() {
    if (loginOwnerformKey.currentState!.validate()) {
      loginOwner();
    }
  }

  void loginOwner() async {
    isLogin = true;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Map<String, dynamic> userData = {
      'username': username.text,
      'password': password.text,
    };

    Response response =
        await apiClient.postAuthData(AppConstants.ownerLoginUrl, userData);

    // Check the response status
    if (response.statusCode == 200) {
      prefs.setString(AppConstants.token, response.body["token"]);
            prefs.setString(AppConstants.type, "Owner");

      prefs.setString(
          AppConstants.userName, response.body["owner"]["username"]);
      prefs.setInt(AppConstants.userID, response.body["owner"]["owner_id"]);
      prefs.setString(AppConstants.userPhone, response.body["owner"]["phone"]);
      prefs.setString(
          AppConstants.fullName, response.body["owner"]["owner_name"]);

      isLogin = false;
      update();
      Fluttertoast.showToast(
          msg: "Owner Login successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      Get.to(() => OwnerMyNavBar());
    } else {
      isLogin = false;
      update();
      Fluttertoast.showToast(
          msg: "Owner Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
