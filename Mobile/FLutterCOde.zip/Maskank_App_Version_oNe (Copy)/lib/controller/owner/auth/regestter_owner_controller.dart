import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:maskank/view/screens/auth/owner/login/login_page_owner.dart';
import 'package:maskank/view/screens/auth/owner/scan/scan2_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RegesterOwnerController extends GetxController {
  final usernameController = TextEditingController();
  final email = TextEditingController();
  final fullnameController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmpasswordController = TextEditingController();
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  bool isRegister = false;
  bool isvisible = false;
  void changeVisible() {
    isvisible = !isvisible;
    update();
  }

  void registerUser() async {
    isRegister = true;

    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Map<String, dynamic> userData = {
      'username': usernameController.text,
      'password': passwordController.text,
      'owner_name': fullnameController.text,
      'email': email.text,
      'phone': phoneController.text,
      'photo': 'test.jpg',
      "national_id": '999892'
    };

    Response response =
        await apiClient.postAuthData(AppConstants.ownerRegisterUrl, userData);
    // Check the response status
    if (response.statusCode == 200) {
      isRegister = false;
      update();
      Fluttertoast.showToast(
          msg: "Owner registered successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      Get.to(() => const LoginOwner());
    } else {
      isRegister = false;
      Get.to(() => const LoginOwner());

      update();

      // if (t) {
      //   Fluttertoast.showToast(
      //       msg: "Owner already exists",
      //       toastLength: Toast.LENGTH_SHORT,
      //       gravity: ToastGravity.BOTTOM,
      //       timeInSecForIosWeb: 1,
      //       backgroundColor: Colors.red,
      //       textColor: Colors.white,
      //       fontSize: 16.0);
      // } else {
      //   Fluttertoast.showToast(
      //       msg: "Failed to register Owner",
      //       toastLength: Toast.LENGTH_SHORT,
      //       gravity: ToastGravity.BOTTOM,
      //       timeInSecForIosWeb: 1,
      //       backgroundColor: Colors.red,
      //       textColor: Colors.white,
      //       fontSize: 16.0);
      // }
    }
  }
}
