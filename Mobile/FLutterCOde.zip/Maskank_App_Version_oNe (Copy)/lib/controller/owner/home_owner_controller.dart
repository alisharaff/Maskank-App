import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/owner/upload_owner_status.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeOwnerController extends GetxController {
  int done = 0;
  int waiting = 0;
  bool isLoad = true;
  String? ownerName = "Owner Name";

  @override
  void onInit() {
    super.onInit();
    loadWaitingAndDone();
    Get.put(UploadOwnerStatusController()).getPostsOfOwner();
  }

  void loadWaitingAndDone() async {
    isLoad = true;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ownerName = prefs.getString(AppConstants.fullName);

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response = await apiClient.getData(
        "${AppConstants.ownerWaitingAndDoneUrl}/${prefs.getInt(AppConstants.userID)}");

    // Check the response status
    if (response.statusCode == 200) {
      print("******************");
      print(response.body["Done"]);
      print(response.body["Waiting"]);
      done = response.body["Done"];
      waiting = response.body["Waiting"];
      print(waiting);
      print("******************");
      isLoad = false;
      update();
    } else {
      print(response.body);
      isLoad = false;
      update();
      Fluttertoast.showToast(
          msg: "Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
