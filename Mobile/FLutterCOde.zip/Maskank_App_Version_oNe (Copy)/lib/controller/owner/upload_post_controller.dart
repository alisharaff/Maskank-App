import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class UploadPostOwnerController extends GetxController {
  TextEditingController location = TextEditingController();
  TextEditingController priceField = TextEditingController();
  TextEditingController yourDescription = TextEditingController();
  List<File> selectedImages = [];
  bool isLoadAi = false;
  bool isLoadUpload = false;
  String? selectedCondition;
  String? selectedCity;
  String? selectedRegi;
  String? selectedFor;
  int selectedBedrooms = 1;
  int selectedBathroom = 1;
  String? selectedType;
  int selectedFloor = 0;
  double selectedSize = 40;
  List selectdReg = ["", ""];
  List rAlex = [
    'Kafr Abdo',
    'Seyouf',
    'Raml Station',
    'Moharam Bik',
    'Saba Pasha',
    'Miami',
    'Sporting',
    'Sidi Beshr',
    'Manshiyya',
    'Al Ibrahimiyyah',
    'Mandara',
    'Gianaclis',
    'Asafra',
    'Sidi Gaber',
    'Cleopatra',
    'Glim',
    'San Stefano',
    'Nakheel',
    'Azarita',
    'Zezenia',
    'Camp Caesar',
    'Al Hadrah',
    'Montazah',
    'Bolkly',
    'Fleming',
    'Maamoura',
    'Abu Qir',
    'Schutz',
    'Awayed',
    'Bahray - Anfoshy',
    'Ras El Tin',
    'Abu Talat',
    'Borg al-Arab',
    'Kabbary'
  ];

  List cairoR = [
    'Zahraa Al Maadi',
    'Nasr City',
    'Mostakbal City',
    'New Cairo - El Tagamoa',
    'New Capital City',
    'Madinaty',
    'Shorouk City',
    'New Nozha',
    'Rehab City',
    'Heliopolis',
    'Obour City',
    'Badr City',
    'Sheraton',
    'Helmeyat El Zaytoun',
    'Shubra',
    'Abasiya',
    'Downtown Cairo',
    'Salam City',
    'Katameya',
    'Gesr Al Suez',
    'Zamalek',
    'Helwan',
    'Al Manial',
    'Garden City',
    'Basateen',
    'Matareya',
    'Dar al-Salaam',
    'Qasr al-Nil',
    'Hadayek al-Kobba',
    '15 May City'
  ];
  List gizaR = [
    'Sheikh Zayed',
    'Faisal',
    'Dokki',
    'Haram',
    'Mohandessin',
    'West Somid',
    'Giza District',
    'Imbaba',
    'Moneeb',
    'Agouza',
    'Ard El Lewa',
    '6th of October',
    'Hadayek 6th of October',
    'Hadayek al-Ahram',
    'Boulaq Dakrour'
  ];

  void changeCity() {
    if (selectedCity == "Alexandria") {
      selectdReg = rAlex;
      update();
    } else if (selectedCity == "Cairo") {
      selectdReg = cairoR;
      update();
    } else {
      selectdReg = gizaR;
      update();
    }
  }

  void changeSize(double size) {
    selectedSize = size;
    update();
  }

  final picker = ImagePicker();

  Future<void> getImage(ImageSource source) async {
    if (selectedImages.length >= 6) {
      Fluttertoast.showToast(
          msg: "You can only select up to six photos.",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      return;
    }

    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      selectedImages.add(File(pickedFile.path));
      update();
    }
  }

  Future<void> uploadPosttest(
      String description,
      int price,
      String size,
      String? purpose,
      String? bedrooms,
      String? bathrooms,
      String region,
      String city,
      String floor,
      String condition,
      int status,
      int? ownerId,
      int renterId,
      int booked,
      List<File> images) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString(AppConstants.token);
    print(token);
    isLoadUpload = true;
    update();
    Map<String, String>? headers = {
      'Content-Type': 'application/json; charset=UTF-8',
      'Authorization': 'Bearer $token'
    };
    var uri = Uri.parse('${AppConstants.baseUrl}${AppConstants.uploadPostUrl}');
    var request = http.MultipartRequest('POST', uri);

    request.headers.addAll(headers);
    request.fields['description'] = description;
    request.fields['price'] = price.toString();
    request.fields['size'] = size;
    request.fields['purpose'] = purpose!;
    request.fields['bedrooms'] = bedrooms.toString();
    request.fields['bathrooms'] = bathrooms.toString();
    request.fields['region'] = region;
    request.fields['city'] = city;
    request.fields['floor'] = floor;
    request.fields['condition'] = condition;
    request.fields['status'] = "0";
    request.fields['owner_id'] = ownerId.toString();
    // request.fields['renterId'] = renterId.toString();
    // request.fields['booked'] = booked.toString();

    for (var image in images) {
      var stream = http.ByteStream(image.openRead());
      var length = await image.length();
      var multipartFile = http.MultipartFile('images[]', stream, length,
          filename: image.path.split('/').last);
      request.files.add(multipartFile);
    }
    var response = await request.send();
    print(response.statusCode);
    print(response);
    var responseData = await response.stream.bytesToString();
    print(responseData);
    if (response.statusCode == 201 || response.statusCode == 302) {
      isLoadUpload = false;
      update();

      Fluttertoast.showToast(
          msg: "Post uploaded successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      Get.back();
    } else {
      isLoadUpload = false;
      update();
      Fluttertoast.showToast(
          msg: "Failed to upload post",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  void UploadPost() async {
    print("***********************************************");
    print(priceField.text);
    print(yourDescription.text);
    print(selectedCondition);
    print(selectedFor);
    print(selectedBedrooms);
    print(selectedBathroom);
    print(selectedType);
    print(selectedSize.toStringAsFixed(2));
    print(selectedRegi);
    print("***********************************************");
    SharedPreferences prefs = await SharedPreferences.getInstance();

    uploadPosttest(
      yourDescription.text,
      double.parse(priceField.text).toInt(),
      selectedSize.toStringAsFixed(2).toString(),
      selectedFor,
      selectedBedrooms.toString(),
      selectedBathroom.toString(),
      selectedRegi!,
      selectedCity!,
      selectedFloor.toString(),
      selectedCondition!,
      1,
      prefs.getInt(AppConstants.userID),
      0,
      0,
      selectedImages,
    );
  }

  String result = '';

  Future<void> getPrediction() async {
    isLoadAi = true;
    update();
    final url = Uri.parse(
        'https://house-price-prediction-final-final-1.onrender.com/house_pred');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        "type": selectedType,
        "size": selectedSize.toInt(),
        "bedrooms": selectedBedrooms,
        "bathrooms": selectedBathroom,
        "floor": selectedFloor,
        "fur": selectedCondition == "Unfinished" ? "No" : "Yes",
        "region": selectedRegi,
        "city": selectedCity
      }),
    );
    print(response.body);
    if (response.statusCode == 200) {
      result = json.decode(response.body).toStringAsFixed(2).toString();
      priceField.text = result.toString();
      isLoadAi = false;
      update();
      print(result);
    } else {
      isLoadAi = false;
      update();
      result = 'Error: ${response.statusCode}';
    }
  }

  void showImagePickerOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return GetBuilder<UploadPostOwnerController>(
          init: UploadPostOwnerController(),
          builder: (controller) => SizedBox(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height / 4.5,
            child: Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        controller.getImage(ImageSource.gallery);
                      },
                      child:  SizedBox(
                        child: Column(
                          children: [
                            Icon(
                              Icons.image,
                              size: 70,
                              color: Color(0xff5E756D),
                            ),
                            Text(
                              "Gallery".tr,
                              style: TextStyle(
                                fontFamily: "Besley",
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        controller.getImage(ImageSource.camera);
                      },
                      child: const SizedBox(
                        child: Column(
                          children: [
                            Icon(
                              Icons.camera_alt,
                              size: 70,
                              color: Color(0xff5E756D),
                            ),
                            Text(
                              "Camera",
                              style: TextStyle(
                                fontFamily: "Besley",
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget buildImageContainer(File imageFile) {
    return GetBuilder<UploadPostOwnerController>(
      builder: (controller) => Container(
        width: 165,
        height: 175,
        margin: const EdgeInsets.only(left: 25, bottom: 10),
        decoration: BoxDecoration(
          color: const Color(0xffFFFFFF),
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [
            BoxShadow(
              color: Color(0xffbdc2bf),
              offset: Offset(2, 3),
            )
          ],
          image: DecorationImage(
            image: FileImage(imageFile),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            GestureDetector(
              onTap: () {
                controller.selectedImages.remove(imageFile);
                update();
              },
              child: Container(
                alignment: Alignment.topRight,
                padding: const EdgeInsets.all(5),
                child: const Icon(
                  Icons.cancel,
                  color: Color(0xffFF725E),
                  size: 20,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
