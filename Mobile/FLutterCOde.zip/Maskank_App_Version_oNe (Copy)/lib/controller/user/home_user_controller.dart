import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/favorite_screen_controller.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/data/model/house_model.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeUserController extends GetxController {
  List<House> houseList = <House>[];
  bool isLoading = true;
  bool isLoad = false;
  String? userName = "User Name";

  @override
  void onInit() {
    super.onInit();
    getInfo();
  }

  void addFavorite(int postId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response = await apiClient.postData(
        "${AppConstants.addFavoriteUrl}/$postId",
        {"renter_id": prefs.getInt(AppConstants.userID)});

    // Check the response status
    if (response.statusCode == 200) {
      print(response.body);
      Get.put(FavoriteController()).getInfo();
    } else {
      print(response.body);

      print("NO Data");
    }
  }

  getInfo() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    userName = prefs.getString(AppConstants.fullName);

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response = await apiClient
        .getData("${AppConstants.getHomeUserPostLoginUrl}?limit=5");

    // Check the response status
    if (response.statusCode == 200) {
      List<dynamic> jsonList = response.body;
      // Map each dynamic object to a House object using fromJson method
      houseList = jsonList.map((jsonItem) => House.fromJson(jsonItem)).toList();
      isLoad = false;
      update();
    } else {
      isLoad = false;
      update();
      Fluttertoast.showToast(
          msg: "Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
