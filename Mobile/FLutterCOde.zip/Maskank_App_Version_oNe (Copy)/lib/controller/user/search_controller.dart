import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/data/model/search_model.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SearchUserController extends GetxController {
  TextEditingController searchField = TextEditingController();
  List<SearchHouseModel> houseSearchList = [];
  bool isLoadSearch = false;
  String? selectedCity;
  String? selectedRegi;
  double selectedSize = 40;
  bool noSize = false;
  double selectedPrice = 0.0;
  List selectdReg = ["", ""];
  List rAlex = [
    'Kafr Abdo',
    'Seyouf',
    'Raml Station',
    'Moharam Bik',
    'Saba Pasha',
    'Miami',
    'Sporting',
    'Sidi Beshr',
    'Manshiyya',
    'Al Ibrahimiyyah',
    'Mandara',
    'Gianaclis',
    'Asafra',
    'Sidi Gaber',
    'Cleopatra',
    'Glim',
    'San Stefano',
    'Nakheel',
    'Azarita',
    'Zezenia',
    'Camp Caesar',
    'Al Hadrah',
    'Montazah',
    'Bolkly',
    'Fleming',
    'Maamoura',
    'Abu Qir',
    'Schutz',
    'Awayed',
    'Bahray - Anfoshy',
    'Ras El Tin',
    'Abu Talat',
    'Borg al-Arab',
    'Kabbary'
  ];

  List cairoR = [
    'Zahraa Al Maadi',
    'Nasr City',
    'Mostakbal City',
    'New Cairo - El Tagamoa',
    'New Capital City',
    'Madinaty',
    'Shorouk City',
    'New Nozha',
    'Rehab City',
    'Heliopolis',
    'Obour City',
    'Badr City',
    'Sheraton',
    'Helmeyat El Zaytoun',
    'Shubra',
    'Abasiya',
    'Downtown Cairo',
    'Salam City',
    'Katameya',
    'Gesr Al Suez',
    'Zamalek',
    'Helwan',
    'Al Manial',
    'Garden City',
    'Basateen',
    'Matareya',
    'Dar al-Salaam',
    'Qasr al-Nil',
    'Hadayek al-Kobba',
    '15 May City'
  ];
  List gizaR = [
    'Sheikh Zayed',
    'Faisal',
    'Dokki',
    'Haram',
    'Mohandessin',
    'West Somid',
    'Giza District',
    'Imbaba',
    'Moneeb',
    'Agouza',
    'Ard El Lewa',
    '6th of October',
    'Hadayek 6th of October',
    'Hadayek al-Ahram',
    'Boulaq Dakrour'
  ];

  void changeCity() {
    if (selectedCity == "Alexandria") {
      selectdReg = rAlex;
      update();
    } else if (selectedCity == "Cairo") {
      selectdReg = cairoR;
      update();
    } else {
      selectdReg = gizaR;
      update();
    }
  }

  void changeSize(double size) {
    selectedSize = size;
    update();
  }

  void noSizePro() {
    noSize = !noSize;
    // selectedSize = 0;
    update();
  }

  getSearchInfo() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response = await apiClient
        .getData("${AppConstants.searchPostUrl}?term=${searchField.text}");

    // Check the response status
    if (response.statusCode == 200) {
      List<dynamic> jsonList = response.body;
      houseSearchList =
          jsonList.map((json) => SearchHouseModel.fromJson(json)).toList();
      isLoadSearch = false;
      update();
    } else {
      print(response.body);
      isLoadSearch = false;
      update();
      Fluttertoast.showToast(
          msg: "Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  getFilterInfo() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Response response = await apiClient.getData(noSize
        ? "${AppConstants.filterPostUrl}?city=$selectedCity&size=&price=&bedrooms="
        : "${AppConstants.filterPostUrl}?city=$selectedCity&size=${selectedSize.toInt()}&price=&bedrooms=");

    // Check the response status
    if (response.statusCode == 200) {
      List<dynamic> jsonList = response.body['filteredPosts']['original'];
      houseSearchList =
          jsonList.map((json) => SearchHouseModel.fromJson(json)).toList();
    

      isLoadSearch = false;
      update();
    } else {
      print(response.body);
      isLoadSearch = false;
      update();
      Fluttertoast.showToast(
          msg: "Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}

  // api/search?term=masr

