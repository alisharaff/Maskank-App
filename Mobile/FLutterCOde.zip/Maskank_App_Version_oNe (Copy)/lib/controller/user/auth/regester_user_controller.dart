import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:maskank/view/screens/auth/user/login/login_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RegisterUserController extends GetxController {
  TextEditingController username = TextEditingController();
  TextEditingController fullname = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController phone = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  GlobalKey<FormState> registerUserFormKey = GlobalKey<FormState>();

  bool isRegister = false;
  bool isPasswordVisible = false;
  // -- Fun for add new user --
  void toggleVisibility() {
    isPasswordVisible = !isPasswordVisible;
    update();
  }

  void register() {
    if (registerUserFormKey.currentState!.validate()) {
      registerUser();
    }
  }

  void registerUser() async {
    isRegister = true;

    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();

    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Map<String, String> userData = {
      'username': username.text,
      'renter_name': fullname.text,
      'phone': phone.text,
      'password': password.text,
      'email': email.text,
      // 'photo': 'test.jpg',
    };

    Response response = await apiClient.postAuthData(
      AppConstants.registerUrl,
      userData,
    );
    
    if (response.statusCode == 200) {
      isRegister = false;    
      update();
      Fluttertoast.showToast(
          msg: "User registered successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      Get.to(() => const LoginPage());
    } else {
      isRegister = false;
      update();
      // if (response.body["message"] == "User already exists") {
      //   Fluttertoast.showToast(
      //       msg: "User already exists",
      //       toastLength: Toast.LENGTH_SHORT,
      //       gravity: ToastGravity.BOTTOM,
      //       timeInSecForIosWeb: 1,
      //       backgroundColor: Colors.red,
      //       textColor: Colors.white,
      //       fontSize: 16.0);
      // } else {
      //   Fluttertoast.showToast(
      //       msg: "Failed to register user",
      //       toastLength: Toast.LENGTH_SHORT,
      //       gravity: ToastGravity.BOTTOM,
      //       timeInSecForIosWeb: 1,
      //       backgroundColor: Colors.red,
      //       textColor: Colors.white,
      //       fontSize: 16.0);
      // }
    }
  }
}
