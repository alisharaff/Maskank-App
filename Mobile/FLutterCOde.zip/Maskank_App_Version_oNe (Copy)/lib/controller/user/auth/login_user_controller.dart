import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:maskank/data/api/api_client.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:maskank/view/base/butNavBar/but_nav_bar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoginUserController extends GetxController {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  GlobalKey<FormState> loginUserformKey = GlobalKey<FormState>();
  bool isVisible = false;
  bool isLogin = false;

  void toggleVisibility() {
    isVisible = !isVisible;
    update();
  }

  void login() {
    if (loginUserformKey.currentState!.validate()) {
      loginUser();
    }
  }

  void loginUser() async {
    isLogin = true;
    update();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ApiClient apiClient = ApiClient(
      appBaseUrl: AppConstants.baseUrl,
      sharedPreferences: prefs,
    );

    Map<String, dynamic> userData = {
      'username': username.text,
      'password': password.text,
    };

    Response response =
        await apiClient.postAuthData(AppConstants.loginUrl, userData);

    // Check the response status
    if (response.statusCode == 200) {
      prefs.setString(AppConstants.token, response.body["token"]);
      prefs.setString(AppConstants.userName, response.body["data"]["username"]);
      prefs.setInt(AppConstants.userID, response.body["data"]["renter_id"]);
      prefs.setString(AppConstants.userPhone, response.body["data"]["phone"]);
      prefs.setString(
          AppConstants.fullName, response.body["data"]["renter_name"]);
      prefs.setString(AppConstants.userEmail, response.body["data"]["email"]);

      isLogin = false;
      update();
      Fluttertoast.showToast(
          msg: "User Login successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
      Get.to(() => MyNavBar());
    } else {
      isLogin = false;
      update();
      Fluttertoast.showToast(
          msg: "User Not Found",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }
}
