import 'package:get/get.dart';
import 'package:maskank/controller/user/favorite_screen_controller.dart';

class BottomNavBarController extends GetxController {
  var selectedIndex = 0.obs;

  void onItemTapped(int index) {
    Get.put(FavoriteController());
    selectedIndex.value = index;
  }
}
