import 'package:flutter/material.dart';
import 'package:maskank/maskank.dart';

void main() {
  runApp(const MaskankApp());
}
