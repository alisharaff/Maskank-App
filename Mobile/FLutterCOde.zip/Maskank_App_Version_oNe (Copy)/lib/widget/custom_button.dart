import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  final Color color;

  const CustomButton({
    Key? key,
    required this.title,
    required this.onTap,
    this.color = const Color(0XFFFF725E), // Default color
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
        ),
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontFamily: "Cairo",
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
