import 'package:get/get.dart';

class MyLocale implements Translations {
  @override
  // TODO: implement keys
  Map<String, Map<String, String>> get keys => {
        "ar": {
          "CHOOSE_YOUR_OWN_PLACE": "اختر مكانك الخاص",
          //Onboarding-1
          "Choose_Your_place": "اختر مكانك",
          "we_have_everything_you_need":
              "لدينا كل ما تحتاجه، اختر مكانك في متجرنا",
          "skip": "تخطي",
          "next": "التالي",
          "done": "انتهاء",
          //Onboarding-2
          "Easy_and_save_your_money": "سهلة وتوفير أموالك",
          "We_can_make_it_easy_for_you_to_find_the_place_lowest_possible_price":
              "يمكننا أن نسهل عليك العثور على المكان بأقل سعر ممكن",
          //Onboarding-3
          "Easy_way_to_deal": "طريقة سهلة للتعامل",
          "Good_communication_Save_your_time_with_the_click_of_a_button.":
              "التواصل الجيد وفر وقتك بنقرة زر واحدة.",
          //Select Role
          "Choose_Your_Role": "اختر دورك",
          "user": "مستأجر",
          "owner": "ماللك",
          "Searching_for_Apartments_Reviewing_Apartments_Communicating_with_Owners_or_Agents_Booking_and_Leasing_and_Interacting_with_Customer_Service":
              "البحث عن الشقق، مراجعة الشقق، التواصل مع المالكين أو الوكلاء، الحجز والتأجير، والتفاعل مع خدمة العملاء.",
          "Listing_Properties_Managing_Inquiries_Scheduling_Viewings_Reviewing_Applications_Handling_Lease_Agreements_Financial_Transactions_and_Communicating_with_Tenants":
              "إدراج العقارات وإدارة الاستفسارات وجدولة العروض ومراجعة الطلبات والتعامل مع اتفاقيات الإيجار والمعاملات المالية والتواصل مع المستأجرين",
          //Login
          "User_name": "اسم المستخدم",
          "Password": "كلمة السر",
          "Login": "تسجيل الدخول",
          "Log_In": "تسجيل الدخول",
          "Don’t_have_an_account": "ليس لديك حساب",
          "SIGN_UP": "انشاء حساب",
          //Sign up
          "Register": "انشاء حساب",
          "Full_name": "الاسم الكامل",
          "email": "البريد الالكتروني",
          "Phone": "رقم التليفون",
          "Confirm_Password": "تأكيد كلمة السر",
          "Already_have_an_accoun": "لديك حساب بالفعل",
          //SCAN-1
          "Scan_Your_ID": "قم بمسح هويتك ضوئيًا",
          "Now_place_your_phone_directly_on_top_of_your_id_photo_so_we_can_connect_securely":
              "الآن ضع هاتفك مباشرة أعلى صورة هويتك حتى نتمكن من الاتصال بشكل آمن",
          "Position_your_photo_inside_the_box": "ضع صورتك داخل الصندوق",
          "Scan_Now": "إفحص الآن",
          //SCAN
          "Now_place_your_phone_directly_on_top_of_your_id_photo_so_we_can_connect_securely_to_your_ID_photo":
              "الآن ضع هاتفك مباشرة أعلى صورة هويتك، حتى نتمكن من الاتصال بشكل آمن بصورة هويتك",
          "Gallery":"المعرض",
          "Camera":"الكاميرا",
          //Verification
          "Verification_Success": "نجاح التحقق",
          "Congrats_your_identity_successfully_verified":
              "تهانينا لقد تم التحقق من هويتك بنجاح",
          "Continue": "استمرار",

          //booking
          "Dear_this_place_is_dedicated_to_following_up_on_the_rental_status_and_when_the_apartment_owner_agrees_you_can_view_his_information_and_contact_him":
              "عزيزي، هذا المكان مخصص لمتابعة الحالة الإيجارية، وعندما يوافق صاحب الشقة يمكنك الاطلاع على بياناته والتواصل معه.",
          "Status_of_request": "حالة الطلب",
          "Your_Requests_here!": "طلباتك هنا!",
          //favourite
          "Dear_this_place_is_dedicated_to_important_posts_that_you_like_and_you_can_delete_a_post_from_here_by_clicking_on_the_heart.":
              "عزيزي هذا المكان مخصص للمشاركات المهمة التي تعجبك ويمكنك حذف مشاركة من هنا بالضغط على القلب.",
          "Favorite_Posts": "المشاركات المفضلة",
          "Yor_Favorite_Posts_here!": "مشاركاتك المفضلة هنا!",

          //home user
          "Search_for_real_state": "ابحث عن العقارات",
          "to_suite_any_taste": "التي تناسب أي ذوق",
          "Explore": "اكتشاف",
          "Recent_searches": "عمليات البحث الأخيرة",
          "Popular_places": "أماكن شائعه",
          "View_all": "عرض الكل",
          "Hello":"مرحبا",
          //appartement detaile
          "Dear_Renter_we_are_happy_that_you_are_using_the_Maskanak_application_now":
              "عزيزي المستأجر، يسعدنا أنك تستخدم تطبيق مسكنك الآن. مع العلم أنه لا يسمح بالاطلاع على بيانات صاحب الشقة أو التواصل معه إلا بعد موافقته على هذا الطلب.",
          "Amenities": "وسائل الراحة",
          "Book": "حجز",
          "Details": "تفاصيل",
          "search_Apartment_building_etc": "البحث عن شقة، مبنى، الخ",
          "Recommendations": "مقترحات",
          //filter
          "Apply_Filter":"تطبيق الفلتر",
          "Your_Filter":"الفلتر الخاص بك",
          "close":"إغلاق",
          "Student":"طالب ؟",
          "Any":"أي",
          "Personal":"شخصي",
          "student":"طالب",
          "Buy_or_rent?": "شراء أو الإيجار؟",
          "Apartment":"شقه",
          "Studio":"استوديو",
          "Duplex":"دوبلكس",
          "Property_Type": "نوع العقار",
          "Choose_your_city":"اختر مدينتك",
          "Alexandria":"الاسكندريه",
          "Cairo":"القاهره",
          "Giza":"الجيزه",
          "Your_budget":"ميزانيتك",
          "Property_Price": "سعر العقار",
          "Bedrooms": "غرف نوم",
          "Bathrooms": "الحمامات",
          "Furnishing": "الاثاث",
          "Beds": "سرير",
          "Property_Size": "حجم العقار",
          "All":"كل",
          "You_Want_All_Size":"تريد كل الحجم",
          //search
          "Exploer":"استكشاف",
          "Search Apartment":"البحث عن شقه",
          "OOPS, No Data!":"عفوًا، لا توجد بيانات!",
          //profile
          "Your_name": "اسم المستخدم",
          "Your_e-mail": "البريد الالكتروني",
          "Phone_number": "رقم التليفون",
          "Your_location": "العنوان",
          "Edit_profile": "تعديل",
          "Log_out": "تسجيل الخروج",
          "Save": "حفظ",
          //home owner
          "Total_information_of_deal": "المعلومات الإجمالية للتعاملات",
          "Done_deal": "التعاملات المنهيه",
          "Waiting_deal": "التعاملات المنتظره",
          "You_can_upload_from_here": "يمكنك التحميل من هنا",
          "Upload_your_apartment": "قم بتحميل شقتك",
          "location":"الموقع",
          //approved screen
          "Your_Approved_posts": "مشاركاتك المعتمدة",
          //details user request
          "User_Requests":"طلبات المستخدم",
          //upload screen
          "Choose_your_region":"اختر منطقتك",
          "Write_Your_location": "اكتب موقعك",
          "Price": "السعر",
          "For?": "لمن؟",
          "Apartment_features": "مميزات الشقة",
          "Apartment_Condition": "حالة الشقة",
          "Finished": "مفروشه",
          "Unfinished": "غير مفروشه",
          "Super_lux": "سوبر لوكس",
          "Description":"الوصف",
          "Write Your Description":"اكتب وصفك",
          "Upload": "رفع",
          "Size":"المساحه",
          "Dear apartment owner, we use artificial intelligence to determine a fair price for the apartment.":"عزيزي مالك الشقة، نستخدم الذكاء الاصطناعي لتحديد السعر العادل للشقة.",
       "Type the right price for your apartment":"اكتب السعر المناسب لشقتك",
       "Dear, in order to use artificial intelligence, you must fill all the fields first.":"عزيزي، لتتمكن من استخدام الذكاء الاصطناعي، عليك ملء جميع الحقول أولاً.",
       "Use AI":"استخدم الAI",
       "Floor":"الطابق",
       "Dear, you must fill all the fields first.":"عزيزي، يجب عليك ملء جميع الحقول أولاً.",
       "Use Ai to determine a fair price.":"استخدم Ai لتحديد السعر العادل.",
        },
        "en": {
          "CHOOSE_YOUR_OWN_PLACE": "CHOOSE YOUR OWN PLACE",
          //Onboarding-1
          "Choose_Your_place": "Choose Your place",
          "we_have_everything_you_need":
              "We have everything you need, choose your place in our application",
          "skip": "Skip",
          "next": "Next",
          "done": "Done",
          //Onboarding-2
          "Easy_and_save_your_money": "Easy and save your money",
          "We_can_make_it_easy_for_you_to_find_the_place_lowest_possible_price":
              "We can make it easy for you to find the place lowest possible price",
          //Onboarding-3
          "Easy_way_to_deal": "Easy way to deal",
          "Good_communication_Save_your_time_with_the_click_of_a_button.":
              "Good communication Save your time with the click of a button.",
          //Select Role
          "Choose_Your_Role": "Choose Your Role",
          "user": "User",
          "owner": "Owner",
          "Searching_for_Apartments_Reviewing_Apartments_Communicating_with_Owners_or_Agents_Booking_and_Leasing_and_Interacting_with_Customer_Service":
              "Searching for Apartments, Reviewing Apartments, Communicating with Owners or Agents, Booking and Leasing, and Interacting with Customer Service.",
          "Listing_Properties_Managing_Inquiries_Scheduling_Viewings_Reviewing_Applications_Handling_Lease_Agreements_Financial_Transactions_and_Communicating_with_Tenants":
              "Listing Properties, Managing Inquiries, Scheduling Viewings, Reviewing Applications, Handling Lease Agreements, Financial Transactions, and Communicating with Tenants",

          //Login
          "User_name": "User name",
          "Password": "Password",
          "Login": "Login",
          "Log_In": "Log In ",
          "Don’t_have_an_account": "Don’t have an account",
          "SIGN_UP": "SIGN UP",

          //Sign up
          "Register": " Register",
          "Full_name": "Full name",
          "email": "Email",
          "Phone": "Phone",
          "Confirm_Password": "Confirm Password",
          "Already_have_an_accoun": "Already have an accoun",
          //SCAN-1
          "Scan_Your_ID": "Scan Your ID",
          "Now_place_your_phone_directly_on_top_of_your_id_photo_so_we_can_connect_securely":
              "Now place your phone directly on top of your id photo so we can connect securely",
          "Position_your_photo_inside_the_box":
              "Position your photo inside the box",
          "Scan_Now": "Scan Now",
          "Gallery":"Gallery",
          "Camera":"Camera",
          //SCAN
          "Now_place_your_phone_directly_on_top_of_your_id_photo_so_we_can_connect_securely_to_your_ID_photo":
              "Now place your phone directly on top of your ID photo, so we can connect securrely to your ID photo.",
          //Verification
          "Verification_Success": "Verification Success",
          "Congrats_your_identity_successfully_verified":
              "Congrats your identity successfully verified",
          "Continue": "Continue",

          //home user

          "Search_for_real_state": "Search for real state",
          "to_suite_any_taste": "to suite any taste",
          "Explore": "Explore",
          "Recent_searches": "Recent searches",
          "Popular_places": "Popular places",
          "View_all": "View all",
          "Hello":"Hello",
//booking
          "Dear_this_place_is_dedicated_to_following_up_on_the_rental_status_and_when_the_apartment_owner_agrees_you_can_view_his_information_and_contact_him":
              "Dear, this place is dedicated to following up on the rental status, and when the apartment owner agrees, you can view his information and contact him.",
          "Status_of_request": "Status of  request",
          "Your_Requests_here!": "Your Requests here!",
          //FAVOURITE
          "Dear_this_place_is_dedicated_to_important_posts_that_you_like_and_you_can_delete_a_post_from_here_by_clicking_on_the_heart.":
              "Dear, this place is dedicated to important posts that you like, and you can delete a post from here by clicking on the heart.",
          "Favorite_Posts": "Favorite Posts",
          "Yor_Favorite_Posts_here!": "Yor Favorite Posts here!",
          //appartement detaile
          "Dear_Renter_we_are_happy_that_you_are_using_the_Maskanak_application_now":
              "Dear Renter, we are happy that you are using the Maskanak application now. Please note that the information of the apartment owner is not allowed to be viewed or communicated with him unless he approves this request.",
          "Amenities": "Amenities",
          "Book": "Book",
          "Details": "Details",
          "search_Apartment_building_etc": "search Apartment,building,etc",
          "Recommendations": "Recommendations",
          //filter
          "Apply_Filter":"Apply Filter",
          "Your_Filter":"your Filter",
          "close":"Close",
          "Student":"Student ?",
          "Any":"Any",
          "Personal":"Personal",
          "student":"Student",
          "Buy_or_rent?": "Buy or rent?",
          "Apartment":"Apartment",
          "Studio":"Studio",
          "Duplex":"Duplex",
          "Property_Type": "Property Type",
          "Choose_your_city":"Choose Your City",
          "Alexandria":"Alexandria",
          "Cairo":"Cairo",
          "Giza":"Giza",
          "Your_budget":"Your budget",
          "Property_Price": "Property Price",
          "Bedrooms": "Bedrooms",
          "Bathrooms": "Bathrooms",
          "Furnishing": "Furnishing",
          "Beds": "Beds",
          "Property_Size": "Property Size",
          "All":"All",
          "You_Want_All_Size":"You Want All Size",
          //search
          "Exploer":"Exploer",
          "Search Apartment":"Search Apartment",
          "OOPS, No Data!":"OOPS, No Data!",
          //profile
          "Your_name": "Your name",
          "Your_e-mail": "Your e-mail",
          "Phone_number": "Phone number",
          "Your_location": "Your location",
          "Edit_profile": "Edit profile",
          "Log_out": " Log Out",
          "Save": "Save",

          //home owner
          "Total_information_of_deal": "Total information of deal",
          "Done_deal": "Done deal",
          "Waiting_deal": "Waiting deal",
          "You_can_upload_from_here": "You can upload from here",
          "Upload_your_apartment": "Upload your apartment",
          //approved screen
          "Your_Approved_posts": "Your Approved posts",
          //details user request
          "User_Requests":"User Requests",
          //upload screen
          "Choose_your_region":"Choose your region",
          "location": "location",
          "Write_Your_location": "Write Your location",
          "Price": "Price",
          "For?": "For?",
          "Apartment_features": "Apartment features",
          "Apartment_Condition": "Apartment Condition",
          "Finished": "Finished",
          "Unfinished": "Unfinished ",
          "Super_lux": "Super lux",
          "Description":"Description",
          "Write Your Description":"Write Your Description",
          "Upload": "Upload",
          "Size":"Size",
          "Dear apartment owner, we use artificial intelligence to determine a fair price for the apartment.":"Dear apartment owner, we use artificial intelligence to determine a fair price for the apartment.",
          "Type the right price for your apartment":"Type the right price for your apartment",
          "Dear, in order to use artificial intelligence, you must fill all the fields first.":"Dear, in order to use artificial intelligence, you must fill all the fields first.",
          "Use AI":"Use AI",
          "Floor":"Floor",
          "Dear, you must fill all the fields first.":"Dear, you must fill all the fields first.",
          "Use Ai to determine a fair price.":"Use Ai to determine a fair price.",
        },
      };
}
