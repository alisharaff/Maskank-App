import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/helper/get_di.dart';
import 'package:maskank/locale/locale/locale.dart';
import 'package:maskank/locale/locale/locale_controller.dart';

import 'package:maskank/view/base/noConeection/no_coneection.dart';
import 'package:maskank/view/screens/splash/splash_screen.dart';
import 'package:maskank/view/screens/user/booking/booking_screen.dart';
import 'package:maskank/view/screens/user/favorite/favorite_screen.dart';
import 'package:maskank/view/screens/user/home/filter/filter_screen.dart';

class MaskankApp extends StatefulWidget {
  const MaskankApp({super.key});

  @override
  State<MaskankApp> createState() => _MaskankAppState();
}

class _MaskankAppState extends State<MaskankApp> {
  late bool _isConnected = false;

  @override
  void initState() {
    super.initState();
    init();
    _checkConnectivity();
    Connectivity().onConnectivityChanged.listen((result) {
      setState(() {
        _isConnected = result != ConnectivityResult.none;
      });
    });
  }

  Future<void> _checkConnectivity() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    setState(() {
      _isConnected = connectivityResult != ConnectivityResult.none;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Get.put(MyLocaleController());
    return GetMaterialApp(
      title: 'Maskank App',
      locale: Get.deviceLocale,
      translations: MyLocale(),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        // body: FilterScreen(),
        body: _isConnected ? const SplashScreen() : const NoConnection(),
      ),
    );
  }
}
//MyNavBar(), //splashScreen(),OwnerMyNavBar()