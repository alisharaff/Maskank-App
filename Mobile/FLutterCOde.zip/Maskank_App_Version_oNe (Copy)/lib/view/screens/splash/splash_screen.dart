import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:maskank/util/app_constants.dart';
import 'package:maskank/view/base/butNavBar/but_nav_bar.dart';
import 'package:maskank/view/base/butNavBar/owner_nav_bar.dart';

import 'package:maskank/view/screens/onBoarding/onboarding_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../util/images.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  void _checkToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString(AppConstants.token);
    String? type = prefs.getString(AppConstants.type);

    if (token != null) {
      if (type == "Owner") {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => OwnerMyNavBar()),
          );
        });
      } else {
        Timer(const Duration(seconds: 3), () {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => MyNavBar()),
          );
        });
      }
    } else {
      Timer(const Duration(seconds: 3), () {
        // If token does not exist, navigate to login screen
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const OnBoarding()),
        );
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _checkToken();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xffEEE1D8), Color(0xffDBA690)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft)),
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Column(
                children: [
                  Image.asset(
                    AppImages.logo,
                  ),
                   Text(
                    'CHOOSE_YOUR_OWN_PLACE'.tr,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xffD15000),
                      fontSize: 16,
                      fontFamily: 'Besley',
                    ),
                  ),
                ],
              ),
              LoadingAnimationWidget.waveDots(
                color: const Color(0xffDBA690),
                size: 80,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
