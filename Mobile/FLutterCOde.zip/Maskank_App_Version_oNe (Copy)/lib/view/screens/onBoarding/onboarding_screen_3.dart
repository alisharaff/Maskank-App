import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../util/images.dart';

class OnBoardingThree extends StatelessWidget {
  const OnBoardingThree({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(color: Color(0xffEAF0EC)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              AppImages.onBoardingThree,
              width: 350,
              height: 430,
            ),
             Text(
              'Easy_way_to_deal'.tr,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xff263238),
                fontSize: 36,
                fontFamily: 'Berkshire Swash',
              ),
            ),
             Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Good_communication_Save_your_time_with_the_click_of_a_button.'.tr,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xff5F696C),
                  fontSize: 18,
                  fontFamily: 'Besley',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
