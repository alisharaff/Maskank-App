import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../util/images.dart';

class OnBoardingTwo extends StatelessWidget {
  const OnBoardingTwo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(color: Color(0xffEAF0EC)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              AppImages.onBoardingTwo,
              width: 350,
              height: 430,
            ),
             Text(
              'Easy_and_save_your_money'.tr,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xff263238),
                fontSize: 31,
                fontFamily: 'Berkshire Swash',
              ),
            ),
             Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'We_can_make_it_easy_for_you_to_find_the_place_lowest_possible_price'.tr,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xff5F696C),
                  fontSize: 18,
                  fontFamily: 'Besley',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
