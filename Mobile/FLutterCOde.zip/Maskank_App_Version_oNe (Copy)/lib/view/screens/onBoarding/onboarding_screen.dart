import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/view/screens/selectRole/role.dart';
import 'package:maskank/view/screens/onBoarding/onboarding_screen_1.dart';
import 'package:maskank/view/screens/onBoarding/onboarding_screen_2.dart';
import 'package:maskank/view/screens/onBoarding/onboarding_screen_3.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class OnBoarding extends StatefulWidget {
  const OnBoarding({super.key});


  @override
  State<OnBoarding> createState() => _OnBoardingState();
}

class _OnBoardingState extends State<OnBoarding> {
  
  bool onlastpage = false;
  @override
  Widget build(BuildContext context) {
      PageController controller = PageController();
    return Scaffold(
      backgroundColor: const Color(0xffEAF0EC),
      body: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height / 1.1,
            child: PageView(
              onPageChanged: (index) {
                setState(() {
                  onlastpage = (index == 2);
                });
              },
              controller: controller,
              children: const [
                OnBoardingOne(),
                OnBoardingTwo(),
                OnBoardingThree(),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                //skip
                GestureDetector(
                    onTap: () {
                      controller.jumpToPage(2);
                    },
                    child:  Text(
                      'skip'.tr,
                      style: const TextStyle(
                          fontSize: 15,
                          fontFamily: 'Besley',
                          color: Color(0xff263238)),
                    )),
                //next
                onlastpage
                    ? GestureDetector(
                        onTap: () {
                          Get.to(()=>const RolePage());
                          
                        },
                        child:  Text(
                          'done'.tr,
                          style: const TextStyle(
                              fontSize: 15,
                              fontFamily: 'Besley',
                              color: Color(0xff263238)),
                        ))
                    : GestureDetector(
                        onTap: () {
                          controller.nextPage(
                              duration: const Duration(milliseconds: 500),
                              curve: Curves.easeIn);
                        },
                        child:  Text(
                          'next'.tr,
                          style: const TextStyle(
                              fontSize: 15,
                              fontFamily: 'Besley',
                              color: Color(0xff263238)),
                        )),
              ],
            ),
          ),
          Container(
            alignment: const Alignment(0, 0.90),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SmoothPageIndicator(
                  controller: controller,
                  count: 3,
                  effect: const ExpandingDotsEffect(
                    spacing: 8.0,
                    radius: 20.0,
                    dotColor: Color(0xffCFE2D5),
                    activeDotColor: Color(0xff486C4B),
                    dotHeight: 12.0,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
