import 'package:flutter/material.dart';
import 'dart:io';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:group_button/group_button.dart';
import 'package:maskank/controller/owner/upload_post_controller.dart';
import 'package:maskank/util/colors.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

class UploaScreen extends StatelessWidget {
  const UploaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManager.mainLightGreen,
      body: GetBuilder<UploadPostOwnerController>(
        init: UploadPostOwnerController(),
        builder: (controller) => ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: const Icon(
                      FontAwesomeIcons.angleLeft,
                      color: Color(0xff5E756D),
                    ),
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                   Text(
                    'Upload_your_apartment'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  children: [
                    ...controller.selectedImages.map(
                      (File imageFile) {
                        return controller.buildImageContainer(imageFile);
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 25),
                      child: GestureDetector(
                        onTap: () {
                          controller.showImagePickerOptions(context);
                        },
                        child: Container(
                          alignment: Alignment.center,
                          width: 165,
                          height: 175,
                          decoration: BoxDecoration(
                            color: const Color(0xffFFFFFF),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xffbdc2bf),
                                  offset: Offset(2, 3))
                            ],
                          ),
                          child: Center(
                            child: SvgPicture.asset(
                              'assets/images/Plus.svg',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text(
                    'location'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: DropdownButtonFormField(
                        decoration: InputDecoration(
                          hintText: 'Choose_your_city'.tr,
                          hintStyle: const TextStyle(
                            color: Color(0xffABAC9C),
                            fontSize: 22,
                            fontFamily: 'Besley',
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide:
                                const BorderSide(color: Color(0xffffffff)),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide:
                                const BorderSide(color: Color(0xffffffff)),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                        ),
                        icon: const Padding(
                          padding: EdgeInsets.only(right: 10),
                          child: Image(
                            image: AssetImage(
                              'assets/images/arrow down.jpg',
                            ),
                          ),
                        ),
                        value: controller.selectedCity,
                        items: ['Alexandria'.tr, 'Cairo'.tr, 'Giza'.tr].map(
                          (value) {
                            return DropdownMenuItem(
                              value: value,
                              child: Container(
                                padding: const EdgeInsets.only(left: 20),
                                child: Text(
                                  value,
                                  style: TextStyle(
                                    color: controller.selectedCity == value
                                        ? const Color(0xffFF725E)
                                        : const Color(0xffABAC9C),
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                            );
                          },
                        ).toList(),
                        onChanged: (newValue) {
                          controller.selectedCity = newValue;
                          controller.changeCity();
                        },
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: DropdownButtonFormField(
                        decoration: InputDecoration(
                          hintText: 'Choose_your_region'.tr,
                          hintStyle: const TextStyle(
                            color: Color(0xffABAC9C),
                            fontSize: 22,
                            fontFamily: 'Besley',
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide:
                                const BorderSide(color: Color(0xffffffff)),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide:
                                const BorderSide(color: Color(0xffffffff)),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                        ),
                        icon: const Padding(
                          padding: EdgeInsets.only(right: 10),
                          child: Image(
                            image: AssetImage(
                              'assets/images/arrow down.jpg',
                            ),
                          ),
                        ),
                        value: controller.selectedRegi,
                        items: controller.selectdReg.map(
                          (value) {
                            return DropdownMenuItem(
                              value: value,
                              child: MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: Container(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: Text(
                                    value,
                                    style: TextStyle(
                                      color: controller.selectedRegi == value
                                          ? const Color(0xffFF725E)
                                          : const Color(0xffABAC9C),
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                                onEnter: (_) {
                                  (context.findRenderObject() as RenderBox)
                                      .markNeedsPaint();
                                },
                                onExit: (_) {
                                  (context.findRenderObject() as RenderBox)
                                      .markNeedsPaint();
                                },
                              ),
                            );
                          },
                        ).toList(),
                        onChanged: (newValue) {
                          controller.selectedRegi = newValue as String?;
                        },
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                       Text(
                        'Size'.tr,
                        style: const TextStyle(
                            color: Color(0xff5E756D),
                            fontFamily: 'Besley',
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        controller.selectedSize.toStringAsFixed(2).toString(),
                        style: const TextStyle(
                            color: Color(0xff5E756D),
                            fontFamily: 'Besley',
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  SfSlider(
                    inactiveColor: ColorsManager.moreLightGray,
                    activeColor: ColorsManager.mainOrange,
                    min: 30.0,
                    max: 1000.0,
                    value: controller.selectedSize,
                    interval: 150,
                    showTicks: true,
                    showLabels: true,
                    enableTooltip: true,
                    minorTicksPerInterval: 1,
                    onChanged: (dynamic value) {
                      controller.changeSize(value);
                    },
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                       Text(
                        'Price'.tr,
                        style: const TextStyle(
                            color: Color(0xff5E756D),
                            fontFamily: 'Besley',
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      IconButton(
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  icon: const Icon(
                                    Icons.info_rounded,
                                    size: 40,
                                    color: ColorsManager.mainOrange,
                                  ),
                                  content:  Text(
                                    'Dear apartment owner, we use artificial intelligence to determine a fair price for the apartment.'.tr,
                                    style: const TextStyle(
                                      color: ColorsManager.gray,
                                      fontFamily: 'Besley',
                                      fontSize: 18,
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                      child: const Text(
                                        'OK',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'Besley',
                                          fontSize: 14,
                                        ),
                                      ),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                    ),
                                  ],
                                );
                              },
                            );
                          },
                          icon: const Icon(
                            Icons.info_outline_rounded,
                            size: 20,
                            color: ColorsManager.mainOrange,
                          ))
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Container(
                      padding: const EdgeInsets.only(left: 20, top: 0),
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.white,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 2,
                            child: TextFormField(
                              controller: controller.priceField,
                              style: const TextStyle(
                                color: Color(0xffABAC9C),
                                fontFamily: 'Besley',
                                fontSize: 14,
                              ),
                              decoration:  InputDecoration(
                                border: InputBorder.none,
                                hintText:
                                    "Type the right price for your apartment".tr,
                                hintStyle: const TextStyle(
                                    fontFamily: 'Besley',
                                    color: Color(0xffABAC9C),
                                    fontSize: 13),
                              ),
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width / 3,
                            height: 60,
                            decoration: BoxDecoration(
                                color: ColorsManager.mainOrange,
                                borderRadius: BorderRadius.circular(30)),
                            child: controller.isLoadAi == false
                                ? InkWell(
                                    onTap: () {
                                      if (controller.selectedImages.isNotEmpty &&
                                          controller.selectedCondition !=
                                              null &&
                                          controller.yourDescription.text
                                              .isNotEmpty &&
                                          controller.selectedFor != null) {
                                        controller.getPrediction();
                                      } else {
                                        // Show error message if any field is empty
                                        showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return AlertDialog(
                                              icon: const Icon(
                                                Icons.error,
                                                size: 40,
                                                color: ColorsManager.mainOrange,
                                              ),
                                              content:  Text(
                                                'Dear, in order to use artificial intelligence, you must fill all the fields first.'.tr,
                                                style: const TextStyle(
                                                  color: ColorsManager.gray,
                                                  fontFamily: 'Besley',
                                                  fontSize: 20,
                                                ),
                                              ),
                                              actions: <Widget>[
                                                TextButton(
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  },
                                                  child: const Text(
                                                    'OK',
                                                    style: TextStyle(
                                                      color: Colors.black,
                                                      fontFamily: 'Besley',
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            );
                                          },
                                        );
                                      }
                                    },
                                    child:  Text(
                                      'Use AI'.tr,
                                      style: const TextStyle(
                                          color: Color(0xffFFFFFF),
                                          fontFamily: 'Berkshire Swash',
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                      textAlign:
                                          TextAlign.center, // Text weight
                                    ),
                                  )
                                : const Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Center(
                                        child: CircularProgressIndicator(
                                      color: ColorsManager.gray,
                                    )),
                                  ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                   Text(
                    'For?'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    color: ColorsManager.mainLightGreen,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: GroupButton(
                        buttons:  ['Any'.tr, 'Student'.tr, 'Personal'.tr],
                        isRadio: true,
                        onSelected: (value, index, isSelected) {
                          if (isSelected) {
                            controller.selectedFor =
                                ['Any', 'Student', 'Personal'][index];
                          }
                        },
                        options: GroupButtonOptions(
                          spacing: 15,
                          selectedColor: const Color(0xffFF725E),
                          borderRadius: BorderRadius.circular(10),
                          selectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xffFFFFFF),
                            fontSize: 16,
                          ),
                          unselectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xff000000),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                   Text(
                    'Bedrooms'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    color: ColorsManager.mainLightGreen,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            GroupButton(
                              buttons: const [1, 2, 3, 4, 5, 6, 7],
                              isRadio: true,
                              onSelected: (value, index, isSelected) {
                                controller.selectedBedrooms = value;
                              },
                              options: GroupButtonOptions(
                                direction: Axis.horizontal,
                                spacing: 15,
                                selectedColor: const Color(0xffFF725E),
                                borderRadius: BorderRadius.circular(10),
                                selectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xffFFFFFF),
                                  fontSize: 16,
                                ),
                                unselectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xff000000),
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                   Text(
                    'Bathrooms'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    color: ColorsManager.mainLightGreen,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            GroupButton(
                              buttons: const [1, 2, 3, 4, 5, 6, 7],
                              isRadio: true,
                              onSelected: (value, index, isSelected) {
                                controller.selectedBathroom = value;
                              },
                              options: GroupButtonOptions(
                                direction: Axis.horizontal,
                                spacing: 15,
                                selectedColor: const Color(0xffFF725E),
                                borderRadius: BorderRadius.circular(10),
                                selectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xffFFFFFF),
                                  fontSize: 16,
                                ),
                                unselectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xff000000),
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                   Text(
                    'Floor'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    color: ColorsManager.mainLightGreen,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            GroupButton(
                              buttons: const [1, 2, 3, 4, 5, 6, 7],
                              isRadio: true,
                              onSelected: (value, index, isSelected) {
                                controller.selectedBathroom = value;
                              },
                              options: GroupButtonOptions(
                                direction: Axis.horizontal,
                                spacing: 15,
                                selectedColor: const Color(0xffFF725E),
                                borderRadius: BorderRadius.circular(10),
                                selectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xffFFFFFF),
                                  fontSize: 16,
                                ),
                                unselectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xff000000),
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                   Text(
                    'Property_Type'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Container(
                    color: ColorsManager.mainLightGreen,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            GroupButton(
                              buttons:  [
                                'Any'.tr,
                                'Apartment'.tr,
                                'Studio'.tr,
                                'Duplex'.tr,
                              ],
                              isRadio: true,
                              onSelected: (value, index, isSelected) {
                                controller.selectedType = value;
                              },
                              options: GroupButtonOptions(
                                direction: Axis.horizontal,
                                spacing: 15,
                                selectedColor: const Color(0xffFF725E),
                                borderRadius: BorderRadius.circular(10),
                                selectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xffFFFFFF),
                                  fontSize: 16,
                                ),
                                unselectedTextStyle: const TextStyle(
                                  fontFamily: 'Besley',
                                  color: Color(0xff000000),
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                   Text(
                    'Apartment_features'.tr,
                    style: const TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffffffff),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: DropdownButtonFormField(
                        decoration: InputDecoration(
                          hintText: 'Apartment_Condition'.tr,
                          hintStyle: const TextStyle(
                            color: Color(0xffABAC9C),
                            fontSize: 22,
                            fontFamily: 'Besley',
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide:
                                const BorderSide(color: Color(0xffffffff)),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(30),
                            borderSide:
                                const BorderSide(color: Color(0xffffffff)),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 12),
                        ),
                        icon: const Padding(
                          padding: EdgeInsets.only(right: 10),
                          child: Image(
                            image: AssetImage(
                              'assets/images/arrow down.jpg',
                            ),
                          ),
                        ),
                        value: controller.selectedCondition,
                        items: ['Finished'.tr, 'Unfinished'.tr, 'Super_lux'.tr].map(
                          (value) {
                            return DropdownMenuItem(
                              value: value,
                              child: MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: Container(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: Text(
                                    value,
                                    style: TextStyle(
                                      color:
                                          controller.selectedCondition == value
                                              ? const Color(0xffFF725E)
                                              : const Color(0xffABAC9C),
                                      fontSize: 20,
                                    ),
                                  ),
                                ),
                                onEnter: (_) {
                                  (context.findRenderObject() as RenderBox)
                                      .markNeedsPaint();
                                },
                                onExit: (_) {
                                  (context.findRenderObject() as RenderBox)
                                      .markNeedsPaint();
                                },
                              ),
                            );
                          },
                        ).toList(),
                        onChanged: (newValue) {
                          controller.selectedCondition = newValue;
                        },
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                   Text(
                    'Description'.tr,
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      height: 200,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.white,
                      ),
                      child: TextFormField(
                        controller: controller.yourDescription,
                        minLines: 1,
                        maxLines: 10,
                        style: const TextStyle(
                          color: Color(0xffABAC9C),
                          fontFamily: 'Besley',
                          fontSize: 14,
                        ),
                        decoration:  InputDecoration(
                          border: InputBorder.none,
                          hintText: "Write Your Description".tr,
                          hintStyle: TextStyle(
                              fontFamily: 'Besley',
                              color: Color(0xffABAC9C),
                              fontSize: 18),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Center(
                    child: GestureDetector(
                      onTap: () {
                        if (controller.priceField.text.isNotEmpty) {
                          if (controller.selectedImages.isNotEmpty &&
                              controller.selectedCondition != null &&
                              controller.selectdReg.isNotEmpty &&
                              controller.priceField.text.isNotEmpty &&
                              controller.yourDescription.text.isNotEmpty &&
                              controller.selectedFor != null &&
                              controller.selectedCity != null) {
                            controller.UploadPost();
                          } else {
                            showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  icon: const Icon(
                                    Icons.error,
                                    size: 40,
                                    color: ColorsManager.mainOrange,
                                  ),
                                  content:  Text(
                                    'Dear, you must fill all the fields first.'.tr,
                                    style: const TextStyle(
                                      color: ColorsManager.gray,
                                      fontFamily: 'Besley',
                                      fontSize: 20,
                                    ),
                                  ),
                                  actions: <Widget>[
                                    TextButton(
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      child: const Text(
                                        'OK',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontFamily: 'Besley',
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            );
                          }
                        } else {
                          Fluttertoast.showToast(
                              msg: "Use Ai to determine a fair price.".tr,
                              toastLength: Toast.LENGTH_SHORT,
                              gravity: ToastGravity.BOTTOM,
                              timeInSecForIosWeb: 1,
                              backgroundColor: Colors.red,
                              textColor: Colors.white,
                              fontSize: 16.0);
                        }
                        //   Get.to(
                        //     () => CompleteUploadPage(
                        //       selectedImages: controller.selectedImages,
                        //       selectedCondition: controller.selectedCondition!,
                        //       location: controller.location.text,
                        //       price: controller.price.text,
                        //       description: controller.yourDescription.text,
                        //       selectedFor: controller.selectedFor!,
                        //     ),
                        //   );
                      },
                      child: Container(
                        alignment: Alignment.center,
                        width: 150,
                        height: 55,
                        decoration: BoxDecoration(
                            color: ColorsManager.mainOrange,
                            borderRadius: BorderRadius.circular(30)),
                        child: controller.isLoadUpload == false
                            ?  Text(
                                'Upload'.tr,
                                style: const TextStyle(
                                    color: Color(0xffFFFFFF),
                                    fontFamily: 'Berkshire Swash',
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                                textAlign: TextAlign.center, // Text weight
                              )
                            : const Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Center(
                                    child: CircularProgressIndicator(
                                  color: ColorsManager.gray,
                                )),
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
