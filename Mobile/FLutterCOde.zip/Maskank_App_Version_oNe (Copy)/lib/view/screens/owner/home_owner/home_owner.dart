import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/owner/home_owner_controller.dart';
import 'package:maskank/util/images.dart';
import 'package:maskank/view/screens/owner/home_owner/upload_screen.dart';
import 'package:url_launcher/url_launcher.dart';

void openWhatsAppChat(String phoneNumber, BuildContext context) async {
  String whatsAppUrl = "whatsapp://send?phone=$phoneNumber&text=Can u help me!";

  await launch(whatsAppUrl);
}

// final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
//     GlobalKey<RefreshIndicatorState>();

class HomeOwner extends StatelessWidget {
  const HomeOwner({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xffeaf0ec),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GetBuilder<HomeOwnerController>(
            init: HomeOwnerController()..loadWaitingAndDone(),
            builder: (controller) => SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Hello, ${controller.ownerName}',
                      style: const TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Besley',
                          fontSize: 24),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                   Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      'Total_information_of_deal'.tr,
                      style: const TextStyle(fontFamily: 'Besley', fontSize: 20),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.only(
                              left: 5, right: 40, bottom: 20),
                          child: GestureDetector(
                            onTap: () {},
                            child: Container(
                              alignment: Alignment.center,
                              width: MediaQuery.of(context).size.width / 2,
                              height: MediaQuery.of(context).size.width / 2,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color.fromARGB(
                                            255, 204, 209, 206),
                                        offset: Offset(0, 3.5))
                                  ]),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                          'assets/images/deal 1.png'),
                                      controller.isLoad == false
                                          ? Text(
                                              controller.done.toString(),
                                              style: const TextStyle(
                                                  fontSize: 25,
                                                  fontFamily: 'Besley',
                                                  color: Color(0xffc6c8bc)),
                                            )
                                          : const SizedBox(
                                              height: 25,
                                              child: Center(
                                                  child: SizedBox(
                                                width: 10,
                                                height: 10,
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2,
                                                ),
                                              )),
                                            ),
                                       Text(
                                        "Done_deal".tr,
                                        style: const TextStyle(
                                            color: Color(0xffc6c8bc),
                                            fontFamily: 'Cairo',
                                            fontSize: 20),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 20),
                          child: GestureDetector(
                            onTap: () {},
                            child: Container(
                              alignment: Alignment.center,
                              width: 110,
                              height: 180,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                  boxShadow: const [
                                    BoxShadow(
                                        color: Color.fromARGB(
                                            255, 204, 209, 206),
                                        offset: Offset(0, 3.5))
                                  ]),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Column(
                                  children: [
                                    Image.asset(
                                        'assets/images/Hoursglass.png'),
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(top: 2),
                                      child: controller.isLoad == false
                                          ? Text(
                                              controller.waiting.toString(),
                                              style: const TextStyle(
                                                  fontSize: 25,
                                                  fontFamily: 'Besley',
                                                  color: Color(0xffc6c8bc)),
                                            )
                                          : const SizedBox(
                                              height: 25,
                                              child: Center(
                                                  child: SizedBox(
                                                width: 10,
                                                height: 10,
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2,
                                                ),
                                              )),
                                            ),
                                    ),
                                     Padding(
                                      padding: const EdgeInsets.only(top: 10),
                                      child: FittedBox(
                                        child: Text(
                                          "Waiting_deal".tr,
                                          style: const TextStyle(
                                              color: Color(0xffc6c8bc),
                                              fontFamily: 'Cairo',
                                              fontSize: 15),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                   Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(
                      'You_can_upload_from_here'.tr,
                      style: const TextStyle(fontFamily: 'Besley', fontSize: 20),
                    ),
                  ),
                  Center(
                    child: Padding(
                      padding:
                          const EdgeInsets.only(left: 50, right: 50, top: 20),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) {
                                return const UploaScreen();
                              },
                            ),
                          );
                        },
                        child: Container(
                          alignment: Alignment.center,
                          width: 300,
                          height: 160,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(35),
                              color: Colors.white,
                              boxShadow: const [
                                BoxShadow(
                                    color: Color.fromARGB(255, 204, 209, 206),
                                    offset: Offset(0, 3.5))
                              ]),
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 5),
                                    child: Image.asset(AppImages.uploadPost),
                                  ),
                                   Text(
                                    "Upload_your_apartment".tr,
                                    style: const TextStyle(
                                        color: Color(0xffc6c8bc),
                                        fontFamily: 'Besley',
                                        fontSize: 15),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.07,
                  ),
                  GestureDetector(
                    onTap: () {
                      openWhatsAppChat("+201026624173", context);
                    },
                    child: Align(
                      alignment: Alignment.bottomRight,
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: const BoxDecoration(
                            color: Color.fromARGB(255, 204, 209, 206),
                            borderRadius:
                                BorderRadius.all(Radius.circular(20))),
                        child: const Icon(FontAwesomeIcons.whatsapp),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
