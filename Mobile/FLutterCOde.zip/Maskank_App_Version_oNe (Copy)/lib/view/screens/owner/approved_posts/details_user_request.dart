import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/owner/upload_owner_status.dart';
import 'package:maskank/data/model/requests_user_model.dart';
import 'package:maskank/util/images.dart';
import 'package:maskank/view/screens/owner/approved_posts/widget/user_card_reqest.dart';

final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
    GlobalKey<RefreshIndicatorState>();

class UserRequests extends StatelessWidget {
  final List<MainRequestsOwner> postListRequsts;
 final int indexvar ;
  const UserRequests({super.key, required this.postListRequsts, required this.indexvar});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFFEAF0EC),
      body: SafeArea(
        child: SingleChildScrollView(
          child: GetBuilder<UploadOwnerStatusController>(
            init: UploadOwnerStatusController(),
            builder: (controller) => RefreshIndicator(
              key: _refreshIndicatorKey,
              onRefresh: () async {
                Get.put(UploadOwnerStatusController()).getPostsOfOwner();
                return;
              },
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                          onPressed: () {
                            Get.back();
                          },
                          icon: const Icon(
                            Icons.arrow_back_ios_new,
                            size: 25,
                            color: Colors.black,
                          )),
                      const Text(
                        'User Reqests',
                        style: TextStyle(
                          fontSize: 22,
                          fontFamily: "Besley",
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height - 110,
                    child: controller.postListRequsts.isNotEmpty
                        ? ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            itemCount: controller.postListRequsts[indexvar].requests.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.all(10),
                                child: UserRequestCard(
                                  postList: controller.postListRequsts,
                                  index: index, indexVar: indexvar,
                                ),
                              );
                            })
                        : Image.asset(AppImages.noData),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
