import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/owner/upload_owner_status.dart';
import 'package:maskank/data/model/requests_user_model.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/widget/custom_button.dart';

class UserRequestCard extends StatelessWidget {
  final List<MainRequestsOwner> postList;
  final int indexVar;
  final int index;

  const UserRequestCard(
      {super.key,
      required this.postList,
      required this.index,
      required this.indexVar});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height / 4,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: Colors.white,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const CircleAvatar(
                            backgroundColor: ColorsManager.mainLightGreen,
                            child: Icon(
                              Icons.person,
                              color: ColorsManager.darkBlue,
                            )),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            postList[indexVar]
                                .requests[index]
                                .renter
                                .renterName,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Besley",
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const CircleAvatar(
                            backgroundColor: ColorsManager.mainLightGreen,
                            child: Icon(
                              Icons.call,
                              color: ColorsManager.darkBlue,
                            )),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: FittedBox(
                            child: Text(
                              postList[indexVar].requests[index].renter.phone,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                fontFamily: "Besley",
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const CircleAvatar(
                            backgroundColor: ColorsManager.mainLightGreen,
                            child: Icon(
                              Icons.mail,
                              color: ColorsManager.darkBlue,
                            )),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: FittedBox(
                            child: Text(
                              postList[indexVar].requests[index].renter.email,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                fontFamily: "Besley",
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: CustomButton(
                        title: 'Approval',
                        onTap: () {
                          Get.put(UploadOwnerStatusController()).updatePost(
                              1, postList[indexVar].requests[index].id);
                        },
                        color: const Color.fromARGB(255, 132, 240, 168),
                      ),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    Expanded(
                      child: CustomButton(
                        title: 'Cancel',
                        onTap: () {
                          Get.put(UploadOwnerStatusController()).updatePost(
                              0, postList[indexVar].requests[index].id);
                        },
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
