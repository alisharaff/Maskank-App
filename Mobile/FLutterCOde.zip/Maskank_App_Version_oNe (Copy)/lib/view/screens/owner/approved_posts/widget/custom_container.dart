import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/owner/upload_owner_status.dart';
import 'package:maskank/data/model/post_owner_model.dart';
import 'package:maskank/data/model/requests_user_model.dart';
import 'package:maskank/view/screens/owner/approved_posts/details_user_request.dart';
import 'package:maskank/view/screens/owner/approved_posts/widget/custom_check_accept.dart';

class CheckAcceptOwner extends StatelessWidget {
  final List<MainRequestsOwner> postList;
  final int index;

  const CheckAcceptOwner(
      {super.key, required this.postList, required this.index});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<UploadOwnerStatusController>(
      init: UploadOwnerStatusController(),
      // ..(postList[index].postId),
      builder: (controller) => InkWell(
        onTap: () {
          Get.to(() => UserRequests(
                postListRequsts: postList,
                indexvar: index,
              ));
        },
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height / 2,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: Colors.white,
          ),
          child: Stack(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height * 0.2 + 10,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                          image: DecorationImage(
                              image:
                                  NetworkImage(postList[index].post.images[0]),
                              fit: BoxFit.fill),
                        ),
                      ),
                      Text(
                        '${postList[index].post.price.toString()} EGP/Month',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w500,
                          fontFamily: "Besley",
                        ),
                      ),
                      const SizedBox(
                        height: 7,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/images/Group.png'),
                          const SizedBox(
                            width: 10,
                          ),
                          SizedBox(
                            child: Text(
                              '${postList[index].post.region.toString()} - ${postList[index].post.city.toString()}',
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                              style: const TextStyle(
                                fontSize: 18,
                                color: Color(0XFFABAC9C),
                                fontFamily: "Besley",
                              ),
                            ),
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 7,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.bed,
                              color: const Color(0XFFABAC9C).withOpacity(0.5),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              postList[index].post.bedrooms.toString(),
                              style: const TextStyle(
                                fontSize: 13,
                                color: Color(0XFFABAC9C),
                                fontFamily: "Besley",
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Icon(
                              Icons.bathtub,
                              color: const Color(0XFFABAC9C).withOpacity(0.5),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              postList[index].post.bathrooms.toString(),
                              style: const TextStyle(
                                fontSize: 13,
                                color: Color(0XFFABAC9C),
                                fontFamily: "Besley",
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Image.asset('assets/images/Frame 108.png'),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              postList[index].post.size.toString(),
                              style: const TextStyle(
                                color: Color(
                                  0XFFABAC9C,
                                ),
                                fontFamily: "Besley",
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Positioned(
                bottom: 0,
                right: 0,
                left: 0,
                child: CheckAccept(
                  activeStep: postList[index].post.status,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
