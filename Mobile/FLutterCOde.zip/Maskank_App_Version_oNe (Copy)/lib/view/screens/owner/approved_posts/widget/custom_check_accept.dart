import 'package:easy_stepper/easy_stepper.dart';
import 'package:flutter/material.dart';
import 'package:maskank/util/colors.dart';

class CheckAccept extends StatefulWidget {
  int activeStep = 1;
  CheckAccept({super.key, required this.activeStep});

  @override
  State<CheckAccept> createState() => _CheckAcceptState();
}

class _CheckAcceptState extends State<CheckAccept> {
  @override
  Widget build(BuildContext context) {
    return EasyStepper(
      enableStepTapping: false,
      activeStep: widget.activeStep,
      defaultStepBorderType: BorderType.normal,
      unreachedStepIconColor: Colors.black,
      finishedStepIconColor: Colors.amber,
      activeStepTextColor: Colors.black87,
      finishedStepTextColor: Colors.black87,
      finishedStepBorderColor: ColorsManager.gray,
      activeStepBorderColor: ColorsManager.gray,
      internalPadding: 30,
      showLoadingAnimation: true,
      stepRadius: 10,
      showStepBorder: true,
      lineStyle: const LineStyle(
          lineType: LineType.normal,
          activeLineColor: ColorsManager.mainOrange,
          finishedLineColor: ColorsManager.mainOrange),
      steps: [
        EasyStep(
          customStep: CircleAvatar(
            radius: 8,
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: 7,
              backgroundColor: widget.activeStep >= 0
                  ? ColorsManager.mainOrange
                  : Colors.white,
            ),
          ),
          title: 'Waiting',
          customTitle: const Text(
            "Waiting",
            style: TextStyle(
              color: Color(0XFFABAC9C),
              fontFamily: "Besley",
            ),
          ),
        ),
        EasyStep(
          customStep: CircleAvatar(
            radius: 8,
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: 7,
              backgroundColor: widget.activeStep >= 1
                  ? ColorsManager.mainOrange
                  : Colors.white,
            ),
          ),
          title: 'Post Received',
          customTitle: const Text(
            "Received",
            textAlign: TextAlign.start,
            style: TextStyle(
              color: Color(0XFFABAC9C),
              fontFamily: "Besley",
            ),
          ),
          topTitle: true,
        ),
        EasyStep(
          customTitle: const Text(
            "Preparing",
            style: TextStyle(
              color: Color(0XFFABAC9C),
              fontFamily: "Besley",
            ),
          ),
          customStep: CircleAvatar(
            radius: 8,
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: 7,
              backgroundColor: widget.activeStep >= 2
                  ? ColorsManager.mainOrange
                  : Colors.white,
            ),
          ),
          title: 'Preparing',
        ),
        EasyStep(
          customStep: CircleAvatar(
            radius: 8,
            backgroundColor: Colors.white,
            child: CircleAvatar(
              radius: 7,
              backgroundColor: widget.activeStep >= 3
                  ? ColorsManager.mainOrange
                  : Colors.white,
            ),
          ),
          customTitle: const Text(
            "Done",
            style: TextStyle(
              color: Color(0XFFABAC9C),
              fontFamily: "Besley",
            ),
          ),
          title: 'Done',
          topTitle: true,
        ),
      ],
      onStepReached: (index) => setState(() => widget.activeStep = index),
    );
  }
}
