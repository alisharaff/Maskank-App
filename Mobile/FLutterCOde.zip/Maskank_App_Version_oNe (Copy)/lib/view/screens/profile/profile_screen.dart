import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/profile_controller.dart';
import 'package:maskank/util/images.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileScreenController>(
      init: ProfileScreenController()..getInfo(),
      builder: (controller) {
        return Scaffold(
            backgroundColor: const Color(0xffEAF0EC),
            body: RefreshIndicator(
              onRefresh: () async {
                await controller.getInfo();
                return;
              },
              child: SingleChildScrollView(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                    Stack(
                      children: [
                        Container(
                          width: double.infinity,
                          height: 250,
                          decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                  AppImages.orange,
                                ),
                                fit: BoxFit.cover),
                          ),
                        ),
                        Positioned(
                            top: 50,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    controller.logout();
                                  },
                                  child: const Padding(
                                    padding: EdgeInsets.only(left: 260),
                                    child: Icon(
                                      FontAwesomeIcons.arrowRightFromBracket,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                  ),
                                ),
                                 Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Text(
                                    'Log_out'.tr,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontFamily: 'Besley',
                                        fontSize: 18),
                                  ),
                                ),
                              ],
                            )),
                        Center(
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              controller.image != null
                                  ? Container(
                                      width: 150,
                                      height: 150,
                                      margin: const EdgeInsets.only(top: 180),
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            image:
                                                MemoryImage(controller.image!),
                                            fit: BoxFit.cover,
                                          )),
                                    )
                                  : Container(
                                      width: 150,
                                      height: 150,
                                      margin: const EdgeInsets.only(top: 180),
                                      decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                          image: DecorationImage(
                                            image: AssetImage(
                                                AppImages.profilepic),
                                            fit: BoxFit.cover,
                                          )),
                                    ),
                              Positioned(
                                  top: 100,
                                  child: Text(
                                    controller.profileName,
                                    style: const TextStyle(
                                      fontFamily: 'Besley',
                                      fontSize: 20,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    textAlign: TextAlign.center,
                                  )),
                              Positioned(
                                  bottom: 90,
                                  right: 0,
                                  left: 125,
                                  child: GestureDetector(
                                    onTap: () {
                                      controller.showImagePickerOption();
                                    },
                                    child: Container(
                                      width: 30,
                                      height: 30,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              width: 4,
                                              color: const Color(0xffEAF0EC)),
                                          color: const Color(0xffEAF0EC)),
                                      child: const Icon(
                                        FontAwesomeIcons.pen,
                                        color: Color(0xffABAC9C),
                                        size: 15,
                                      ),
                                    ),
                                  )),
                            ],
                          ),
                        )
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Center(
                      child: Container(
                        alignment: Alignment.center,
                        width: 150,
                        height: 55,
                        decoration: BoxDecoration(
                          color: const Color(0xffFFFFFF),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                            color: const Color(0xffFF725E),
                            width: 1,
                          ),
                        ),
                        child: ElevatedButton(
                          onPressed: () {
                            controller.toggleReadOnly();
                          },
                          style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.white),
                          ),
                          child: Container(
                            alignment: Alignment.center,
                            child: Text(
                              controller.isReadOnly ? 'Edit_profile'.tr : 'Save'.tr,
                              style: const TextStyle(
                                  color: Color(0xffABAC9C),
                                  fontFamily: 'Besley',
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                     Padding(
                      padding: EdgeInsets.only(left: 50,right: 50),
                      child: Text(
                        'Your_name'.tr,
                        style: const TextStyle(
                          fontFamily: 'Besley',
                          fontSize: 14,
                          color: Color(0xff5E756D),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 22, right: 22),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              margin: const EdgeInsets.all(8),
                              padding: const EdgeInsets.only(left: 22),
                              height: 45,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: TextFormField(
                                controller: controller.fullnameController,
                                readOnly: controller.isReadOnly,
                                style: TextStyle(color: controller.fontColor),
                                decoration: const InputDecoration(
                                  icon: Icon(
                                    Icons.person,
                                    size: 32,
                                    color: Color(0xFFABAC9C),
                                  ),
                                  border: InputBorder.none,
                                  hintText: "Ali SHaraf",
                                  hintStyle: TextStyle(
                                      fontFamily: 'Besley',
                                      color: Color(0xffABAC9C),
                                      fontSize: 16),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                     Padding(
                      padding: EdgeInsets.only(left: 50,right: 50),
                      child: Text(
                        'Your_e-mail'.tr,
                        style: const TextStyle(
                          fontFamily: 'Besley',
                          fontSize: 14,
                          color: Color(0xff5E756D),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 22, right: 22),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              margin: const EdgeInsets.all(8),
                              padding: const EdgeInsets.only(left: 16),
                              height: 45,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: TextFormField(
                                controller: controller.mailController,
                                readOnly: controller.isReadOnly,
                                style: TextStyle(color: controller.fontColor),
                                decoration: InputDecoration(
                                  prefixIcon: Container(
                                    width: 48,
                                    height: 48,
                                    alignment: Alignment.center,
                                    child: SvgPicture.asset(
                                      AppImages.mail,
                                    ),
                                  ),
                                  border: InputBorder.none,
                                  hintText: "maskank@gmail.com",
                                  hintStyle: const TextStyle(
                                      fontFamily: 'Besley',
                                      color: Color(0xffABAC9C),
                                      fontSize: 16),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                     Padding(
                      padding: const EdgeInsets.only(left: 50,right: 50),
                      child: Text(
                        'Phone_number'.tr,
                        style: const TextStyle(
                          fontFamily: 'Besley',
                          fontSize: 14,
                          color: Color(0xff5E756D),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 22, right: 22),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              margin: const EdgeInsets.all(8),
                              padding: const EdgeInsets.only(left: 16),
                              height: 45,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: TextFormField(
                                controller: controller.phoneController,
                                readOnly: controller.isReadOnly,
                                style: TextStyle(color: controller.fontColor),
                                decoration: InputDecoration(
                                  prefixIcon: Container(
                                    width: 48,
                                    height: 48,
                                    alignment: Alignment.center,
                                    child: SvgPicture.asset(
                                      AppImages.phone,
                                    ),
                                  ),
                                  border: InputBorder.none,
                                  hintText: "+20100000000",
                                  hintStyle: const TextStyle(
                                      fontFamily: 'Besley',
                                      color: Color(0xffABAC9C),
                                      fontSize: 16),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                     Padding(
                      padding: const EdgeInsets.only(left: 50,right: 50),
                      child: Text(
                        'Your_location'.tr,
                        style: const TextStyle(
                          fontFamily: 'Besley',
                          fontSize: 14,
                          color: Color(0xff5E756D),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 22, right: 22),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              margin: const EdgeInsets.all(8),
                              padding: const EdgeInsets.only(left: 10),
                              height: 45,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.white,
                              ),
                              child: TextFormField(
                                controller: controller.addressController,
                                readOnly: controller.isReadOnly,
                                style: TextStyle(color: controller.fontColor),
                                decoration: InputDecoration(
                                  prefixIcon: Container(
                                    width: 48,
                                    height: 48,
                                    alignment: Alignment.center,
                                    child: SvgPicture.asset(
                                      AppImages.location,
                                    ),
                                  ),
                                  border: InputBorder.none,
                                  hintText: "Egypt, Alex",
                                  hintStyle: const TextStyle(
                                      fontFamily: 'Besley',
                                      color: Color(0xffABAC9C),
                                      fontSize: 16),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  ])),
            ));
      },
    );
  }
}
