import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/view/base/butNavBar/owner_nav_bar.dart';

class CompleteUploadPage extends StatelessWidget {
  const CompleteUploadPage(
      {super.key,
      required List<File> selectedImages,
      required String selectedCondition,
      required String location,
      required String price,
      required String description,
      required String selectedFor});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffEAF0EC),
      body: Column(
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 160),
            child: Center(
              child: Image(
                image: AssetImage('assets/images/upload.png'),
              ),
            ),
          ),
          const Text(
            'Your apartment was uploaded successfully',
            style: TextStyle(
              fontFamily: 'Besley',
              fontSize: 20,
              color: Color(0x8A000000),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 20,
          ),
          GestureDetector(
            onTap: () {
              Get.offAll(() => OwnerMyNavBar());
            },
            child: Container(
              alignment: Alignment.center,
              width: 150,
              height: 55,
              decoration: BoxDecoration(
                  color: const Color(0xfff7dd41e),
                  borderRadius: BorderRadius.circular(30)),
              child: const Text(
                'Close',
                style: TextStyle(
                    color: Color(0xffFFFFFF),
                    fontFamily: 'Berkshire Swash',
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
