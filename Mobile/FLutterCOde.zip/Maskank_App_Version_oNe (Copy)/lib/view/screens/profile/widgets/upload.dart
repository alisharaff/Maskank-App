import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:group_button/group_button.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maskank/view/screens/owner/home_owner/home_owner.dart';
import 'package:maskank/view/screens/profile/widgets/complete_upload.dart';

class Upload extends StatefulWidget {
  const Upload({Key? key}) : super(key: key);

  @override
  State<Upload> createState() => _UploadState();
}

class _UploadState extends State<Upload> {
  TextEditingController location = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController yourDescription = TextEditingController();

  @override
  void dispose() {
    location.dispose();
    price.dispose();
    yourDescription.dispose();

    super.dispose();
  }

  List<File> _selectedImages = [];
  String? _selectedCondition;
  String? _selectedFor;

  final picker = ImagePicker();

  Future<void> _getImage(ImageSource source) async {
    if (_selectedImages.length >= 6) {
      // Show error message if maximum number of images reached
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error'),
            content: const Text('You can only select up to six photos.'),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
      return;
    }

    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) {
      setState(
        () {
          _selectedImages.add(File(pickedFile.path));
        },
      );
    }
  }

  void _showImagePickerOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height / 4.5,
          child: Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () {
                      Navigator.pop(context);
                      _getImage(ImageSource.gallery);
                    },
                    child: const SizedBox(
                      child: Column(
                        children: [
                          Icon(
                            Icons.image,
                            size: 70,
                            color: Color(0xff5E756D),
                          ),
                          Text(
                            "Gallery",
                            style: TextStyle(
                              fontFamily: "Besley",
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: InkWell(
                    onTap: () {
                      Navigator.pop(context);
                      _getImage(ImageSource.camera);
                    },
                    child: const SizedBox(
                      child: Column(
                        children: [
                          Icon(
                            Icons.camera_alt,
                            size: 70,
                            color: Color(0xff5E756D),
                          ),
                          Text(
                            "Camera",
                            style: TextStyle(
                              fontFamily: "Besley",
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildImageContainer(File imageFile) {
    return Container(
      width: 165,
      height: 175,
      margin: const EdgeInsets.only(left: 25, bottom: 10),
      decoration: BoxDecoration(
        color: const Color(0xffFFFFFF),
        borderRadius: BorderRadius.circular(20),
        boxShadow: const [
          BoxShadow(
            color: Color(0xffbdc2bf),
            offset: Offset(2, 3),
          )
        ],
        image: DecorationImage(
          image: FileImage(imageFile),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                _selectedImages.remove(imageFile);
              });
            },
            child: Container(
              alignment: Alignment.topRight,
              padding: const EdgeInsets.all(5),
              child: const Icon(
                Icons.cancel,
                color: Color(0xffFF725E),
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffEAF0EC),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 300, top: 30),
            child: GestureDetector(
              onTap: () {
                // Navigate to the second page
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeOwner()),
                );
              },
              child: const Icon(
                FontAwesomeIcons.angleLeft,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          const Padding(
            padding: EdgeInsets.only(left: 25),
            child: Text(
              'Upload your apartment',
              style: TextStyle(
                  color: Color(0xff5E756D),
                  fontFamily: 'Besley',
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                children: [
                  ..._selectedImages.map(
                    (File imageFile) {
                      return _buildImageContainer(imageFile);
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 25),
                    child: GestureDetector(
                      onTap: () {
                        _showImagePickerOptions(context);
                      },
                      child: Container(
                        alignment: Alignment.center,
                        width: 165,
                        height: 175,
                        decoration: BoxDecoration(
                          color: const Color(0xffFFFFFF),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0xffbdc2bf), offset: Offset(2, 3))
                          ],
                        ),
                        child: Center(
                          child: SvgPicture.asset(
                            'assets/images/Plus.svg',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 25),
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.only(right: 235),
                  child: Text(
                    'location',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 20, top: 8),
                  padding: const EdgeInsets.only(left: 40, top: 5),
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: Colors.white,
                  ),
                  child: TextFormField(
                    controller: location,
                    style: const TextStyle(
                      color: Color(0xffABAC9C),
                      fontFamily: 'Besley',
                      fontSize: 14,
                    ),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "Write Your location",
                      hintStyle: TextStyle(
                          fontFamily: 'Besley',
                          color: Color(0xffABAC9C),
                          fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 235),
                  child: Text(
                    'Price',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 20, top: 8),
                  padding: const EdgeInsets.only(left: 40, top: 5),
                  height: 60,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: Colors.white,
                  ),
                  child: TextFormField(
                    controller: price,
                    style: const TextStyle(
                      color: Color(0xffABAC9C),
                      fontFamily: 'Besley',
                      fontSize: 14,
                    ),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "Type the right price for your apartment",
                      hintStyle: TextStyle(
                          fontFamily: 'Besley',
                          color: Color(0xffABAC9C),
                          fontSize: 13),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 235),
                  child: Text(
                    'For?',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                GroupButton(
                  buttons: const ['Any', 'Student', 'Personal'],
                  isRadio: true,
                  onSelected: (value, index, isSelected) {
                    if (isSelected) {
                      setState(
                        () {
                          _selectedFor = ['Any', 'Student', 'Personal'][index];
                        },
                      );
                    }
                  },
                  options: GroupButtonOptions(
                    spacing: 15,
                    selectedColor: const Color(0xffFF725E),
                    borderRadius: BorderRadius.circular(10),
                    selectedTextStyle: const TextStyle(
                      fontFamily: 'Besley',
                      color: Color(0xffFFFFFF),
                      fontSize: 16,
                    ),
                    unselectedTextStyle: const TextStyle(
                      fontFamily: 'Besley',
                      color: Color(0xff000000),
                      fontSize: 16,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 190),
                  child: Text(
                    'Bedrooms',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      GroupButton(
                        buttons: const ['Studio', '1', '2', '3', '4+'],
                        isRadio: true,
                        onSelected: (value, index, isSelected) {},
                        options: GroupButtonOptions(
                          direction: Axis.horizontal,
                          spacing: 15,
                          selectedColor: const Color(0xffFF725E),
                          borderRadius: BorderRadius.circular(10),
                          selectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xffFFFFFF),
                            fontSize: 16,
                          ),
                          unselectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xff000000),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 190),
                  child: Text(
                    'Bathrooms',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      GroupButton(
                        buttons: const ['Studio', '1', '2', '3', '4+'],
                        isRadio: true,
                        onSelected: (value, index, isSelected) {},
                        options: GroupButtonOptions(
                          direction: Axis.horizontal,
                          spacing: 15,
                          selectedColor: const Color(0xffFF725E),
                          borderRadius: BorderRadius.circular(10),
                          selectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xffFFFFFF),
                            fontSize: 16,
                          ),
                          unselectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xff000000),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 165),
                  child: Text(
                    'Property type',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      GroupButton(
                        buttons: const [
                          'Any',
                          'Apartments',
                          'House',
                          'Room',
                          'Duplex',
                          'Villa'
                        ],
                        isRadio: true,
                        onSelected: (value, index, isSelected) {},
                        options: GroupButtonOptions(
                          direction: Axis.horizontal,
                          spacing: 15,
                          selectedColor: const Color(0xffFF725E),
                          borderRadius: BorderRadius.circular(10),
                          selectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xffFFFFFF),
                            fontSize: 16,
                          ),
                          unselectedTextStyle: const TextStyle(
                            fontFamily: 'Besley',
                            color: Color(0xff000000),
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xffffffff),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: DropdownButtonFormField(
                    decoration: InputDecoration(
                      hintText: 'Apartment Condition',
                      hintStyle: const TextStyle(
                        color: Color(0xffABAC9C),
                        fontSize: 24,
                        fontFamily: 'Besley',
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: const BorderSide(color: Color(0xffffffff)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: const BorderSide(color: Color(0xffffffff)),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                    ),
                    icon: const Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: Image(
                        image: AssetImage(
                          'assets/images/arrow down.jpg',
                        ),
                      ),
                    ),
                    value: _selectedCondition,
                    items: ['Finished', 'Unfinished', 'Super lux'].map(
                      (value) {
                        return DropdownMenuItem(
                          value: value,
                          child: MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: Container(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                value,
                                style: TextStyle(
                                  color: _selectedCondition == value
                                      ? const Color(0xffFF725E)
                                      : const Color(0xffABAC9C),
                                  fontSize: 20,
                                ),
                              ),
                            ),
                            onEnter: (_) {
                              // Change the color when hovered
                              (context.findRenderObject() as RenderBox)
                                  .markNeedsPaint();
                            },
                            onExit: (_) {
                              // Change the color back to normal
                              (context.findRenderObject() as RenderBox)
                                  .markNeedsPaint();
                            },
                          ),
                        );
                      },
                    ).toList(),
                    onChanged: (newValue) {
                      setState(
                        () {
                          _selectedCondition = newValue;
                        },
                      );
                    },
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 180),
                  child: Text(
                    'Description',
                    style: TextStyle(
                        color: Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  margin: const EdgeInsets.only(right: 20, top: 8),
                  padding: const EdgeInsets.only(left: 40, top: 10),
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: Colors.white,
                  ),
                  child: TextFormField(
                    controller: yourDescription,
                    minLines: 1,
                    maxLines: 10,
                    style: const TextStyle(
                      color: Color(0xffABAC9C),
                      fontFamily: 'Besley',
                      fontSize: 14,
                    ),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "Write your description",
                      hintStyle: TextStyle(
                          fontFamily: 'Besley',
                          color: Color(0xffABAC9C),
                          fontSize: 18),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                GestureDetector(
                  onTap: () {
                    if (_selectedImages.isNotEmpty &&
                        _selectedCondition != null &&
                        location.text.isNotEmpty &&
                        price.text.isNotEmpty &&
                        yourDescription.text.isNotEmpty &&
                        _selectedFor != null) {
                      // All fields are filled, navigate to complete upload
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CompleteUploadPage(
                            selectedImages: _selectedImages,
                            selectedCondition: _selectedCondition!,
                            location: location.text,
                            price: price.text,
                            description: yourDescription.text,
                            selectedFor: _selectedFor!,
                          ),
                        ),
                      );
                    } else {
                      // Show error message if any field is empty
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text('Error'),
                            content:
                                const Text('Please fill all required fields.'),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: const Text('OK'),
                              ),
                            ],
                          );
                        },
                      );
                    }
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: 150,
                    height: 55,
                    decoration: BoxDecoration(
                        color: const Color(0xffFF725E),
                        borderRadius: BorderRadius.circular(30)),
                    child: const Text(
                      'Upload',
                      style: TextStyle(
                          color: Color(0xffFFFFFF),
                          fontFamily: 'Berkshire Swash',
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center, // Text weight
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
