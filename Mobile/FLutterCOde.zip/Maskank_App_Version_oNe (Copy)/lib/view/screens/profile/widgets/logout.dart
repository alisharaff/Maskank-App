import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class LogOut extends StatelessWidget {
  const LogOut({super.key});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 8)).then((_) {
      SystemNavigator.pop();
    });
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xffEEE1D8), Color(0xffDBA690)],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft)),
        child: const Padding(
          padding: EdgeInsets.only(top: 300),
          child: Column(
            children: [
              Center(
                child: Text(
                  'Log out',
                  style: TextStyle(
                      color: Color(0xffD15000),
                      fontSize: 40,
                      fontFamily: 'Besley',
                      fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              CircularProgressIndicator(
                color: Color(0xffFF7864),
                backgroundColor: Color(0xffebb9ae),
                strokeWidth: 8,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
