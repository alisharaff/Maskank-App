import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:maskank/locale/locale/locale_controller.dart';
import 'package:maskank/util/images.dart';
import 'package:maskank/view/screens/auth/owner/login/login_page_owner.dart';
import 'package:maskank/view/screens/auth/user/login/login_page.dart';

class RolePage extends StatelessWidget {
  const RolePage({super.key});

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    // MyLocaleController controllerlang = Get.find();
    return Scaffold(
      backgroundColor: const Color.fromRGBO(234, 240, 236, 1),
      body: ListView(
        children: [
          // MaterialButton(
          //     color: Colors.white,
          //     textColor: Colors.black,
          //     child: const Text('Arabic'),
          //     onPressed: () {
          //       controllerlang.changeLang("ar");
          //     }),
          // const SizedBox(
          //   height: 20,
          // ),
          //  MaterialButton(
          //     color: Colors.white,
          //     textColor: Colors.black,
          //     child: const Text('english'),
          //     onPressed: () {
          //       controllerlang.changeLang("en");
          //     }),
          Stack(
            children: [
              SizedBox(
                  child: Align(
                alignment: Alignment.topRight,
                child: Image.asset(AppImages.selectRoleCircle),
              )),
            ],
          ),
          Text(
            'Choose_Your_Role'.tr,
            style: const TextStyle(
              fontFamily: 'Berkshire Swash',
              fontSize: 32,
              color: Color(0xff896360),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 10,
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.only(left: 80, right: 80, bottom: 20),
              child: GestureDetector(
                onTap: () {
                  Get.to(() => const LoginPage());
                },
                child: Container(
                  alignment: Alignment.center,
                  width: MediaQuery.of(context).size.width / 2,
                  height: screenSize.height * 0.20,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(35),
                      color: const Color(0xffDDA796),
                      boxShadow: const [
                        BoxShadow(
                            color: Color.fromARGB(255, 204, 209, 206),
                            offset: Offset(0, 3.5))
                      ]),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Column(
                        children: [
                          Expanded(
                              child: Center(
                                  child: SvgPicture.asset(
                                      'assets/images/user.svg'))),
                          Text(
                            "user".tr,
                            style: const TextStyle(
                                color: Color(0xff896360),
                                fontFamily: 'Berkshire Swash',
                                fontSize: 36),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Center(
            child: Text(
              'Searching_for_Apartments_Reviewing_Apartments_Communicating_with_Owners_or_Agents_Booking_and_Leasing_and_Interacting_with_Customer_Service'
                  .tr,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontFamily: "Besley",
                fontSize: 14,
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(top: 8, bottom: 8),
            child: Divider(
              color: Color(0xffb2b3a5),
              thickness: 1,
              indent: 20,
              endIndent: 20,
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.only(left: 80, right: 80, bottom: 20),
              child: GestureDetector(
                onTap: () {
                  Get.to(() => const LoginOwner());
                },
                child: Container(
                  alignment: Alignment.center,
                  width: MediaQuery.of(context).size.width / 2,
                  height: screenSize.height * 0.20,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(35),
                      color: const Color(0xffDDA796),
                      boxShadow: const [
                        BoxShadow(
                            color: Color.fromARGB(255, 204, 209, 206),
                            offset: Offset(0, 3.5))
                      ]),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Padding(
                      padding: const EdgeInsets.only(
                          left: 20, right: 10, bottom: 10),
                      child: Column(
                        children: [
                          Expanded(
                              child: Center(
                            child: SvgPicture.asset(
                              'assets/images/Owner.svg',
                              height: 100,
                              width: 100,
                            ),
                          )),
                          Text(
                            "owner".tr,
                            style: const TextStyle(
                                color: Color(0xff896360),
                                fontFamily: 'Berkshire Swash',
                                fontSize: 30),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Text(
            'Listing_Properties_Managing_Inquiries_Scheduling_Viewings_Reviewing_Applications_Handling_Lease_Agreements_Financial_Transactions_and_Communicating_with_Tenants'
                .tr,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontFamily: "Besley",
              fontSize: 14,
            ),
          ),
          Container(
              color: const Color.fromARGB(0, 255, 193, 7),
              width: 60,
              height: 60,
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Image.asset(AppImages.selectRoleCircleBU),
              )),
        ],
      ),
    );
  }
}
