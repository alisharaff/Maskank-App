import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/view/base/butNavBar/owner_nav_bar.dart';

class VerteficationScreen extends StatelessWidget {
  const VerteficationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFFEAF0EC),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height / 5,
              ),
              const CircleAvatar(
                backgroundColor: Color.fromARGB(132, 124, 212, 30),
                radius: 60,
                child: CircleAvatar(
                  backgroundColor: Color(0xFF7DD41E),
                  radius: 40,
                  child: Icon(
                    Icons.check,
                    size: 50,
                    color: Colors.white,
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 20),
                child: Text(
                  'Verevication Success',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 10),
                child: Text('Congrats Your Identy Succeccfully Verified'),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 6,
              ),
              SizedBox(
                width: 220,
                height: 60,
                child: ElevatedButton(
                    onPressed: () {
                      Get.offAll(() => OwnerMyNavBar());
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0XFFFF725E),
                    ),
                    child: const Text(
                      'continue',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    )),
              ),
              const Spacer(
                flex: 1,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
