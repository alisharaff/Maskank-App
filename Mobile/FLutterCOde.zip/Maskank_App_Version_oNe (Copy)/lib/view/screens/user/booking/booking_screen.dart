import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/favorite_screen_controller.dart';
import 'package:maskank/data/model/request_user_post_model.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/view/base/noData/no_booking.dart';
import 'package:maskank/view/screens/user/home/apartement_details/apartement_details.dart';

import '../../../../controller/booked_controller.dart';

class BookingScreen extends StatelessWidget {
  const BookingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await Get.put(BookedUserRequestController()).getRequestInfo();
        return;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
                onPressed: () async {
                  await Get.put(BookedUserRequestController()).getRequestInfo();
                },
                icon: const Icon(
                  Icons.refresh,
                  color: ColorsManager.mainLightGreen,
                )),
            IconButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        icon: const Icon(
                          Icons.error,
                          size: 40,
                          color: ColorsManager.mainOrange,
                        ),
                        content: Text(
                          'Dear_this_place_is_dedicated_to_following_up_on_the_rental_status_and_when_the_apartment_owner_agrees_you_can_view_his_information_and_contact_him'
                              .tr,
                          style: const TextStyle(
                            color: ColorsManager.gray,
                            fontFamily: 'Besley',
                            fontSize: 20,
                          ),
                        ),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text(
                              'OK',
                              style: TextStyle(
                                color: Colors.black,
                                fontFamily: 'Besley',
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
                icon: const Icon(
                  Icons.error_outline,
                  color: ColorsManager.mainOrange,
                ))
          ],
          title: Text(
            'Status_of_request'.tr,
            style: const TextStyle(
                color: Color(0XFF5E756D),
                fontFamily: "Besley",
                fontSize: 20,
                fontWeight: FontWeight.bold),
          ),
        ),
        body: SafeArea(
            child: SizedBox(
                width: MediaQuery.of(context).size.width,
                child: GetBuilder<BookedUserRequestController>(
                  init: BookedUserRequestController()..getRequestInfo(),
                  builder: (controller) => controller.houseList.isNotEmpty
                      ? ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          itemCount: controller.houseList.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ApartementDetails(
                                      potId: controller.houseList[index].id,
                                    ),
                                  ),
                                );
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(8.0),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 2,
                                        blurRadius: 5,
                                        offset: const Offset(0, 3),
                                      ),
                                    ],
                                  ),
                                  child: PostCard(
                                    controller.houseList,
                                    index: index,
                                  ),
                                ),
                              ),
                            );
                          })
                      : const NoBooking(),
                ))),
      ),
    );
  }
}

class PostCard extends StatelessWidget {
  final List<PostData> houseList;
  final int index;
  const PostCard(this.houseList, {super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavoriteController>(
      builder: (controller) => Stack(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        children: [
                          Text(
                            houseList[index].post.status == 2
                                ? '${houseList[index].post.owner.phone} '
                                : "",
                          ),
                          SizedBox(
                            child: Text(
                              '${houseList[index].post.price} EGP/month',
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                              style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "cairo"),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Align(
                            alignment: Alignment.topCenter,
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.location_on,
                                  color: Color(0XFFFF725E),
                                ),
                                const SizedBox(
                                  width: 12,
                                ),
                                SizedBox(
                                  child: Text(
                                    '${houseList[index].post.region} , ${houseList[index].post.city}',
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style: const TextStyle(
                                      fontFamily: "cairo",
                                      fontSize: 12,
                                      color: Color(0XFFABAC9C),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.bed,
                                color: const Color(0XFFABAC9C).withOpacity(0.5),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                '${houseList[index].post.bedrooms}',
                                style: const TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFFABAC9C),
                                    fontFamily: "Cairo"),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Icon(
                                Icons.bathtub,
                                color: const Color(0XFFABAC9C).withOpacity(0.5),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                '${houseList[index].post.bathrooms}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Color(0XFFABAC9C),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Image.asset('assets/images/Frame 108.png'),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                '${houseList[index].post.size} m²',
                                style: const TextStyle(
                                  color: const Color(0XFFFF725E),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              // const SizedBox(
                              //   width: 10,
                              // ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Stack(
                                  children: [
                                    Row(
                                      children: [
                                        const SizedBox(
                                          width: 5,
                                        ),
                                        SizedBox(
                                            child: IconButton(
                                                onPressed:
                                                    houseList[index].status == 0
                                                        ? null
                                                        : () {
                                                            showUserBottomSheet(
                                                                context,
                                                                houseList[index]
                                                                    .post
                                                                    .owner);
                                                          },
                                                icon: const Icon(
                                                  FontAwesomeIcons.userLock,
                                                  color: Color(0XFF5E756D),
                                                ))),
                                        SizedBox(
                                            child: IconButton(
                                                onPressed:
                                                    houseList[index].status == 0
                                                        ? null
                                                        : () {
                                                            controller
                                                                .openWhatsAppChat(
                                                                    "+2${houseList[index].post.owner.phone}",
                                                                    context);
                                                          },
                                                icon: const Icon(
                                                  FontAwesomeIcons.whatsapp,
                                                  color: Color(0XFF5E756D),
                                                ))),
                                        SizedBox(
                                            child: IconButton(
                                                onPressed:
                                                    houseList[index].status == 0
                                                        ? null
                                                        : () {
                                                            controller
                                                                .makePhoneCall(
                                                              "+2${houseList[index].post.owner.phone}",
                                                            );
                                                          },
                                                icon: const Icon(
                                                  FontAwesomeIcons
                                                      .phone, //phoneSlash
                                                  color: Color(0XFF5E756D),
                                                ))),
                                      ],
                                    ),
                                    houseList[index].status == 1
                                        ? const SizedBox()
                                        : Positioned(
                                            top: 20,
                                            child: Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                width: MediaQuery.of(context)
                                                        .size
                                                        .width /
                                                    2,
                                                height: 10,
                                                decoration: const BoxDecoration(
                                                    color: Colors.red,
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                2))),
                                              ),
                                            ),
                                          ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(0.0),
            child: Align(
                alignment: Alignment.topRight,
                child: Transform.rotate(
                  angle: 0.2,
                  child: Container(
                    width: 110,
                    height: 30,
                    decoration: BoxDecoration(
                        color: houseList[index].status == 0
                            ? Colors.red
                            : Colors.green,
                        borderRadius: const BorderRadius.all(Radius.circular(2))),
                    child: Center(
                        child: Text(
                      houseList[index].status == 0 ? "Waiting" : "Can deal",
                      style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontFamily: "Cairo"),
                    )),
                  ),
                )),
          )
        ],
      ),
    );
  }

  void showUserBottomSheet(BuildContext context, Owner owner) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const CircleAvatar(
                radius: 40,
                child: Icon(
                  Icons.person,
                  size: 40,
                  color: ColorsManager.mainOrange,
                ),
              ),
              const SizedBox(height: 16.0),
              Text("${owner.ownerName}",
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8.0),
              Text("ID: ${owner.nationalId}", style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 8.0),
              Text("Phone: ${owner.phone}", style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 8.0),
              Text("Email: ${owner.email}", style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 16.0),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[],
              ),
            ],
          ),
        );
      },
    );
  }
}
