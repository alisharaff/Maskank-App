import 'package:flutter/material.dart';

Container fourth_container_in_appartment_details() {
  return Container(
    width: 430,
    constraints: const BoxConstraints(
      minHeight: 0,
      maxHeight: double.infinity,
    ),
    color: Colors.white,
    child: const Padding(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                'Details',
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w500,
                  color: Color(0XFF5E756D),
                ),
              ),
            ],
          ),
          Row(
            children: [
              SizedBox(
                  width: 370,
                  child: Text(
                    'About Our Company (NEW EDGE).New Edge is a real estate advisory company that enables clients to buy, sell or rent real estate in Egypt for living as well as investment purposes.Through our unique contemporary style and total passion for connecting people to their dream property.We are not constrained by the boundaries of traditional real estate when it comes to buying, selling, renting or managing assets because we understand how this can be the biggest investment of their lives and we are always looking for new and innovative ways to satisfy our clients.',
                    overflow: TextOverflow.ellipsis,
                    maxLines: 10,
                  )),

            ],
          ),
          SizedBox(height: 15,)
        ],
      ),
    ),
  );
}
