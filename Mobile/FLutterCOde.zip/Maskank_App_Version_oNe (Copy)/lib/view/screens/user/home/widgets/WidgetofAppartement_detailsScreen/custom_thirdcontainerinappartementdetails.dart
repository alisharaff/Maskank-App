import 'package:flutter/material.dart';

Container third_container_in_appartment_details() {
  return Container(
    height: 205,
    color: Colors.white,
    child: const Padding(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                'Amenities',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.chair_outlined),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 130,
                child: Text(
                  ' Furnished',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              ),
              SizedBox(
                width: 32,
              ),
              Icon(Icons.soup_kitchen_outlined),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 132,
                child: Text(
                  'Kitchen Appliances',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.ac_unit),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 130,
                child: Text(
                  ' Central A/C',
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              ),
              SizedBox(
                width: 32,
              ),
              Icon(Icons.help_outline),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 132,
                child: Text(
                  'Security',
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.handyman_outlined),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 130,
                child: Text(
                  'Built in Wardrobes',
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              ),
              SizedBox(
                width: 32,
              ),
              Icon(Icons.receipt_outlined),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 130,
                child: Text(
                  'Lobby in Building',
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.balcony_outlined),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 132,
                child: Text(
                  'Balcony',
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              ),
              SizedBox(
                width: 32,
              ),
              Icon(Icons.close_fullscreen_outlined),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                width: 130,
                child: Text(
                  'Walk-in Closet',
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          )
        ],
      ),
    ),
  );
}
