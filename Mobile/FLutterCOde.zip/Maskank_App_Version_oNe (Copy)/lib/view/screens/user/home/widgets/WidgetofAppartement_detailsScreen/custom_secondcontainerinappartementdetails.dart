import 'package:flutter/material.dart';

Container second_container_in_appartment_details() {
  return Container(
    height: 197,
    color: Colors.white,
    child: const Padding(
      padding: EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        children: [
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.apartment_outlined),
              SizedBox(
                width: 10,
              ),
              Text(
                'Property Type:',
                style: TextStyle(
                    fontSize: 13,
                    color: Color(0XFF5E756D),
                    fontWeight: FontWeight.w500),
              ),
              SizedBox(
                width: 80,
              ),
              SizedBox(
                width: 107,
                child: Text(
                  'Appartement',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.space_bar),
              SizedBox(
                width: 10,
              ),
              Text(
                'Property Size:',
                style: TextStyle(
                    fontSize: 13,
                    color: Color(0XFF5E756D),
                    fontWeight: FontWeight.w500),
              ),
              SizedBox(
                width: 80,
              ),
              SizedBox(
                width: 107,
                child: Text(
                  '1,066ft(99m)',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.bed_outlined),
              SizedBox(
                width: 10,
              ),
              Text(
                'Bedrooms:',
                style: TextStyle(
                    fontSize: 13,
                    color: Color(0XFF5E756D),
                    fontWeight: FontWeight.w500),
              ),
              SizedBox(
                width: 100,
              ),
              SizedBox(
                width: 107,
                child: Text(
                  '2',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            children: [
              Icon(Icons.bathtub_outlined),
              SizedBox(
                width: 10,
              ),
              Text(
                'Bathrooms:',
                style: TextStyle(
                    fontSize: 13,
                    color: Color(0XFF5E756D),
                    fontWeight: FontWeight.w500),
              ),
              SizedBox(
                width: 97,
              ),
              SizedBox(
                width: 107,
                child: Text(
                  '2',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0XFF5E756D),
                      fontWeight: FontWeight.w500),
                ),
              )
            ],
          )
        ],
      ),
    ),
  );
}
