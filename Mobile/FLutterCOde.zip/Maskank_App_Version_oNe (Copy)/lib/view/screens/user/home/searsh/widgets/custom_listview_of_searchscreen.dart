import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:maskank/data/model/search_model.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/view/base/noData/no_data.dart';
import 'package:maskank/view/screens/user/home/apartement_details/apartement_details.dart';

class SearchScreenListViewWidget extends StatelessWidget {
  final List<SearchHouseModel> houseSearchList;

  const SearchScreenListViewWidget({super.key, required this.houseSearchList});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height / 1.5,
      child: houseSearchList.isEmpty
          ? const NoData()
          : ListView.builder(
              physics: const BouncingScrollPhysics(),
              itemCount: houseSearchList.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ApartementDetails(
                            potId: houseSearchList[index].id,
                          ),
                        ),
                      );
                    },
                    child: Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Container(
                          width: 392,
                          height: 265,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: Colors.white,
                          ),
                          child: Column(
                            children: [
                              Container(
                                height: 170,
                                width: 392,
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(16),
                                    topRight: Radius.circular(16),
                                  ),
                                  image: DecorationImage(
                                      image: NetworkImage(
                                          houseSearchList[index].images[0]),
                                      fit: BoxFit.fill),
                                ),
                              ),
                              Text(
                                '${houseSearchList[index].price} EGP/month',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(
                                height: 7,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(
                                    FontAwesomeIcons.mapLocation,
                                    color: ColorsManager.mainLightGreen,
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  SizedBox(
                                    child: Text(
                                      '${houseSearchList[index].region} - ${houseSearchList[index].city}',
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Color(0XFFABAC9C),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              const SizedBox(
                                height: 7,
                              ),
                              Row(
                                children: [
                                  const SizedBox(width: 100),
                                  Icon(
                                    Icons.bed,
                                    color: const Color(0XFFABAC9C)
                                        .withOpacity(0.5),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    houseSearchList[index].bedrooms.toString(),
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFFABAC9C),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Icon(
                                    Icons.bathtub,
                                    color: const Color(0XFFABAC9C)
                                        .withOpacity(0.5),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    houseSearchList[index].bathrooms.toString(),
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFFABAC9C),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Image.asset('assets/images/Frame 108.png'),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '${houseSearchList[index].size.toString()} m²',
                                    style: const TextStyle(
                                        color: Color(0XFFABAC9C)),
                                  ),
                                ],
                              )
                            ],
                          ),
                        )));
              }),
    );
  }
}
