import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:get/get.dart';
import 'package:maskank/data/model/post_details_model.dart';

class SliderAppartementDetails extends StatefulWidget {
  final List imageList;
  final PostDetails data;
  SliderAppartementDetails({
    super.key,
    required this.imageList,
    required this.data,
  });

  @override
  SliderAppartementDetailsState createState() =>
      SliderAppartementDetailsState();
}

class SliderAppartementDetailsState extends State<SliderAppartementDetails> {
  int _currentIndex = 0;
  // final List<String> photos = [
  //   'assets/images/Rectangle 18.png',
  //   'assets/images/Rectangle 18.png',
  //   'assets/images/Rectangle 18.png',
  // ];

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Stack(
            children: [
              SizedBox(
                // height: 230,
                // width: 460,
                child: CarouselSlider.builder(
                  itemCount: widget.imageList.length,
                  itemBuilder:
                      (BuildContext context, int index, int realIndex) {
                    return Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: NetworkImage(widget.imageList[index]),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                  options: CarouselOptions(
                    enlargeCenterPage: true,
                    aspectRatio: 9 / 9,
                    viewportFraction: 1.03,
                    autoPlay: true,
                    autoPlayInterval: const Duration(seconds: 3),
                    autoPlayAnimationDuration:
                        const Duration(milliseconds: 800),
                    autoPlayCurve: Curves.fastOutSlowIn,
                    pauseAutoPlayOnTouch: true,
                    height: 230,
                    initialPage: 0,
                    enableInfiniteScroll: true,
                    reverse: false,
                    onPageChanged: (index, reason) {
                      setState(() {
                        _currentIndex = index;
                      });
                    },
                  ),
                ),
              ),
              IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios_new_outlined,
                    color: Colors.white,
                  )),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: FractionallySizedBox(
                  widthFactor: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: widget.imageList.asMap().entries.map((entry) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _currentIndex = entry.key;
                          });
                        },
                        child: Container(
                          width: _currentIndex == entry.key ? 18.0 : 13.0,
                          height: _currentIndex == entry.key ? 18.0 : 13.0,
                          margin: const EdgeInsets.symmetric(
                              vertical: 10.0, horizontal: 4.0),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _currentIndex == entry.key
                                ? Colors.white
                                : Colors.grey,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 15,
          ),
          Text(
            '${widget.data.price} EGP/month',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w400,
            ),
          ),
          const Text(
            'Furnished apartment for rent, first residence',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
