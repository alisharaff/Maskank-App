import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/post_controller.dart';
import 'package:maskank/controller/user/home_user_controller.dart';
import 'package:maskank/view/screens/user/home/apartement_details/apartement_details.dart';
import 'package:maskank/view/screens/user/home/widgets/second_card.dart';

class RecentSearchListview extends StatelessWidget {
  const RecentSearchListview({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        height: MediaQuery.of(context).size.height * 0.4 - 23,
        child: GetBuilder<HomeUserController>(
          init: HomeUserController()..getInfo(),
          builder: (controller) => ListView.builder(
              physics: const BouncingScrollPhysics(),
              scrollDirection: Axis.horizontal,
              itemCount: controller.houseList.length,
              reverse: true,
              itemBuilder: (context, index) {
                return GestureDetector(
                    onTap: () {
                      // if (Get.put(PostController()).isLoad == true) {
                      Get.put(PostController())
                          .getPostDetials(controller.houseList[index].id);
                      Future.delayed(Duration(seconds: 1), () {
                        Get.to(() => ApartementDetails(
                              potId: controller.houseList[index].id,
                            ));
                      });

                      //    }
                    },
                    child: controller.isLoad
                        ? const Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Center(
                                child: CircularProgressIndicator(
                              color: Color(0xffABAC9C),
                            )),
                          )
                        : controller.houseList[index].status == 0
                            ? const SizedBox()
                            : RecentCard(
                                index: index,
                                isLoad: Get.put(PostController()).isLoad,
                              ));
              }),
        ));
  }
}
