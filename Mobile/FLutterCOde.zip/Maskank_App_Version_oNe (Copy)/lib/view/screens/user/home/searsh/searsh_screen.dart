import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/search_controller.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/view/screens/user/home/filter/filter_screen.dart';
import 'package:maskank/view/screens/user/home/searsh/widgets/custom_listview_of_searchscreen.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFFEAF0EC),
      body: GetBuilder<SearchUserController>(
        init: SearchUserController(),
        builder: (controller) => Padding(
          padding: const EdgeInsets.only(top: 8, right: 8, left: 8, bottom: 16),
          child: ListView(
            children: [
              Row(
                children: [
                  IconButton(
                      onPressed: () {
                        Get.back();
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios_new,
                        size: 25,
                        color: Colors.black,
                      )),
                  const Text(
                    'Exploer',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Besley",
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Expanded(
                    flex: 5,
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: TextFormField(
                        controller: controller.searchField,
                        decoration: const InputDecoration(
                          hintText: 'Search Apartment',
                          hintStyle: TextStyle(color: Colors.grey),
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.all(12),
                          prefixIcon: Icon(
                            Icons.search,
                            color: Colors.grey,
                          ),
                        ),
                        onChanged: (value) {
                          controller.getSearchInfo();
                        },
                      ),
                    ),
                  ),
                  Expanded(
                    child: IconButton(
                      onPressed: () {
                        Get.to(() => const FilterScreen());
                      },
                      icon: const Icon(
                        Icons.tune_rounded,
                        color: ColorsManager.mainOrange,
                      ),
                      iconSize: 35,
                    ),
                  )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              const Text(
                'Recommendations',
                style: TextStyle(
                    fontSize: 18,
                    color: ColorsManager.gray,
                    fontWeight: FontWeight.w600,
                    fontFamily: "Cairo"),
              ),
              const SizedBox(
                height: 10,
              ),
              SearchScreenListViewWidget(
                houseSearchList: controller.houseSearchList,
              )
            ],
          ),
        ),
      ),
    );
  }
}
