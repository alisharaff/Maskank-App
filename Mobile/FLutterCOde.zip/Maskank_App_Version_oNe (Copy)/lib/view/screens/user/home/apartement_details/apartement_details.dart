import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/post_controller.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/view/screens/user/home/widgets/WidgetofAppartement_detailsScreen/custom_firstcontainerinappartementdetails.dart';

class ApartementDetails extends StatelessWidget {
  final int potId;

  const ApartementDetails({super.key, required this.potId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFFEAF0EC),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GetBuilder<PostController>(
          builder: (controller) => Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width / 2,
                child: SizedBox(
                  height: 46,
                  child: ElevatedButton(
                    onPressed: controller.isRequest
                        ? () {
                            controller.requestPost(potId);
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0XFFFF725E),
                    ),
                    child: Text(
                      controller.isRequest ? 'BOOK' : 'Waiting',
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
              IconButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          icon: const Icon(
                            Icons.info_rounded,
                            size: 40,
                            color: ColorsManager.mainOrange,
                          ),
                          content:  Text(
                            'Dear_Renter_we_are_happy_that_you_are_using_the_Maskanak_application_now'.tr,
                            style: const TextStyle(
                              color: ColorsManager.gray,
                              fontFamily: 'Besley',
                              fontSize: 18,
                            ),
                          ),
                          actions: [
                            TextButton(
                              child: const Text(
                                'OK',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontFamily: 'Besley',
                                  fontSize: 14,
                                ),
                              ),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        );
                      },
                    );
                  },
                  icon: const Icon(
                    Icons.info_outline_rounded,
                    size: 35,
                    color: ColorsManager.mainOrange,
                  ))
            ],
          ),
        ),
      ),
      body: GetBuilder<PostController>(
          init: PostController()..getPostDetials(potId),
          builder: (controller) {
            return ListView(
              // physics: const BouncingScrollPhysics(),
              children: [
                SliderAppartementDetails(
                  data: controller.postDetails,
                  imageList: controller.postDetails.images,
                ),
                const SizedBox(height: 10),
                Container(
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 15,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Row(
                              children: [
                                Icon(
                                  FontAwesomeIcons.treeCity,
                                  size: 30,
                                  color: Color(0XFF5E756D),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Text(
                                  'Property Info',
                                  style: TextStyle(
                                      fontSize: 20,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                            Transform.rotate(
                              angle: 0.2,
                              child: Container(
                                height: 45,
                                decoration: const BoxDecoration(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(20)),
                                    color: ColorsManager.mainOrange),
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Center(
                                      child: Text(
                                    controller.postDetails.purpose.toString(),
                                    style: const TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                        fontFamily: "cairo",
                                        fontWeight: FontWeight.bold),
                                  )),
                                ),
                              ),
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 12,
                        ),
                        const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              Icon(Icons.apartment_outlined),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Property Type:',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                              SizedBox(
                                width: 80,
                              ),
                              SizedBox(
                                width: 107,
                                child: Text(
                                  'Appartement',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const Icon(Icons.space_bar),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                'Property Size:',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                              const SizedBox(
                                width: 80,
                              ),
                              SizedBox(
                                width: 107,
                                child: Text(
                                  '${controller.postDetails.size.toString()} m²',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const Icon(Icons.bed_outlined),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                'Bedrooms:',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                              const SizedBox(
                                width: 100,
                              ),
                              SizedBox(
                                width: 107,
                                child: Text(
                                  controller.postDetails.bedrooms.toString(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const Icon(Icons.bathtub_outlined),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                'Bathrooms:',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                              const SizedBox(
                                width: 97,
                              ),
                              SizedBox(
                                width: 107,
                                child: Text(
                                  controller.postDetails.bathrooms.toString(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  // height: 197,
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 15,
                        ),
                        const Row(
                          children: [
                            Icon(
                              FontAwesomeIcons.mapLocation,
                              size: 30,
                              color: Color(0XFF5E756D),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              'Property Location',
                              style: TextStyle(
                                  fontSize: 20,
                                  color: Color(0XFF5E756D),
                                  fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const Icon(Icons.location_history),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                'Region',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                              const SizedBox(
                                width: 80,
                              ),
                              SizedBox(
                                width: 107,
                                child: Text(
                                  controller.postDetails.region.toString(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            children: [
                              const Icon(FontAwesomeIcons.locationCrosshairs),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                'City',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                              const SizedBox(
                                width: 100,
                              ),
                              SizedBox(
                                width: 107,
                                child: Text(
                                  controller.postDetails.city.toString(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFF5E756D),
                                      fontWeight: FontWeight.w500),
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  height: 205,
                  color: Colors.white,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              'Amenities',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Row(
                          children: [
                            Icon(Icons.chair_outlined),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 130,
                              child: Text(
                                ' Furnished',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              width: 32,
                            ),
                            Icon(Icons.soup_kitchen_outlined),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 132,
                              child: Text(
                                'Kitchen Appliances',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Row(
                          children: [
                            Icon(Icons.ac_unit),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 130,
                              child: Text(
                                ' Central A/C',
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              width: 32,
                            ),
                            Icon(Icons.help_outline),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 132,
                              child: Text(
                                'Security',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Row(
                          children: [
                            Icon(Icons.handyman_outlined),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 130,
                              child: Text(
                                'Built in Wardrobes',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              width: 32,
                            ),
                            Icon(Icons.receipt_outlined),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 130,
                              child: Text(
                                'Lobby in Building',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            )
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                        Row(
                          children: [
                            Icon(Icons.balcony_outlined),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 132,
                              child: Text(
                                'Balcony',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              width: 32,
                            ),
                            Icon(Icons.close_fullscreen_outlined),
                            SizedBox(
                              width: 10,
                            ),
                            SizedBox(
                              width: 130,
                              child: Text(
                                'Walk-in Closet',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: Color(0XFF5E756D),
                                    fontWeight: FontWeight.w500),
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  width: 430,
                  constraints: const BoxConstraints(
                    minHeight: 0,
                    maxHeight: double.infinity,
                  ),
                  color: Colors.white,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Column(
                      children: [
                        const Row(
                          children: [
                            Text(
                              'Details',
                              textAlign: TextAlign.start,
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w500,
                                color: Color(0XFF5E756D),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            SizedBox(
                                width: 370,
                                child: Text(
                                  controller.postDetails.description.toString(),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 10,
                                )),
                          ],
                        ),
                        const SizedBox(
                          height: 15,
                        )
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const SizedBox(
                  height: 10,
                ),
              ],
            );
          }),
    );
  }
}
