import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/post_controller.dart';
import 'package:maskank/controller/user/home_user_controller.dart';
import 'package:maskank/view/screens/user/home/apartement_details/apartement_details.dart';

import 'package:maskank/view/screens/user/home/widgets/pouplar_home_card.dart';

class CustomPopularListview extends StatelessWidget {
  const CustomPopularListview({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeUserController>(
        builder: (controller) => ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: controller.houseList.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                  onTap: () {
                    Get.put(PostController())
                        .getPostDetials(controller.houseList[index].id);
                    Future.delayed(const Duration(seconds: 1), () {
                      Get.to(() => ApartementDetails(
                            potId: controller.houseList[index].id,
                          ));
                    });
                  },
                  child: controller.houseList[index].status == 0
                      ? const SizedBox()
                      : PouplarHomeCard(
                          index: index,
                        ));
            }));
  }
}
