import 'dart:math';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart' as slider_;
import 'package:syncfusion_flutter_sliders/sliders.dart';

class RangeSelectorPage extends StatefulWidget {
  const RangeSelectorPage({super.key});

  @override
  _RangeSelectorPageState createState() => _RangeSelectorPageState();
}

class _RangeSelectorPageState extends State<RangeSelectorPage> {
  final DateTime dateMin = DateTime(2003, 01, 01);
  final DateTime dateMax = DateTime(2010, 01, 01);
  final SfRangeValues dateValues =
      SfRangeValues(DateTime(2005, 01, 01), DateTime(2008, 01, 01));
  late List<Data> chartData = getChartData();
  double minPrice = 0;
  double maxPrice = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(0),
      padding: const EdgeInsets.all(0),
      child: Stack(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 0),
            child: Center(
              child: SfRangeSelector(
                min: dateMin,
                max: dateMax,
                initialValues: dateValues,
                labelPlacement: slider_.LabelPlacement.betweenTicks,
                interval: 1,
                dateIntervalType: DateIntervalType.years,
                dateFormat: DateFormat.y(),
                showTicks: true,
                showLabels: true,
                // onChangeStart: (DateRangePickerSelectionChangedArgs args) {
                //   setState(() {
                //     minPrice = getPriceAtDate(args.value.startValue);
                //   });
                // },
                // onChangeEnd: (DateRangePickerSelectionChangedArgs args) {
                //   setState(() {
                //     maxPrice = getPriceAtDate(args.value.endValue);
                //   });
                // },
                child: SizedBox(
                  height: 200,
                  child: SfCartesianChart(
                    margin: const EdgeInsets.all(0),
                    primaryXAxis: DateTimeAxis(
                      minimum: dateMin,
                      maximum: dateMax,
                      isVisible: false,
                    ),
                    primaryYAxis:
                        const NumericAxis(isVisible: false, maximum: 4),
                    series: <SplineAreaSeries<Data, DateTime>>[
                      SplineAreaSeries<Data, DateTime>(
                          dataSource: chartData,
                          xValueMapper: (Data sales, int index) => sales.x,
                          yValueMapper: (Data sales, int index) => sales.y)
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Text(
              'Price Range: $minPrice - $maxPrice',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  List<Data> getChartData() {
    List<Data> chartData = [];
    for (int i = 2003; i <= 2010; i++) {
      chartData.add(Data(DateTime(i), Random().nextDouble() * 100));
    }
    return chartData;
  }

  double getPriceAtDate(DateTime date) {
    List<Data> data = getChartData();

    // Find the two data points that the date lies between
    int index1 = -1;
    int index2 = -1;
    for (int i = 0; i < data.length - 1; i++) {
      if (data[i].x.isBefore(date) && data[i + 1].x.isAfter(date)) {
        index1 = i;
        index2 = i + 1;
        break;
      }
    }

    // If no data points were found, return 0
    if (index1 == -1 || index2 == -1) {
      return 0.0;
    }

    // Use the linear interpolation formula to calculate the price at the given date
    double t = (date.year - data[index1].x.year) /
        (data[index2].x.year - data[index1].x.year);
    return data[index1].y + t * (data[index2].y - data[index1].y);
  }
}

class Data {
  DateTime x;
  double y;

  Data(this.x, this.y);
}
