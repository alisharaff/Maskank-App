import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/home_user_controller.dart';

import 'package:maskank/view/screens/user/home/widgets/explore_care.dart';
import 'package:maskank/view/screens/user/home/widgets/recent_search_listview.dart';
import 'package:maskank/view/screens/user/home/widgets/custom_popular_listview.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: GetBuilder<HomeUserController>(
      init: HomeUserController(),
      builder: (controller) => RefreshIndicator(
        onRefresh: () async {
          await controller.getInfo();
          return;
        },
        child: Scaffold(
          backgroundColor: const Color(0XFFEAF0EC),
          body: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 5),
                  Text(
                    'Hello, ${controller.userName}',
                    textAlign: TextAlign.start,
                    style: const TextStyle(
                        color: Colors.black, fontSize: 25, fontFamily: 'Cairo'),
                  ),
                  const SizedBox(height: 20),
                  const HomeExploreCard(),
                  const SizedBox(height: 20),
                   Text(
                    'Recent_searches'.tr,
                    style: const TextStyle(
                        fontFamily: "Besley",
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  const RecentSearchListview(),
                  const SizedBox(height: 10),
                   Row(
                    children: [
                      Text(
                        'Popular_places'.tr,
                        style: const TextStyle(
                            fontFamily: "Besley",
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        width: 150,
                      ),
                      // Text(
                      //   'View all',
                      //   style:
                      //       TextStyle(fontSize: 20, color: Color(0XFFABAC9C)),
                      // )
                    ],
                  ),
                  const SizedBox(height: 10),
                  const CustomPopularListview()
                ],
              ),
            ),
          ),
        ),
      ),
    ));
  }
}
