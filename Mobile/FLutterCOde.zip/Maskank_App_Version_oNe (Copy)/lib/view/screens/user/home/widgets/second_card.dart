import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/home_user_controller.dart';
import 'package:maskank/util/images.dart';

class RecentCard extends StatelessWidget {
  const RecentCard({super.key, required this.index, required this.isLoad});
  final int index;
  final bool isLoad;
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.only(right: 10),
        child: GetBuilder<HomeUserController>(
          builder: (controller) => Row(
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 0.60,
                      height: MediaQuery.of(context).size.height * 0.22,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(16),
                          topRight: Radius.circular(16),
                        ),
                        image: DecorationImage(
                          image: controller.houseList[index].images.isEmpty
                              ? const AssetImage(AppImages.noData) as ImageProvider
                              : NetworkImage(
                                  controller.houseList[index].images[0]),
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            child: Text(
                              '${controller.houseList[index].price} EGP/month',
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Image.asset('assets/images/Group.png'),
                              const SizedBox(
                                width: 12,
                              ),
                              SizedBox(
                                width: 130,
                                child: Text(
                                  '${controller.houseList[index].city} , ${controller.houseList[index].region}',
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Color(0XFFABAC9C),
                                  ),
                                ),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Icon(
                                Icons.bed,
                                color: const Color(0XFFABAC9C).withOpacity(0.5),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                '${controller.houseList[index].bedrooms}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Color(0XFFABAC9C),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Icon(
                                Icons.bathtub,
                                color: const Color(0XFFABAC9C).withOpacity(0.5),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                '${controller.houseList[index].bathrooms}',
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Color(0XFFABAC9C),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              Image.asset('assets/images/Frame 108.png'),
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                "${controller.houseList[index].size.toString()} m²",
                                style:
                                    const TextStyle(color: Color(0XFFABAC9C)),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}
