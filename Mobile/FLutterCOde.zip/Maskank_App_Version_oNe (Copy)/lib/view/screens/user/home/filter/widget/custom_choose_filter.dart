import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FilterChoose extends StatelessWidget {
  final List<String> itemList;
  final RxInt selectedIndex;
  final RxString selectedValue;
  final void Function(String) onChange; // Callback function

  FilterChoose({
    required Key? key,
    required this.itemList,
    required this.selectedIndex,
    required this.selectedValue,
    required this.onChange,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height / 18,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          Obx(() => Wrap(
                spacing: 8.0,
                runSpacing: 8.0,
                children: itemList.asMap().entries.map((entry) {
                  final index = entry.key;
                  final text = entry.value;
                  final isSelected = selectedIndex.value == index;

                  return GestureDetector(
                    onTap: () {
                      selectedIndex.value = index;
                      selectedValue.value = text;
                      onChange(text); // Call the callback function
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        boxShadow: isSelected
                            ? [
                                const BoxShadow(
                                  color: Colors.white,
                                ),
                              ]
                            : null,
                        color: isSelected
                            ? const Color(0XFFFF725E)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.white,
                          width: 2.0,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          text,
                          style: TextStyle(
                            color:
                                isSelected ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              )),
        ],
      ),
    );
  }
}