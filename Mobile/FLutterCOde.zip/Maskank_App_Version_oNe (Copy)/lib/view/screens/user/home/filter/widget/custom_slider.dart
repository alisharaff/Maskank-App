import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FilterSlider extends StatelessWidget {
  final RxDouble value = 0.0.obs;

   FilterSlider({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Slider(
        value: value.value,
        min: 0,
        max: 100,
        divisions: 100,
        activeColor: const Color(0XFFFF725E),
        inactiveColor: Colors.white,
        label: value.value.round().toString(),
        onChanged: (newValue) {
          value.value = newValue;
        },
      ),
    );
  }
}
