import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/search_controller.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/view/screens/user/home/filter/widget/custom_choose_filter.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

class FilterScreen extends StatefulWidget {
  const FilterScreen({super.key});

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  SfRangeValues _values = const SfRangeValues(40.0, 80.0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0XFFEAF0EC),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GetBuilder<SearchUserController>(
          builder: (controller) => Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width / 2,
                child: SizedBox(
                  height: 46,
                  child: ElevatedButton(
                    onPressed: () {
                      controller.getFilterInfo();
                      Get.back();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0XFFFF725E),
                    ),
                    child:  Text(
                      'Apply_Filter'.tr,
                      style:
                          TextStyle(color: Colors.white, fontFamily: "Cairo"),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: GetBuilder<SearchUserController>(
        init: SearchUserController(),
        builder: (controller) => Padding(
          padding: const EdgeInsets.only(top: 10, right: 10, left: 10),
          child: ListView(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                   Text(
                    'Your_Filter'.tr,
                    style: const TextStyle(fontFamily: "Besley", fontSize: 24),
                  ),
                  TextButton(
                      onPressed: () {
                        Get.back();
                      },
                      child:  Text(
                        'close'.tr,
                        style:
                            const TextStyle(color: Color(0XFFFF725E), fontSize: 18),
                      ))
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
               Text(
                'Student'.tr,
                style: const TextStyle(fontFamily: "Besley", fontSize: 24),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
              FilterChoose(
                itemList:  ['Any'.tr, 'Personal'.tr, 'student'.tr],
                key: null,
                selectedIndex: RxInt(0),
                selectedValue: RxString('Any'),
                onChange: (value) {
                  print('Selected value changed to: $value');
                },
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
               Text(
                'Property_Type'.tr,
                style: const TextStyle(fontFamily: "Besley", fontSize: 24),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
              FilterChoose(
                itemList:  [
                  'Any'.tr,
                  'Apartment'.tr,
                  'Studio'.tr,
                  'Duplex'.tr,
                ],
                key: null,
                selectedIndex: RxInt(0), // Initialize selectedIndex
                selectedValue: RxString('Any'),
                onChange: (value) {
                  print('Selected value changed to: $value');
                },
              ),
              Padding(
                padding:  const EdgeInsets.only(left: 10, right: 10),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                       Text(
                        'location'.tr,
                        style: const TextStyle(fontFamily: "Besley", fontSize: 24),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Container(
                          decoration: BoxDecoration(
                            color: const Color(0xffffffff),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: DropdownButtonFormField(
                            decoration: InputDecoration(
                              hintText: 'Choose_your_city'.tr,
                              hintStyle: const TextStyle(
                                color: Color(0xffABAC9C),
                                fontSize: 22,
                                fontFamily: 'Besley',
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    const BorderSide(color: Color(0xffffffff)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide:
                                    const BorderSide(color: Color(0xffffffff)),
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 12),
                            ),
                            icon: const Padding(
                              padding: EdgeInsets.only(right: 10),
                              child: Image(
                                image: AssetImage(
                                  'assets/images/arrow down.jpg',
                                ),
                              ),
                            ),
                            value: controller.selectedCity,
                            items: ['Alexandria'.tr, 'Cairo'.tr, 'Giza'.tr].map(
                              (value) {
                                return DropdownMenuItem(
                                  value: value,
                                  child: Container(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text(
                                      value,
                                      style: TextStyle(
                                        color: controller.selectedCity == value
                                            ? const Color(0xffFF725E)
                                            : const Color(0xffABAC9C),
                                        fontSize: 20,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ).toList(),
                            onChanged: (newValue) {
                              controller.selectedCity = newValue;
                              controller.changeCity();
                            },
                          ),
                        ),
                      ),
                    ]),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
               Text(
                'Your_budget'.tr,
                style: const TextStyle(fontFamily: "Besley", fontSize: 24),
              ),
              SfRangeSlider(
                min: 200.0,
                max: 50000.0,
                values: _values,
                interval: 10000,
                showTicks: true,
                showLabels: true,
                enableTooltip: true,
                inactiveColor: Colors.white,
                activeColor: const Color(0XFFFF725E),
                minorTicksPerInterval: 1,
                onChanged: (SfRangeValues values) {
                  setState(() {
                    _values = values;
                    controller.selectedPrice = values.start;
                  });
                },
              ),
              const SizedBox(
                height: 10,
              ),
               Text(
                'Bedrooms'.tr,
                style: const TextStyle(fontSize: 24),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
              FilterChoose(
                itemList:  ['Studio'.tr, '1', '2', '3', '4', '5', '6'],
                key: null,
                selectedIndex: RxInt(0), // Initialize selectedIndex
                selectedValue: RxString('Any'),
                onChange: (value) {
                  print('Selected value changed to: $value');
                },
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
               Text(
                'Bathrooms'.tr,
                style: const TextStyle(fontSize: 24),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
              FilterChoose(
                itemList:  ['Any'.tr, '1', '2', '3', '4', '5', '6'],
                key: null,
                selectedIndex: RxInt(0), // Initialize selectedIndex
                selectedValue: RxString('Any'),
                onChange: (value) {
                  print('Selected value changed to: $value');
                },
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                   Text(
                    'Property_Size'.tr,
                    style: const TextStyle(fontFamily: "Besley", fontSize: 24),
                  ),
                  IconButton(
                      onPressed: () {
                        controller.noSizePro();
                      },
                      icon: const Icon(
                        Icons.block_outlined,
                        color: ColorsManager.mainOrange,
                      ))
                ],
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '',
                    style: TextStyle(
                        color: controller.noSize
                            ? Colors.grey
                            : const Color(0xff5E756D),
                        fontFamily: 'Besley',
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  controller.noSize
                      ?  Text(
                          "All".tr,
                          style: const TextStyle(
                              color: Color(0xff5E756D),
                              fontFamily: 'Besley',
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        )
                      : Text(
                          controller.selectedSize.toStringAsFixed(2).toString(),
                          style: const TextStyle(
                              color: Color(0xff5E756D),
                              fontFamily: 'Besley',
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                ],
              ),
              controller.noSize
                  ?  Center(
                      child: Text(
                        "You_want_All_Size".tr,
                        style: const TextStyle(
                            color: Color(0xff5E756D),
                            fontFamily: 'Besley',
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    )
                  : SfSlider(
                      inactiveColor: ColorsManager.moreLightGray,
                      activeColor: ColorsManager.mainOrange,
                      min: 30.0,
                      max: 1000.0,
                      value: controller.selectedSize,
                      interval: 150,
                      showTicks: true,
                      showLabels: true,
                      enableTooltip: true,
                      minorTicksPerInterval: 1,
                      onChanged: (dynamic value) {
                        controller.changeSize(value);
                      },
                    ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 50,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
