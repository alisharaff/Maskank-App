import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/view/screens/user/home/searsh/searsh_screen.dart';
import 'package:maskank/util/images.dart';

class HomeExploreCard extends StatelessWidget {
  const HomeExploreCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: 134,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            image: const DecorationImage(
              image: AssetImage(AppImages.exploreCardImg),
              fit: BoxFit.cover,
            ),
          ),
        ),
         SizedBox(
          // width: 300,
          // height: 134,
          child: Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      'Search_for_real_state'.tr,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Text(
                      'to_suite_any_taste'.tr,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 80, left: 12),
          child: SizedBox(
            width: MediaQuery.of(context).size.width * 0.33,
            height: 44,
            child: ElevatedButton(
                onPressed: () {
                  Get.to(() => const SearchScreen());
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0XFF5E756D),
                ),
                child:  Row(
                  children: [
                    Text(
                      'Explore'.tr,
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                    ),
                    const Icon(
                      Icons.arrow_right,
                      color: Colors.white,
                    )
                  ],
                )),
          ),
        )
      ],
    );
  }
}
