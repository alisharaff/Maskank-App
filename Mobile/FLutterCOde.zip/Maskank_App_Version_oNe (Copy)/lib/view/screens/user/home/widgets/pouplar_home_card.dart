import 'package:favorite_button/favorite_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/home_user_controller.dart';
import 'package:maskank/util/images.dart';

class PouplarHomeCard extends StatelessWidget {
  final int index;
  const PouplarHomeCard({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GetBuilder<HomeUserController>(
          builder: (controller) => Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: Colors.white,
            ),
            child: Row(
              children: [
                Container(
                  width: 130,
                  height: 93,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(16),
                      bottomLeft: Radius.circular(16),
                    ),
                    image: DecorationImage(
                      image: controller.houseList[index].images.isEmpty
                          ? const AssetImage(AppImages.noData) as ImageProvider
                          : NetworkImage(controller.houseList[index].images[0]),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: SizedBox(
                          child: Text(
                            '${controller.houseList[index].price} EGP/Month',
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                            style: const TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          Image.asset('assets/images/Group.png'),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: 8.0, bottom: 5),
                            child: SizedBox(
                              width: 160,
                              child: Text(
                                '${controller.houseList[index].city} , ${controller.houseList[index].region}',
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: const TextStyle(
                                  fontSize: 10,
                                  color: Color(0XFFABAC9C),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.bed,
                              color: const Color(0XFFABAC9C).withOpacity(0.5),
                            ),
                            const SizedBox(
                              width: 5,
                            ),
                            Text('${controller.houseList[index].bedrooms}'),
                            const SizedBox(
                              width: 5,
                            ),
                            Icon(
                              Icons.bathtub,
                              color: const Color(0XFFABAC9C).withOpacity(0.5),
                            ),
                            const SizedBox(
                              width: 5,
                            ),
                            Text(
                              '${controller.houseList[index].bathrooms}',
                            ),
                            const SizedBox(
                              width: 5,
                            ),
                            Image.asset('assets/images/Frame 108.png'),
                            const SizedBox(
                              width: 5,
                            ),
                            Text(
                              "${controller.houseList[index].size.toString()} m²",
                              style: const TextStyle(color: Color(0XFFABAC9C)),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                FavoriteButton(
                  iconSize: 45,
                  isFavorite: false,
                  valueChanged: (isFavorite) {
                    if (isFavorite == true) {
                      controller.addFavorite(controller.houseList[index].id);
                    }
                  },
                ),
              ],
            ),
          ),
        ));
  }
}
