import 'package:favorite_button/favorite_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/favorite_screen_controller.dart';
import 'package:maskank/data/model/post_model.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/view/screens/user/home/apartement_details/apartement_details.dart';

class FavoriteScreen extends StatelessWidget {
  const FavoriteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      icon: const Icon(
                        Icons.error,
                        size: 40,
                        color: ColorsManager.mainOrange,
                      ),
                      content:  Text(
                        'Dear_this_place_is_dedicated_to_important_posts_that_you_like_and_you_can_delete_a_post_from_here_by_clicking_on_the_heart.'.tr,
                        style: const TextStyle(
                          color: ColorsManager.gray,
                          fontFamily: 'Besley',
                          fontSize: 20,
                        ),
                      ),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: const Text(
                            'OK',
                            style: TextStyle(
                              color: Colors.black,
                              fontFamily: 'Besley',
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
              icon: const Icon(
                Icons.error_outline,
                color: ColorsManager.mainOrange,
              ))
        ],
        title:  Text(
          'Favorite_Posts'.tr,
          style: const TextStyle(
              color: Color(0XFF5E756D),
              fontFamily: "Besley",
              fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Get.put(FavoriteController()).getInfo();
          return;
        },
        child: SafeArea(
            child: SizedBox(
                width: MediaQuery.of(context).size.width,
                child: GetBuilder<FavoriteController>(
                  init: FavoriteController()..getInfo(),
                  builder: (controller) => controller.houseList.length != 0
                      ? ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          scrollDirection: Axis.vertical,
                          itemCount: controller.houseList.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => ApartementDetails(
                                      potId: controller.houseList[index].id,
                                    ),
                                  ),
                                );
                              },
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors
                                        .white, // Background color of the card
                                    borderRadius: BorderRadius.circular(8.0),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey
                                            .withOpacity(0.5), // Shadow color
                                        spreadRadius: 2, // Spread radius
                                        blurRadius: 5, // Blur radius
                                        offset: const Offset(0,
                                            3), // Offset in the X and Y direction
                                      ),
                                    ],
                                  ),
                                  child: PostCard(
                                    controller.houseList,
                                    index: index,
                                  ),
                                ),
                              ),
                            );
                          })
                      : Center(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Image.asset(
                                "assets/images/heart.gif",
                              ),
                               Text(
                                'Yor_Favorite_Posts_here!'.tr,
                                style: const TextStyle(
                                    fontFamily: "Besley",
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                        ),
                ))),
      ),
    );
  }
}

class PostCard extends StatelessWidget {
  final List<PostData> houseList;
  final int index;
  const PostCard(this.houseList, {super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(10),
        child: GetBuilder<FavoriteController>(
          builder: (controller) => Stack(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: Colors.white,
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width -
                              MediaQuery.of(context).size.width * 0.2,
                          height: MediaQuery.of(context).size.height * 0.22,
                          decoration: BoxDecoration(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(16),
                              topRight: Radius.circular(16),
                            ),
                            image: DecorationImage(
                              image: NetworkImage(
                                  controller.houseList[index].post.images[0]),
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            children: [
                              SizedBox(
                                child: Text(
                                  '${houseList[index].post.price} EGP/month',
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Row(
                                  children: [
                                    Image.asset('assets/images/Group.png'),
                                    const SizedBox(
                                      width: 12,
                                    ),
                                    SizedBox(
                                      child: Text(
                                        '${houseList[index].post.region} , ${houseList[index].post.city}',
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          color: Color(0XFFABAC9C),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Icon(
                                    Icons.bed,
                                    color: const Color(0XFFABAC9C)
                                        .withOpacity(0.5),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '${houseList[index].post.bedrooms}',
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFFABAC9C),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Icon(
                                    Icons.bathtub,
                                    color: const Color(0XFFABAC9C)
                                        .withOpacity(0.5),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '${houseList[index].post.bathrooms}',
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: Color(0XFFABAC9C),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Image.asset('assets/images/Frame 108.png'),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    '${houseList[index].post.size} m²',
                                    style: const TextStyle(
                                        color: Color(0XFFABAC9C)),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Align(
                  alignment: Alignment.topRight,
                  child: FavoriteButton(
                    iconSize: 45,
                    isFavorite: true,
                    valueChanged: (isFavorite) {
                      // if (isFavorite == true) {
                      controller
                          .removeFavorite(controller.houseList[index].post.id);

                      //}
                    },
                  ),
                ),
              )
            ],
          ),
        ));
  }
}
