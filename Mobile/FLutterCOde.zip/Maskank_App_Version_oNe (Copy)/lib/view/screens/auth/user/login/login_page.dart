import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/auth/login_user_controller.dart';
import 'package:maskank/util/images.dart';
import 'package:maskank/view/screens/auth/user/regester/regester_page.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffeaf0ec),
      body: SafeArea(
        child: GetBuilder<LoginUserController>(
          builder: (controller) {
            return ListView(
              children: [
                Stack(
                  children: [
                    SizedBox(
                        width: 110,
                        height: 110,
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Image.asset(AppImages.halfCircle),
                        )),
                    IconButton(
                        onPressed: () {
                          Get.back();
                        },
                        icon: const Icon(
                          Icons.arrow_back_ios_new,
                          size: 25,
                          color: Colors.white,
                        )),
                  ],
                ),
                 Text(
                  "Log_In".tr,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontFamily: 'Berkshire Swash',
                    fontSize: 48,
                    color: Color(0xffdba690),
                  ),
                ),
                Center(
                    child: Image.asset(
                  AppImages.loginImg,
                  height: 250,
                  width: 250,
                )),
                const SizedBox(
                  height: 8,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: SingleChildScrollView(
                    child: Form(
                      key: controller.loginUserformKey,
                      child: Column(
                        children: [
                          Container(
                            margin: const EdgeInsets.all(8),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: const Color(0xffeee1d8),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Color(0xffbdc2bf),
                                      offset: Offset(2, 3))
                                ]),
                            child: TextFormField(
                              controller: controller.username,
                              decoration:  InputDecoration(
                                icon: const Icon(
                                  Icons.person,
                                  color: Colors.white,
                                ),
                                border: InputBorder.none,
                                hintText: "User_name".tr,
                                hintStyle: const TextStyle(
                                  fontFamily: 'Berkshire Swash',
                                  color: Colors.white,
                                ),
                              ),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Please enter a username';
                                }
                                return null;
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: controller.password,
                      obscureText: !controller.isVisible,
                      decoration: InputDecoration(
                          icon: const Icon(
                            Icons.lock,
                            color: Colors.white,
                          ),
                          border: InputBorder.none,
                          hintText: "Password".tr,
                          hintStyle: const TextStyle(
                            fontFamily: 'Berkshire Swash',
                            color: Colors.white,
                          ),
                          suffixIcon: IconButton(
                            onPressed: controller.toggleVisibility,
                            icon: Icon(controller.isVisible
                                ? Icons.visibility
                                : Icons.visibility_off),
                            color: Colors.white,
                          )),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a password';
                        }
                        return null;
                      },
                    ),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                controller.isLogin == false
                    ? Padding(
                        padding: const EdgeInsets.only(
                            left: 80, right: 80, bottom: 20),
                        child: GestureDetector(
                          onTap: () {
                            controller.login();
                          },
                          child: Container(
                            alignment: Alignment.center,
                            width: 250,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              gradient: const LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [Color(0xffABAC9C), Color(0xffD7B59C)],
                              ),
                            ),
                            child:  Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Text(
                                "Login".tr,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Berkshire Swash',
                                    fontSize: 24),
                              ),
                            ),
                          ),
                        ),
                      )
                    : const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Center(
                            child: CircularProgressIndicator(
                          color: Color(0xffABAC9C),
                        )),
                      ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                     Text(
                      'Don’t_have_an_account'.tr,
                      style: const TextStyle(
                          color: Color(0xffdfb8a7),
                          fontSize: 14,
                          fontFamily: 'Besley'),
                    ),
                    GestureDetector(
                      onTap: () {
                        Get.to(()=>const RegesterPage());
                      },
                      child:  Text(
                        'SIGN_UP'.tr,
                        style: const TextStyle(
                          fontSize: 14,
                          fontFamily: 'Besley',
                          color: Color(0xff677c75),
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
