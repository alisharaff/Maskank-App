import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/user/auth/regester_user_controller.dart';
import 'package:maskank/util/images.dart';
import 'package:maskank/view/screens/auth/user/login/login_page.dart';

class RegesterPage extends StatelessWidget {
  const RegesterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffeaf0ec),
      body: SafeArea(
        child: SingleChildScrollView(
          child: GetBuilder<RegisterUserController>(
            builder: (registerController) => Form(
              key: registerController.registerUserFormKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Stack(
                    children: [
                      Align(
                        alignment: Alignment.topLeft,
                        child: Image.asset(AppImages.waveImg),
                      ),
                      IconButton(
                        onPressed: () {
                          Get.back();
                        },
                        icon: const Icon(
                          Icons.arrow_back_ios_new,
                          size: 25,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                   Text(
                    "Register".tr,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: 'Berkshire Swash',
                      fontSize: 48,
                      color: Color(0xffdba690),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: registerController.username,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a this field';
                        }
                        return null;
                      },
                      decoration:  InputDecoration(
                        icon: const Icon(
                          Icons.person,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf)),
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "User_name".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: registerController.fullname,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a this field';
                        }
                        return null;
                      },
                      decoration:  InputDecoration(
                        icon: const Icon(
                          Icons.person,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf)),
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "Full_name".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: registerController.email,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a this field';
                        }
                        return null;
                      },
                      keyboardType: TextInputType.emailAddress,
                      decoration:  InputDecoration(
                        icon: const Icon(
                          Icons.email,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf)),
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "email".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: registerController.phone,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a this field';
                        }
                        return null;
                      },
                      decoration:  InputDecoration(
                        icon: const Icon(
                          Icons.phone,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf)),
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "Phone".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: registerController.password,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a this field';
                        }
                        return null;
                      },
                      obscureText: !registerController.isPasswordVisible,
                      decoration: InputDecoration(
                        icon: const Icon(
                          Icons.lock,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf)),
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "Password".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                          ],
                        ),
                        suffixIcon: IconButton(
                          onPressed: () =>
                              registerController.toggleVisibility(),
                          icon: Icon(
                            registerController.isPasswordVisible
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.all(8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: const Color(0xffeee1d8),
                        boxShadow: const [
                          BoxShadow(
                              color: Color(0xffbdc2bf), offset: Offset(2, 3))
                        ]),
                    child: TextFormField(
                      controller: registerController.confirmPassword,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a this field';
                        }
                        return null;
                      },
                      obscureText: !registerController.isPasswordVisible,
                      decoration: InputDecoration(
                        icon: const Icon(
                          Icons.lock,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf))
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "Confirm_Password".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                          ],
                        ),
                        suffixIcon: IconButton(
                          onPressed: () =>
                              registerController.toggleVisibility(),
                          icon: Icon(
                            registerController.isPasswordVisible
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  registerController.isRegister == false
                      ? Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15.0),
                          child: GestureDetector(
                            onTap: () {
                              registerController.register();
                            },
                            child: Container(
                              alignment: Alignment.center,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(23.89),
                                gradient: const LinearGradient(
                                  begin: Alignment.centerLeft,
                                  end: Alignment.centerRight,
                                  colors: [
                                    Color(0xffABAC9C),
                                    Color(0xffD7B59C)
                                  ],
                                ),
                              ),
                              child:  Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  "SIGN_UP".tr,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontFamily: 'Berkshire Swash',
                                    fontSize: 24,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        )
                      : const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Center(
                              child: CircularProgressIndicator(
                            color: Color(0xffABAC9C),
                          )),
                        ),
                  const SizedBox(height: 5),
                  Padding(
                    padding:  const EdgeInsets.all(15.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                         Text(
                          'Already_have_an_accoun'.tr,
                          style: const TextStyle(
                              color: Color(0xffdfb8a7),
                              fontSize: 14,
                              fontFamily: 'Besley'),
                        ),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) {
                                  return const LoginPage();
                                },
                              ),
                            );
                          },
                          child:  Text(
                            'Log_In'.tr,
                            style: const TextStyle(
                              fontSize: 14,
                              fontFamily: 'Besley',
                              color: Color(0xff677c75),
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
