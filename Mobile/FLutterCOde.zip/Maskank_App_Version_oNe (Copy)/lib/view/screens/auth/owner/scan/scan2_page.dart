import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:maskank/view/screens/vertefication/verevication_done_screen.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  Uint8List? _image;
  File? selectedImage;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
           Padding(
            padding: const EdgeInsets.only(bottom: 40),
            child: Text(
              'Scan_Your_ID'.tr,
              style: const TextStyle(
                color: Color(0xffb8887f),
                fontFamily: 'Berkshire Swash',
                fontSize: 30,
              ),
            ),
          ),
           Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Text(
              'Now_place_your_phone_directly_on_top_of_your_id_photo_so_we_can_connect_securely'.tr,
              textAlign: TextAlign.center,
              style: const TextStyle(fontFamily: 'Besley'),
            ),
          ),
          Center(
            child: Stack(
              children: [
                _image != null
                    ? Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: ClipRRect(
                          borderRadius:
                              const BorderRadius.all(Radius.circular(10.0)),
                          child: SizedBox(
                            height: MediaQuery.of(context).size.height / 3.5,
                            child: Image(image: MemoryImage(_image!)),
                          ),
                        ),
                      )
                    : ClipRRect(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10.0)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 22, vertical: 30),
                          child: Image.asset('assets/images/Frame 81 (1).png'),
                        ),
                      ),
              ],
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: 220,
            height: 50,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              color: const Color(0xfffb8a79),
            ),
            child: GestureDetector(
              onTap: () {
                _image != null
                    ? Get.to(() => const VerteficationScreen())
                    : showImagepickerOption(context);
              },
              child: Text(
                _image != null ? "done".tr : "Scan_Now".tr,
                style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Berkshire Swash',
                    fontSize: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void showImagepickerOption(BuildContext context) {
    showModalBottomSheet(
        backgroundColor: Colors.white,
        context: context,
        builder: (builder) {
          return Padding(
            padding: const EdgeInsets.all(18.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height / 4.5,
              child: Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        pickImageFromGallery();
                      },
                      child: const SizedBox(
                        child: Column(
                          children: [
                            Icon(
                              Icons.image,
                              size: 70,
                            ),
                            Text('Gallery')
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        pickImageFromCamera();
                      },
                      child: const SizedBox(
                        child: Column(
                          children: [
                            Icon(
                              Icons.camera_alt,
                              size: 70,
                            ),
                            Text('Camera')
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
  //Gallery

  Future pickImageFromGallery() async {
    final returnImage =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (returnImage == null) return;
    setState(() {
      selectedImage = File(returnImage.path);
      _image = File(returnImage.path).readAsBytesSync();
    });
    Navigator.of(context).pop();
  }

//Camera
  Future pickImageFromCamera() async {
    final returnImage =
        await ImagePicker().pickImage(source: ImageSource.camera);
    if (returnImage == null) return;
    setState(() {
      selectedImage = File(returnImage.path);
      _image = File(returnImage.path).readAsBytesSync();
    });
    Navigator.of(context).pop();
  }
}
