import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:maskank/controller/owner/auth/regestter_owner_controller.dart';
import 'package:maskank/view/screens/auth/owner/login/login_page_owner.dart';
import '../../../../../util/images.dart';

class RegesterOwner extends StatelessWidget {
  const RegesterOwner({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffeaf0ec),
      body: Center(
        child: GetBuilder<RegesterOwnerController>(
          builder: (registerController) => ListView(
            children: [
              Stack(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Image.asset(AppImages.waveImg),
                  ),
                  IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      size: 25,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
               Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 0, bottom: 40),
                  child: Text(
                    "Register".tr,
                    style: const TextStyle(
                      fontFamily: 'Berkshire Swash',
                      fontSize: 48,
                      color: Color(0xffdba690),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 0.05,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.all(8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color(0xffeee1d8),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xffbdc2bf),
                                  offset: Offset(2, 3))
                            ]),
                        child: TextFormField(
                          controller: registerController.usernameController,
                          decoration:  InputDecoration(
                            icon: const Icon(
                              Icons.person,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    offset: Offset(2, 2.5),
                                    color: Color(0xffbdc2bf))
                              ],
                            ),
                            border: InputBorder.none,
                            hintText: "User_name".tr,
                            hintStyle: const TextStyle(
                              fontFamily: 'Berkshire Swash',
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    offset: Offset(0, 2),
                                    color: Color(0xffbdc2bf))
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.all(8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color(0xffeee1d8),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xffbdc2bf),
                                  offset: Offset(2, 3))
                            ]),
                        child: TextFormField(
                          controller: registerController.fullnameController,
                          decoration:  InputDecoration(
                            icon: const Icon(
                              Icons.person,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    offset: Offset(2, 2.5),
                                    color: Color(0xffbdc2bf))
                              ],
                            ),
                            border: InputBorder.none,
                            hintText: "Full_name".tr,
                            hintStyle: const TextStyle(
                              fontFamily: 'Berkshire Swash',
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    offset: Offset(0, 2),
                                    color: Color(0xffbdc2bf))
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: const Color(0xffeee1d8),
                      boxShadow: const [
                        BoxShadow(
                            color: Color(0xffbdc2bf), offset: Offset(2, 3))
                      ]),
                  child: TextFormField(
                    controller: registerController.email,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a this field';
                      }
                      return null;
                    },
                    keyboardType: TextInputType.emailAddress,
                    decoration:  InputDecoration(
                      icon: const Icon(
                        Icons.email,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                              offset: Offset(2, 2.5), color: Color(0xffbdc2bf)),
                        ],
                      ),
                      border: InputBorder.none,
                      hintText: "email".tr,
                      hintStyle: const TextStyle(
                        fontFamily: 'Berkshire Swash',
                        color: Colors.white,
                        shadows: [
                          Shadow(
                              offset: Offset(0, 2), color: Color(0xffbdc2bf)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        margin: const EdgeInsets.all(8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color(0xffeee1d8),
                            boxShadow: const [
                              BoxShadow(
                                  color: Color(0xffbdc2bf),
                                  offset: Offset(2, 3))
                            ]),
                        child: TextFormField(
                          controller: registerController.phoneController,
                          decoration:  InputDecoration(
                            icon: const Icon(
                              FontAwesomeIcons.phone,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    offset: Offset(2, 2.5),
                                    color: Color(0xffbdc2bf))
                              ],
                            ),
                            border: InputBorder.none,
                            hintText: "Phone".tr,
                            hintStyle: const TextStyle(
                              fontFamily: 'Berkshire Swash',
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    offset: Offset(0, 2),
                                    color: Color(0xffbdc2bf))
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: const Color(0xffeee1d8),
                      boxShadow: const [
                        BoxShadow(
                            color: Color(0xffbdc2bf), offset: Offset(2, 3))
                      ]),
                  child: TextFormField(
                    controller: registerController.passwordController,
                    obscureText: !registerController.isvisible,
                    decoration: InputDecoration(
                        icon: const Icon(
                          Icons.lock,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf))
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "Password".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf))
                          ],
                        ),
                        suffixIcon: IconButton(
                          onPressed: () {
                            registerController.changeVisible();
                          },
                          icon: Icon(registerController.isvisible
                              ? Icons.visibility
                              : Icons.visibility_off),
                          color: Colors.white,
                        )),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: const Color(0xffeee1d8),
                      boxShadow: const [
                        BoxShadow(
                            color: Color(0xffbdc2bf), offset: Offset(2, 3))
                      ]),
                  child: TextFormField(
                    controller: registerController.confirmpasswordController,
                    obscureText: !registerController.isvisible,
                    decoration: InputDecoration(
                        icon: const Icon(
                          Icons.lock,
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(2, 2.5),
                                color: Color(0xffbdc2bf))
                          ],
                        ),
                        border: InputBorder.none,
                        hintText: "Confirm_Password".tr,
                        hintStyle: const TextStyle(
                          fontFamily: 'Berkshire Swash',
                          color: Colors.white,
                          shadows: [
                            Shadow(
                                offset: Offset(0, 2), color: Color(0xffbdc2bf))
                          ],
                        ),
                        suffixIcon: IconButton(
                          onPressed: () {
                            registerController.changeVisible();
                          },
                          icon: Icon(registerController.isvisible
                              ? Icons.visibility
                              : Icons.visibility_off),
                          color: Colors.white,
                        )),
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              const SizedBox(
                height: 1,
              ),
              Padding(
                padding:
                    const EdgeInsets.only(left: 100, right: 100, bottom: 20),
                child: GestureDetector(
                  onTap: () {
                    registerController.registerUser();
                  },
                  child: Container(
                    alignment: Alignment.center,
                    width: 250,
                    height: 65,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(23.89),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0xffd7dcd4),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: Offset(-10, 0),
                        ),
                      ],
                      gradient: const LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Color(0xffABAC9C),
                          Color(0xffD7B59C),
                        ],
                      ),
                    ),
                    child:  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "next".tr,
                          style: const TextStyle(
                              color: Colors.white,
                              fontFamily: 'Berkshire Swash',
                              fontSize: 24.87),
                        ),
                        const Icon(
                          FontAwesomeIcons.chevronRight,
                          color: Colors.white,
                          size: 20,
                        ),
                        const Icon(
                          FontAwesomeIcons.chevronRight,
                          color: Colors.white,
                          size: 20,
                        )
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                     Text(
                      'Already_have_an_accoun'.tr,
                      style: const TextStyle(
                          color: Color(0xffdfb8a7),
                          fontSize: 14,
                          fontFamily: 'Besley'),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return const LoginOwner();
                            },
                          ),
                        );
                      },
                      child:  Text(
                        'Log_In'.tr,
                        style: const TextStyle(
                          fontSize: 14,
                          fontFamily: 'Besley',
                          color: Color(0xff677c75),
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
            ],
            
          ),
        ),
      ),
      
    );
  }
}
