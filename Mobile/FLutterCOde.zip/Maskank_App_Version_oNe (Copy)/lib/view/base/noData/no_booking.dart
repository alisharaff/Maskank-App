import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maskank/util/colors.dart';
import 'package:maskank/util/images.dart';

class NoBooking extends StatelessWidget {
  const NoBooking({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          AppImages.noBooking,
          height: 300,
          width: 300,
        ),
         Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            "Your_Requests_here!".tr,
            style: const TextStyle(
                fontSize: 22,
                fontFamily: "Cairo",
                fontWeight: FontWeight.bold,
                color: ColorsManager.mainOrange),
          ),
        )
      ],
    ));
  }
}
