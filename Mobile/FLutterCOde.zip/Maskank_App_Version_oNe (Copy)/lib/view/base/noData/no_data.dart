import 'package:flutter/material.dart';
import 'package:maskank/util/images.dart';

class NoData extends StatelessWidget {
  const NoData({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          AppImages.noData,
          height: 300,
          width: 300,
        ),
        const Padding(
          padding: EdgeInsets.all(8.0),
          child: Text(
            "OOPS, No Data!",
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
        )
      ],
    ));
  }
}
