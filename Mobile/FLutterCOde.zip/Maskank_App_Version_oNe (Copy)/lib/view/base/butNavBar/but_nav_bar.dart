import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:maskank/controller/but_navbar_controller.dart';
import 'package:maskank/view/screens/user/booking/booking_screen.dart';
import 'package:maskank/view/screens/user/favorite/favorite_screen.dart';
import 'package:maskank/view/screens/user/home/home_screen.dart';
import 'package:maskank/view/screens/user/home/searsh/searsh_screen.dart';
import 'package:maskank/view/screens/profile/profile_screen.dart';

import '../../../util/dimensions.dart';

class MyNavBar extends StatelessWidget {
  final BottomNavBarController _controller = Get.put(BottomNavBarController());

  MyNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => IndexedStack(
            index: _controller.selectedIndex.value,
            children: const <Widget>[
              HomeScreen(),
              FavoriteScreen(),
              BookingScreen(),
              ProfileScreen(),
            ],
          )),
      bottomNavigationBar: Obx(() => AnimatedBottomNavigationBar(
            icons: const [
              Icons.house_outlined,
              Icons.favorite_outline,
              Icons.bookmark_outline,
              Icons.person_outline,
            ],
            activeIndex: _controller.selectedIndex.value,
            gapLocation: GapLocation.center,
            onTap: _controller.onItemTapped,
            backgroundColor: Colors.grey[200],
            activeColor: const Color(0XFF5E756D),
            inactiveColor: Colors.grey,
          )),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0XFF5E756D),
        onPressed: () {
          // Navigate to the search screen
          Get.to(() => const SearchScreen());
        },
        child: const Icon(
          Icons.search,
          color: Colors.white,
          size: Dimensions.iconSizeLarge30,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
