import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:maskank/controller/but_navbar_controller.dart';
import 'package:maskank/util/dimensions.dart';
import 'package:maskank/view/screens/owner/home_owner/home_owner.dart';

import 'package:maskank/view/screens/owner/approved_posts/upload_owner_status.dart';
import 'package:maskank/view/screens/profile/profile_owner_screen.dart';

class OwnerMyNavBar extends StatelessWidget {
  final BottomNavBarController _controller = Get.put(BottomNavBarController());

  OwnerMyNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Obx(() => IndexedStack(
            index: _controller.selectedIndex.value,
            children: const <Widget>[
              HomeOwner(),
              OwnerProfileScreen(),
            ],
          )),
      bottomNavigationBar: Obx(() => AnimatedBottomNavigationBar(
            iconSize: Dimensions.iconSizeLarge35,
            icons: const [
              Icons.house_outlined,
              Icons.person_outline,
            ],
            activeIndex: _controller.selectedIndex.value,
            gapLocation: GapLocation.center,
            onTap: _controller.onItemTapped,
            backgroundColor: Colors.grey[200],
            activeColor: const Color(0XFF5E756D),
            inactiveColor: Colors.grey,
          )),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0XFF5E756D),
        onPressed: () {
          // Navigate to the search screen
          
          Get.to(() => const UploadOwnerStatus());
        },
        child: const Icon(
          Icons.check,
          color: Colors.white,
          size: Dimensions.iconSizeLarge35,
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
