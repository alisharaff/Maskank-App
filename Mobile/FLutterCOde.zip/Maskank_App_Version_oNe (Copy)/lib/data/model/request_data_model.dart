class RequestPostModel {
  Data data;

  RequestPostModel({required this.data});

  factory RequestPostModel.fromJson(Map<String, dynamic> json) {
    return RequestPostModel(
      data: Data.fromJson(json['data']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'data': data.toJson(),
    };
  }
}

class Data {
  int id;
  PostReques post;
  Renter renter;

  Data({required this.id, required this.post, required this.renter});

  factory Data.fromJson(Map<String, dynamic> json) {
    return Data(
      id: json['id'],
      post: PostReques.fromJson(json['post']),
      renter: Renter.fromJson(json['renter']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'post': post.toJson(),
      'renter': renter.toJson(),
    };
  }
}

class PostReques {
  int id;
  List<String> images;
  String description;
  String price;
  int size;
  String purpose;
  int bedrooms;
  int bathrooms;
  String region;
  String city;
  String floor;
  String? condition;
  int status;
  int booked;
  int? ownerId;
  Owner owner;

  PostReques({
    required this.id,
    required this.images,
    required this.description,
    required this.price,
    required this.size,
    required this.purpose,
    required this.bedrooms,
    required this.bathrooms,
    required this.region,
    required this.city,
    required this.floor,
    this.condition,
    required this.status,
    required this.booked,
    this.ownerId,
    required this.owner,
  });

  factory PostReques.fromJson(Map<String, dynamic> json) {
    return PostReques(
      id: json['id'],
      images: List<String>.from(json['images']),
      description: json['description'],
      price: json['price'],
      size: json['size'],
      purpose: json['purpose'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      region: json['region'],
      city: json['city'],
      floor: json['floor'],
      condition: json['condition'],
      status: json['status'],
      booked: json['booked'],
      ownerId: json['ownerId'],
      owner: Owner.fromJson(json['owner']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'images': images,
      'description': description,
      'price': price,
      'size': size,
      'purpose': purpose,
      'bedrooms': bedrooms,
      'bathrooms': bathrooms,
      'region': region,
      'city': city,
      'floor': floor,
      'condition': condition,
      'status': status,
      'booked': booked,
      'ownerId': ownerId,
      'owner': owner.toJson(),
    };
  }
}

class Owner {
  int ownerId;
  String username;
  String ownerName;
  String email;
  String phone;
  int status;
  String nationalId;
  String image;

  Owner({
    required this.ownerId,
    required this.username,
    required this.ownerName,
    required this.email,
    required this.phone,
    required this.status,
    required this.nationalId,
    required this.image,
  });

  factory Owner.fromJson(Map<String, dynamic> json) {
    return Owner(
      ownerId: json['owner_id'],
      username: json['username'],
      ownerName: json['owner_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      nationalId: json['national id'],
      image: json['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'owner_id': ownerId,
      'username': username,
      'owner_name': ownerName,
      'email': email,
      'phone': phone,
      'status': status,
      'national id': nationalId,
      'image': image,
    };
  }
}

class Renter {
  int renterId;
  String username;
  String renterName;
  String email;
  String phone;
  int? status;
  String image;

  Renter({
    required this.renterId,
    required this.username,
    required this.renterName,
    required this.email,
    required this.phone,
    this.status,
    required this.image,
  });

  factory Renter.fromJson(Map<String, dynamic> json) {
    return Renter(
      renterId: json['renter_id'],
      username: json['username'],
      renterName: json['renter_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      image: json['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'renter_id': renterId,
      'username': username,
      'renter_name': renterName,
      'email': email,
      'phone': phone,
      'status': status,
      'image': image,
    };
  }
}
