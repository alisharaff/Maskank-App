class Owner {
  final int ownerId;
  final String username;
  final String ownerName;
  final String email;
  final String phone;
  final int status;
  final String nationalId;
  final String image;

  Owner({
    required this.ownerId,
    required this.username,
    required this.ownerName,
    required this.email,
    required this.phone,
    required this.status,
    required this.nationalId,
    required this.image,
  });

  factory Owner.fromJson(Map<String, dynamic> json) {
    return Owner(
      ownerId: json['owner_id'],
      username: json['username'],
      ownerName: json['owner_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      nationalId: json['national id'],
      image: json['image'],
    );
  }
}

class House {
  final int id;
  final List<String> images; 
  final String description;
  final String purpose;
  final double price;
  final int size;
  final int bedrooms;
  final int bathrooms;
  final String region;
  final String city;
  final String floor;
  final dynamic condition;
  final int status;
  final int? ownerId;
  final int booked;
  final Owner owner;

  House({
    required this.id,
    required this.images,
    required this.description,
    required this.purpose,
    required this.price,
    required this.size,
    required this.bedrooms,
    required this.bathrooms,
    required this.region,
    required this.city,
    required this.floor,
    required this.condition,
    required this.status,
    this.ownerId,
    required this.booked,
    required this.owner,
  });

  factory House.fromJson(Map<String, dynamic> json) {
    return House(
      id: json['id'],
      images: List<String>.from(json['images']), 
      description: json['description'],
      purpose: json['purpose'],
      price: double.parse(json['price'].toString()), // Ensure price is double
      size: json['size'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      region: json['region'],
      city: json['city'],
      floor: json['floor'],
      condition: json['condition'],
      status: json['status'],
      ownerId: json['ownerId'],
      booked: json['booked'],
      owner: Owner.fromJson(json['owner']),
    );
  }
}
