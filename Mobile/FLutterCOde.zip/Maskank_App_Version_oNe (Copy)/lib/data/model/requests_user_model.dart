class MainRequestsOwner {
  final Post post;
  final List<Request> requests;

  MainRequestsOwner({
    required this.post,
    required this.requests,
  });

  factory MainRequestsOwner.fromJson(Map<String, dynamic> json) {
    var requestsList = json['requests'] as List;
    List<Request> requestList = requestsList.map((i) => Request.fromJson(i)).toList();

    return MainRequestsOwner(
      post: Post.fromJson(json['post']),
      requests: requestList,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'post': post.toJson(),
      'requests': requests.map((e) => e.toJson()).toList(),
    };
  }
}

class Post {
  final int id;
  final List<String> images;
  final String description;
  final String price;
  final int size;
  final String purpose;
  final int bedrooms;
  final int bathrooms;
  final String region;
  final String city;
  final String floor;
  final String? condition;
  final int status;
  final int booked;
  final int? ownerId;
  final Owner owner;

  Post({
    required this.id,
    required this.images,
    required this.description,
    required this.price,
    required this.size,
    required this.purpose,
    required this.bedrooms,
    required this.bathrooms,
    required this.region,
    required this.city,
    required this.floor,
    this.condition,
    required this.status,
    required this.booked,
    this.ownerId,
    required this.owner,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'],
      images: List<String>.from(json['images']),
      description: json['description'],
      price: json['price'],
      size: json['size'],
      purpose: json['purpose'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      region: json['region'],
      city: json['city'],
      floor: json['floor'],
      condition: json['condition'],
      status: json['status'],
      booked: json['booked'],
      ownerId: json['ownerId'],
      owner: Owner.fromJson(json['owner']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'images': images,
      'description': description,
      'price': price,
      'size': size,
      'purpose': purpose,
      'bedrooms': bedrooms,
      'bathrooms': bathrooms,
      'region': region,
      'city': city,
      'floor': floor,
      'condition': condition,
      'status': status,
      'booked': booked,
      'ownerId': ownerId,
      'owner': owner.toJson(),
    };
  }
}

class Owner {
  final int ownerId;
  final String username;
  final String ownerName;
  final String email;
  final String phone;
  final int status;
  final String nationalId;
  final String image;

  Owner({
    required this.ownerId,
    required this.username,
    required this.ownerName,
    required this.email,
    required this.phone,
    required this.status,
    required this.nationalId,
    required this.image,
  });

  factory Owner.fromJson(Map<String, dynamic> json) {
    return Owner(
      ownerId: json['owner_id'],
      username: json['username'],
      ownerName: json['owner_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      nationalId: json['national id'],
      image: json['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'owner_id': ownerId,
      'username': username,
      'owner_name': ownerName,
      'email': email,
      'phone': phone,
      'status': status,
      'national id': nationalId,
      'image': image,
    };
  }
}

class Request {
  final int id;
  final int status;
  final int renterId;
  final int postId;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Renter renter;

  Request({
    required this.id,
    required this.status,
    required this.renterId,
    required this.postId,
    required this.createdAt,
    required this.updatedAt,
    required this.renter,
  });

  factory Request.fromJson(Map<String, dynamic> json) {
    return Request(
      id: json['id'],
      status: json['status'],
      renterId: json['renter_id'],
      postId: json['post_id'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      renter: Renter.fromJson(json['renter']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'status': status,
      'renter_id': renterId,
      'post_id': postId,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'renter': renter.toJson(),
    };
  }
}

class Renter {
  final int id;
  final String username;
  final String renterName;
  final String phone;
  final String email;
  final String? emailVerifiedAt;
  final String photo;
  final DateTime createdAt;
  final DateTime updatedAt;

  Renter({
    required this.id,
    required this.username,
    required this.renterName,
    required this.phone,
    required this.email,
    this.emailVerifiedAt,
    required this.photo,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Renter.fromJson(Map<String, dynamic> json) {
    return Renter(
      id: json['id'],
      username: json['username'],
      renterName: json['renter_name'],
      phone: json['phone'],
      email: json['email'],
      emailVerifiedAt: json['email_verified_at'],
      photo: json['photo'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'username': username,
      'renter_name': renterName,
      'phone': phone,
      'email': email,
      'email_verified_at': emailVerifiedAt,
      'photo': photo,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}
