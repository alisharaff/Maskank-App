class Post {
  int postId;
  List<dynamic> images;
  String description;
  double price;
  int size;
  String purpose;
  int bedrooms;
  int bathrooms;
  String region;
  String city;
  String floor;
  String? condition;
  int status;
  int? ownerId;
  Owner? owner;
  int booked;
  DateTime createdAt;
  DateTime updatedAt;

  Post({
    required this.postId,
    required this.images,
    required this.description,
    required this.price,
    required this.size,
    required this.purpose,
    required this.bedrooms,
    required this.bathrooms,
    required this.region,
    required this.city,
    required this.floor,
    this.condition,
    required this.status,
    this.ownerId,
    this.owner,
    required this.booked,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      postId: json['id'],
      images: json['images'] ?? [],
      description: json['description'],
      price: double.parse(json['price'].toString()),
      size: json['size'],
      purpose: json['purpose'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      region: json['region'],
      city: json['city'],
      floor: json['floor'],
      condition: json['condition'],
      status: json['status'],
      ownerId: json['ownerId'],
      owner: json['owner'] != null ? Owner.fromJson(json['owner']) : null,
      booked: json['booked'],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': postId,
      'images': images,
      'description': description,
      'price': price,
      'size': size,
      'purpose': purpose,
      'bedrooms': bedrooms,
      'bathrooms': bathrooms,
      'region': region,
      'city': city,
      'floor': floor,
      'condition': condition,
      'status': status,
      'ownerId': ownerId,
      'owner': owner?.toJson(),
      'booked': booked,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}

class Owner {
  int ownerId;
  String username;
  String ownerName;
  String email;
  String phone;
  int status;
  String nationalId;
  String image;

  Owner({
    required this.ownerId,
    required this.username,
    required this.ownerName,
    required this.email,
    required this.phone,
    required this.status,
    required this.nationalId,
    required this.image,
  });

  factory Owner.fromJson(Map<String, dynamic> json) {
    return Owner(
      ownerId: json['owner_id'],
      username: json['username'],
      ownerName: json['owner_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      nationalId: json['national id'],
      image: json['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'owner_id': ownerId,
      'username': username,
      'owner_name': ownerName,
      'email': email,
      'phone': phone,
      'status': status,
      'national id': nationalId,
      'image': image,
    };
  }
}
