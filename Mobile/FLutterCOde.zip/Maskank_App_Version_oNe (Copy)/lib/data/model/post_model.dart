
class ApiResponse {
  String message;
  List<PostData> data;

  ApiResponse({required this.message, required this.data});

  factory ApiResponse.fromJson(Map<String, dynamic> json) {
    return ApiResponse(
      message: json['message'],
      data: (json['data'] as List)
          .map((postJson) => PostData.fromJson(postJson))
          .toList(),
    );
  }
}

class PostData {
  int id;
  Post post;
  Renter renter;

  PostData({required this.id, required this.post, required this.renter});

  factory PostData.fromJson(Map<String, dynamic> json) {
    return PostData(
      id: json['id'],
      post: Post.fromJson(json['post']),
      renter: Renter.fromJson(json['renter']),
    );
  }
}

class Post {
  int id;
  List<String> images;
  String description;
  String price;
  int size;
  String purpose;
  int bedrooms;
  int bathrooms;
  String region;
  String city;
  String floor;
  dynamic condition;
  int status;
  int booked;
  dynamic ownerId;
  Owner owner;

  Post({
    required this.id,
    required this.images,
    required this.description,
    required this.price,
    required this.size,
    required this.purpose,
    required this.bedrooms,
    required this.bathrooms,
    required this.region,
    required this.city,
    required this.floor,
    required this.condition,
    required this.status,
    required this.booked,
    required this.ownerId,
    required this.owner,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'],
      images: List<String>.from(json['images']), 
      description: json['description'],
      price: json['price'],
      size: json['size'],
      purpose: json['purpose'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      region: json['region'],
      city: json['city'],
      floor: json['floor'],
      condition: json['condition'],
      status: json['status'],
      booked: json['booked'],
      ownerId: json['ownerId'],
      owner: Owner.fromJson(json['owner']),
    );
  }
}

class Owner {
  int ownerId;
  String username;
  String ownerName;
  String email;
  String phone;
  int status;
  String nationalId;
  String image;

  Owner({
    required this.ownerId,
    required this.username,
    required this.ownerName,
    required this.email,
    required this.phone,
    required this.status,
    required this.nationalId,
    required this.image,
  });

  factory Owner.fromJson(Map<String, dynamic> json) {
    return Owner(
      ownerId: json['owner_id'],
      username: json['username'],
      ownerName: json['owner_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      nationalId: json['national id'],
      image: json['image'],
    );
  }
}

class Renter {
  int renterId;
  String username;
  String renterName;
  String email;
  String phone;
  dynamic status;
  String image;

  Renter({
    required this.renterId,
    required this.username,
    required this.renterName,
    required this.email,
    required this.phone,
    required this.status,
    required this.image,
  });

  factory Renter.fromJson(Map<String, dynamic> json) {
    return Renter(
      renterId: json['renter_id'],
      username: json['username'],
      renterName: json['renter_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      image: json['image'],
    );
  }
}
