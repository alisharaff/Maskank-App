class RequestPostResponse {
  final String message;
  final List<PostData> data;

  RequestPostResponse({required this.message, required this.data});

  factory RequestPostResponse.fromJson(Map<String, dynamic> json) {
    return RequestPostResponse(
      message: json['message'],
      data: (json['data'] as List).map((i) => PostData.fromJson(i)).toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'data': data.map((e) => e.toJson()).toList(),
    };
  }
}

class PostData {
  final int id;
  final int status;
  final Post post;
  final Renter renter;

  PostData({
    required this.id,
    required this.post,
    required this.renter,
    required this.status,
  });

  factory PostData.fromJson(Map<String, dynamic> json) {
    return PostData(
      id: json['id'],
      status: json['status'],
      post: Post.fromJson(json['post']),
      renter: Renter.fromJson(json['renter']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'status': status,
      'post': post.toJson(),
      'renter': renter.toJson(),
    };
  }
}

class Post {
  final int id;
  final List<String> images;
  final String description;
  final String price;
  final int size;
  final String purpose;
  final int bedrooms;
  final int bathrooms;
  final String region;
  final String city;
  final String floor;
  final dynamic condition;
  final int status;
  final int booked;
  final dynamic ownerId;
  final Owner owner;

  Post({
    required this.id,
    required this.images,
    required this.description,
    required this.price,
    required this.size,
    required this.purpose,
    required this.bedrooms,
    required this.bathrooms,
    required this.region,
    required this.city,
    required this.floor,
    this.condition,
    required this.status,
    required this.booked,
    this.ownerId,
    required this.owner,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'],
      images: List<String>.from(json['images']),
      description: json['description'],
      price: json['price'],
      size: json['size'],
      purpose: json['purpose'],
      bedrooms: json['bedrooms'],
      bathrooms: json['bathrooms'],
      region: json['region'],
      city: json['city'],
      floor: json['floor'],
      condition: json['condition'],
      status: json['status'],
      booked: json['booked'],
      ownerId: json['ownerId'],
      owner: Owner.fromJson(json['owner']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'images': images,
      'description': description,
      'price': price,
      'size': size,
      'purpose': purpose,
      'bedrooms': bedrooms,
      'bathrooms': bathrooms,
      'region': region,
      'city': city,
      'floor': floor,
      'condition': condition,
      'status': status,
      'booked': booked,
      'ownerId': ownerId,
      'owner': owner.toJson(),
    };
  }
}

class Owner {
  final int ownerId;
  final String username;
  final String ownerName;
  final String email;
  final String phone;
  final int status;
  final String nationalId;
  final String image;

  Owner({
    required this.ownerId,
    required this.username,
    required this.ownerName,
    required this.email,
    required this.phone,
    required this.status,
    required this.nationalId,
    required this.image,
  });

  factory Owner.fromJson(Map<String, dynamic> json) {
    return Owner(
      ownerId: json['owner_id'],
      username: json['username'],
      ownerName: json['owner_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      nationalId: json['national id'],
      image: json['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'owner_id': ownerId,
      'username': username,
      'owner_name': ownerName,
      'email': email,
      'phone': phone,
      'status': status,
      'national id': nationalId,
      'image': image,
    };
  }
}

class Renter {
  final int renterId;
  final String username;
  final String renterName;
  final String email;
  final String phone;
  final dynamic status;
  final String image;

  Renter({
    required this.renterId,
    required this.username,
    required this.renterName,
    required this.email,
    required this.phone,
    this.status,
    required this.image,
  });

  factory Renter.fromJson(Map<String, dynamic> json) {
    return Renter(
      renterId: json['renter_id'],
      username: json['username'],
      renterName: json['renter_name'],
      email: json['email'],
      phone: json['phone'],
      status: json['status'],
      image: json['image'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'renter_id': renterId,
      'username': username,
      'renter_name': renterName,
      'email': email,
      'phone': phone,
      'status': status,
      'image': image,
    };
  }
}
