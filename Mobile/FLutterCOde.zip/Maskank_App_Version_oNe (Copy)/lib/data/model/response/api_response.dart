class ApiResponse {
  final int statusCode;
  final dynamic body;

  ApiResponse({required this.statusCode, required this.body});
}