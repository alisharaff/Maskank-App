class ErrorResponse {
  List<Error> errors;

  ErrorResponse({required this.errors});

  factory ErrorResponse.fromJson(Map<String, dynamic> json) {
    return ErrorResponse(
      errors: List<Error>.from(json['errors'].map((x) => Error.fromJson(x))),
    );
  }
}

class Error {
  String code;
  String message;

  Error({required this.code, required this.message});

  factory Error.fromJson(Map<String, dynamic> json) {
    return Error(
      code: json['code'],
      message: json['message'],
    );
  }
}
