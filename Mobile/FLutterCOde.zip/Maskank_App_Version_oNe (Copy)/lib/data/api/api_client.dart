import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart' as foundation;
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:maskank/data/model/response/error_response.dart';

import '../../util/app_constants.dart';

class ApiClient extends GetxService {
  final String appBaseUrl;
  final SharedPreferences sharedPreferences;
  static const String noInternetMessage =
      'Connection to API server failed due to internet connection';
  final int timeoutInSeconds = 30;

  String? token;
  Map<String, String>? _mainHeaders;

  ApiClient({required this.appBaseUrl, required this.sharedPreferences}) {
    token = sharedPreferences.getString(AppConstants.token);
    debugPrint('Token: $token');
    updateHeader(token);
  }

  void updateHeader(String? token) {
    _mainHeaders = {
      'Content-Type': 'application/json; charset=UTF-8',
      'token': 'Bearer $token'
    };
  }

  Future<Response> getData(String uri,
      {Map<String, dynamic>? query, Map<String, String>? headers}) async {
    try {
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print('====> API Call: $uri\nToken: $token');
        }
      }
      http.Response response = await http
          .get(
            Uri.parse(appBaseUrl + uri),
            headers: headers ?? _mainHeaders,
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      Response apiResponse = handleResponse(response);

      // print('====> ApiResponse: $apiResponse');

      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print(
              '====> API Response: [${response.statusCode}] $uri\n${response.body}');
        }
      }
      return apiResponse;
    } catch (e) {
      return const Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> postAuthMUltiData(String uri, Map<String, String> body,
      {Map<String, String>? headers, File? imageFile}) async {
    print('====> API Body: $body');
    print('====> API Call: $uri');

    // Create a multipart request
    var request = http.MultipartRequest('POST', Uri.parse(appBaseUrl + uri));

    // Add fields to the request
    request.fields.addAll(body);

    // Add headers if provided
    if (headers != null) {
      request.headers.addAll(headers);
    }

    // Add image file if provided
    if (imageFile != null) {
      // Determine the content type based on the file extension or type
      // String contentType = 'image/jpeg'; // Adjust as per your file type

      // Add the file to the request
      request.files.add(await http.MultipartFile.fromPath(
        'image', // Field name on the server side
        imageFile.path,
        contentType: MediaType('image', 'jpeg'), // Adjust MediaType accordingly
      ));
    }

    // Send the request and await the response
    http.StreamedResponse streamedResponse =
        await request.send().timeout(Duration(seconds: timeoutInSeconds));
    http.Response response = await http.Response.fromStream(streamedResponse);

    // Handle the response
    Response apiResponse = handleResponse(response);

    // Print the response if in debug mode
    if (foundation.kDebugMode) {
      print(
          '====> API Response: [${response.statusCode}] $uri\n${response.body}');
    }

    return apiResponse;
  }

  Future<Response> postAuthData(String uri, dynamic body,
      {Map<String, String>? headers}) async {
    print('====> API Body: $body');

    print('====> API Call: $uri');

    http.Response response = await http
        .post(
          Uri.parse(appBaseUrl + uri),
          body: body,
        )
        .timeout(Duration(seconds: timeoutInSeconds));
    Response apiResponse = handleResponse(response);
    if (foundation.kDebugMode) {
      if (kDebugMode) {
        print(
            '====> API Response: [${response.statusCode}] $uri\n${response.body}');
      }
    }
    return apiResponse;
  }

  Future<Response> postData(String uri, dynamic body,
      {Map<String, String>? headers}) async {
    try {
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print('====> API Call: $uri\nToken: $token');
        }
        if (kDebugMode) {
          print('====> API Body: $body');
        }
      }
      http.Response response = await http
          .post(
            Uri.parse(appBaseUrl + uri),
            body: jsonEncode(body),
            headers: headers ?? _mainHeaders,
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      Response apiResponse = handleResponse(response);
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print(
              '====> API Response: [${response.statusCode}] $uri\n${response.body}');
        }
      }
      return apiResponse;
    } catch (e) {
      return const Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> postMultipartData(
      String uri, Map<String, dynamic> body, List<MultipartBody> multipartBody,
      {Map<String, String>? headers}) async {
    // try {
    //   if (foundation.kDebugMode) {
    //     if (kDebugMode) {
    //       print('====> API Call: $uri\nToken: $token');
    //     }
    //     if (kDebugMode) {
    //       print('====> API Body: $body');
    //     }
    //   }
    http.MultipartRequest request =
        http.MultipartRequest('POST', Uri.parse(appBaseUrl + uri));
    request.headers.addAll(headers ?? _mainHeaders!);
    for (MultipartBody multipart in multipartBody) {
      if (foundation.kIsWeb) {
        Uint8List list = await multipart.file.readAsBytes();
        http.MultipartFile part = http.MultipartFile(
          multipart.key,
          multipart.file.readAsBytes().asStream(),
          list.length,
          filename: path.basename(multipart.file.path),
          contentType: MediaType('image', 'jpg'),
        );
        request.files.add(part);
      } else {
        File file = File(multipart.file.path);
        request.files.add(http.MultipartFile(
          multipart.key,
          file.readAsBytes().asStream(),
          file.lengthSync(),
          filename: file.path.split('/').last,
        ));
      }
    }
    // Convert dynamic body values to string
    Map<String, String> stringBody =
        body.map((key, value) => MapEntry(key, value.toString()));
    request.fields.addAll(stringBody); // Add converted body to request
    http.Response response =
        await http.Response.fromStream(await request.send());
    Response apiResponse = handleResponse(response);
    if (foundation.kDebugMode) {
      if (kDebugMode) {
        print(
            '====> API Response: [${response.statusCode}] $uri\n${response.body}');
      }
    }
    return apiResponse;
    // } catch (e) {
    //   return const Response(statusCode: 1, statusText: noInternetMessage);
    // }
  }

  Future<Response> putData(String uri, dynamic body,
      {Map<String, String>? headers}) async {
    try {
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print('====> API Call: $uri\nToken: $token');
        }
        if (kDebugMode) {
          print('====> API Body: $body');
        }
      }
      http.Response response = await http
          .put(
            Uri.parse(appBaseUrl + uri),
            body: jsonEncode(body),
            headers: headers ?? _mainHeaders,
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      Response apiResponse = handleResponse(response);
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print(
              '====> API Response: [${response.statusCode}] $uri\n${response.body}');
        }
      }
      return apiResponse;
    } catch (e) {
      return const Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Future<Response> deleteData(String uri,
      {Map<String, String>? headers}) async {
    try {
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print('====> API Call: $uri\nToken: $token');
        }
      }
      http.Response response = await http
          .delete(
            Uri.parse(appBaseUrl + uri),
            headers: headers ?? _mainHeaders,
          )
          .timeout(Duration(seconds: timeoutInSeconds));
      Response apiResponse = handleResponse(response);
      if (foundation.kDebugMode) {
        if (kDebugMode) {
          print(
              '====> API Response: [${response.statusCode}] $uri\n${response.body}');
        }
      }
      return apiResponse;
    } catch (e) {
      return const Response(statusCode: 1, statusText: noInternetMessage);
    }
  }

  Response handleResponse(http.Response apiResponse) {
    dynamic body;
    try {
      body = jsonDecode(apiResponse.body);
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
    Response response = Response(
      body: body ?? apiResponse.body,
      bodyString: apiResponse.body.toString(),
      headers: apiResponse.headers,
      statusCode: apiResponse.statusCode,
      statusText: apiResponse.reasonPhrase,
    );
    if (response.statusCode != 200 &&
        response.body != null &&
        response.body is! String) {
      if (response.body.toString().startsWith('{errors: [{code:')) {
        ErrorResponse errorResponse = ErrorResponse.fromJson(response.body);
        response = Response(
            statusCode: response.statusCode,
            body: response.body,
            statusText: errorResponse.errors[0].message);
      } else if (response.body.toString().startsWith('{message')) {
        response = Response(
            statusCode: response.statusCode,
            body: response.body,
            statusText: response.body['message']);
      } else if (response.body.toString().startsWith('{success')) {
        response = Response(
            statusCode: response.statusCode,
            body: response.body,
            statusText: response.body['message']);
      }
    } else if (response.statusCode != 200 && response.body == null) {
      response = const Response(statusCode: 0, statusText: noInternetMessage);
    }
    return response;
  }
}

class MultipartBody {
  String key;
  XFile file;

  MultipartBody(this.key, this.file, foundation.Uint8List readAsBytesSync,
      {required String filename});
}
