class AppConstants {
  static const String appName = 'Maskank App';
  static const bool demo = false;
  static const String baseUrl = 'BaseUrlHere'; // Make it for app work
  // user EndPoints
  static const String loginUrl = '/api/renter/login';
  static const String registerUrl = '/api/renter/register';
  // Owner EndPoints
  static const String ownerLoginUrl = '/api/owner/login';
  static const String ownerRegisterUrl = '/api/owner/register';
  static const String ownerWaitingAndDoneUrl = '/api/WaitingAndDone';
  static const String uploadPostUrl = '/api/post/create';

  static const String updtaeRequestStatusUrl = '/api/request/update';

  // Posts EndPoints
  static const String getHomeUserPostLoginUrl = '/api/posts';
  static const String getPostsOfOwnerUrl = '/api/postsOwner';
  static const String getRequestDataUrl = '/api/owner/request';

  static const String getPostsDetailsUrl = '/api/post'; //take /post id
  static const String addFavoriteUrl =
      '/api/post/favorite'; // take renter id and post id
  static const String removeFavoriteUrl =
      '/api/unfavorite'; // take renter id and post id
  static const String getFavoriteUrl =
      '/api/renter/favorite'; // take renter if /1
  static const String addRequestPostUrl = '/api/post/request';
  static const String showRequestPostUrl = '/api/renter/request';
  static const String searchPostUrl = '/api/search';
  static const String filterPostUrl = '/api/posts/filter';

  // Shared Preferences Keys
  static const String token = 'token';
  static const String userID = 'userID';
  static const String type = 'type';
  static const String fullName = 'fullName';
  static const String userName = 'userName';
  static const String userPhone = 'phone';
  static const String userEmail = 'email';

  // static List<LanguageModel> languages = [
  //   LanguageModel(
  //       imageUrl: Images.unitedKingdom,
  //       languageName: 'English',
  //       countryCode: 'US',
  //       languageCode: 'en'),
  //   LanguageModel(
  //       imageUrl: Images.saudi,
  //       languageName: 'Arabic',
  //       countryCode: 'SA',
  //       languageCode: 'ar'),
  // ];
}
