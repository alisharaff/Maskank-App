class AppImages {
  static const String logo = 'assets/images/logo.png';
  static const String onBoardingONe = 'assets/images/onBoardingOne.png';
  static const String onBoardingTwo = 'assets/images/onBoardingTwo.png';
  static const String onBoardingThree = 'assets/images/onBoardingThree.png';
  static const String loginImg = 'assets/images/loginImg.png';
  static const String waveImg = 'assets/images/wavLogin.png';
  static const String halfCircle = 'assets/images/halfCircle.png';
  static const String selectRoleCircle = 'assets/images/selectRoleCircle.png';
  static const String selectRoleCircleBU =
      'assets/images/selectRoleCircleBU.png';
  static const String exploreCardImg = 'assets/images/explore_image.png';
  static const String orange = 'assets/images/orangeframe.png';
  static const String profilepic = 'assets/images/profilepic.png';
  static const String mail = 'assets/images/Mail.svg';
  static const String phone = 'assets/images/phone.svg';
  static const String location = 'assets/images/Location.svg';
  static const String noData = 'assets/images/no_data.png';
  static const String noConnection= 'assets/images/no_connection.png';
  static const String uploadPost= 'assets/images/upload_post.png';
  static const String noBooking= 'assets/images/noBooking.png';



}
