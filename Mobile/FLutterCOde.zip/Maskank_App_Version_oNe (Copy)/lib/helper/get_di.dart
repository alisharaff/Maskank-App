import 'package:get/get.dart';
import 'package:maskank/controller/but_navbar_controller.dart';
import 'package:maskank/controller/owner/auth/regestter_owner_controller.dart';
import 'package:maskank/controller/owner/home_owner_controller.dart';
import 'package:maskank/controller/user/auth/login_user_controller.dart';
import 'package:maskank/controller/user/auth/regester_user_controller.dart';
import 'package:maskank/controller/user/home_user_controller.dart';

Future<Map<String, Map<String, String>>> init() async {
  // Controller
  Get.lazyPut(() => RegisterUserController());
  Get.lazyPut(() => RegesterOwnerController());
  Get.lazyPut(() => BottomNavBarController());
  Get.lazyPut(() => HomeOwnerController());
  Get.lazyPut(() => HomeUserController());
  Get.lazyPut(() => LoginUserController());
  return {};
}