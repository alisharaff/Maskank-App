package com.example.maskank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
